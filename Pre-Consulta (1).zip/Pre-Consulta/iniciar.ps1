# Abre a Pre-Consulta. O app sobe a API sozinho usando o .venv desta pasta.
Set-Location $PSScriptRoot
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Ambiente nao encontrado. Rode instalar.bat primeiro." -ForegroundColor Red; Read-Host "Enter para sair"; exit 1
}
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Write-Host "Aviso: Ollama nao encontrado; o app vai funcionar sem a IA local." -ForegroundColor Yellow
}
Push-Location desktop
npm start
Pop-Location
