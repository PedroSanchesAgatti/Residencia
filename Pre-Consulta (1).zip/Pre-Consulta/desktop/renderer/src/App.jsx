import React, { useEffect, useRef, useState } from "react";
import { chamar } from "./api.js";
import Topo from "./componentes/Topo.jsx";
import Passos from "./componentes/Passos.jsx";
import NovaAplicacao from "./componentes/NovaAplicacao.jsx";
import AreaResultados from "./componentes/AreaResultados.jsx";
import TelaDocumentos from "./componentes/TelaDocumentos.jsx";
import TelaRelato from "./componentes/TelaRelato.jsx";
import TelaQuestionario from "./componentes/TelaQuestionario.jsx";
import TelaAgradecimento from "./componentes/TelaAgradecimento.jsx";
import TelaRisco from "./componentes/TelaRisco.jsx";
import DialogoPin from "./componentes/DialogoPin.jsx";

// Abrir em outra janela: ?modo=paciente&sid=12&codigo=P-0001
const params = new URLSearchParams(window.location.search);
const JANELA_PACIENTE = params.get("modo") === "paciente" && params.get("sid");

const PASSO = { relato: 0, questionario: 1, agradecimento: 2 };

export default function App() {
  const [saude, setSaude] = useState(null);
  const [erroApi, setErroApi] = useState(false);
  const [modo, setModo] = useState(JANELA_PACIENTE ? "paciente" : "profissional");
  // Profissional: "resultados" | "nova" | "documentos". Paciente: "relato" | "questionario" | "agradecimento" | "risco"
  const [tela, setTela] = useState(JANELA_PACIENTE ? "relato" : "resultados");
  const [sessao, setSessao] = useState(JANELA_PACIENTE ? { id: Number(params.get("sid")), codigo: params.get("codigo") } : null);
  const [aberta, setAberta] = useState(null);
  const [dados, setDados] = useState({});
  const [pinAberto, setPinAberto] = useState(false);
  const principal = useRef(null);

  useEffect(() => {
    let vivo = true, tentativas = 0;
    const verificar = () => chamar("/saude")
      .then((s) => { if (vivo) { setSaude(s); setErroApi(false); } })
      .catch(() => { if (vivo) { tentativas += 1; if (tentativas > 20) setErroApi(true); setTimeout(verificar, 1500); } });
    verificar();
    return () => { vivo = false; };
  }, []);

  // A cada troca de tela, o foco vai para o título (teclado e leitores de tela).
  useEffect(() => { principal.current?.querySelector("h2")?.focus(); }, [tela, modo, dados.pergunta]);

  const iniciarAqui = (s) => { setSessao(s); setDados({}); setModo("paciente"); setTela("relato"); };
  // Retomar uma aplicação interrompida, do ponto em que parou
  const retomar = (r) => {
    setSessao({ id: r.id, codigo: r.codigo }); setModo("paciente");
    if (r.estado === "questionario") { setDados({ itens: r.itens }); setTela("questionario"); }
    else if (r.estado === "perguntas") { setDados({ pergunta: r.pergunta, restantes: r.restantes }); setTela("relato"); }
    else { setDados({}); setTela("relato"); }
  };
  const voltarProfissional = () => { setPinAberto(false); setModo("profissional"); setTela("resultados"); setSessao(null); setDados({}); };
  const encerrarPaciente = () => {
    if (JANELA_PACIENTE) window.close();   // janela aberta só para o paciente
    else setPinAberto(true);
  };

  let conteudo;
  if (!saude) {
    conteudo = (
      <section className="cartao" aria-busy="true">
        <h2 tabIndex={-1}>{erroApi ? "Serviço local indisponível" : "Iniciando…"}</h2>
        <p className="ajuda">{erroApi ? "Confira se a API está rodando (veja o README)." : "Na primeira vez, o carregamento pode levar um ou dois minutos."}</p>
      </section>);
  } else if (modo === "profissional") {
    if (tela === "nova") conteudo = <NovaAplicacao aoIniciarAqui={iniciarAqui} aoAbrirJanela={() => setTela("resultados")} />;
    else if (tela === "documentos") conteudo = <TelaDocumentos sid={aberta} aoVoltar={() => setTela("resultados")} />;
    else conteudo = <AreaResultados aoAbrir={(sid) => { setAberta(sid); setTela("documentos"); }} aoNova={() => setTela("nova")} aoRetomar={retomar} />;
  } else {
    if (tela === "relato") conteudo = (
      <TelaRelato key={dados.pergunta || "inicial"} sessao={sessao} pergunta={dados.pergunta} restantes={dados.restantes}
        aoPerguntar={(p, r) => setDados({ ...dados, pergunta: p, restantes: r })}
        aoItens={(itens) => { setDados({ ...dados, itens }); setTela("questionario"); }}
        aoRisco={(m) => { setDados({ ...dados, mensagem: m }); setTela("risco"); }} />);
    else if (tela === "questionario") conteudo = <TelaQuestionario sessao={sessao} itens={dados.itens} aoConcluir={() => setTela("agradecimento")} />;
    else if (tela === "agradecimento") conteudo = <TelaAgradecimento aoEncerrar={encerrarPaciente} />;
    else if (tela === "risco") conteudo = <TelaRisco mensagem={dados.mensagem} aoEncerrar={encerrarPaciente} />;
  }

  return (
    <>
      <a className="pular" href="#conteudo">Pular para o conteúdo</a>
      <Topo modo={modo} tela={tela} aoNavegar={setTela} aoSairPaciente={() => setPinAberto(true)} erroApi={erroApi && !saude}
        avisoIA={modo === "profissional" && saude?.local?.ia_disponivel === false && saude?.llm !== "simulado"} />
      <main id="conteudo" ref={principal} tabIndex={-1}>
        {modo === "paciente" && tela in PASSO && <Passos atual={PASSO[tela]} />}
        {conteudo}
      </main>
      {pinAberto && <DialogoPin aoConfirmar={voltarProfissional} aoCancelar={() => setPinAberto(false)} />}
    </>
  );
}
