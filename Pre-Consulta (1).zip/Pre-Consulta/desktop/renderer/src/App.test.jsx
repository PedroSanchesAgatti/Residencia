// Teste de ponta a ponta da interface contra a API local (rode a API antes: uvicorn api.main:app).
import React from "react";
import { render, screen, within, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect } from "vitest";
import App from "./App.jsx";

describe("fluxo completo: profissional → paciente → profissional", () => {
  it("aplicação, agradecimento, PIN, resultados, documentos e conclusão", async () => {
    const u = userEvent.setup();
    const COD = `P-UI${Date.now() % 100000}`;
    render(<App />);
    await screen.findByRole("heading", { name: /Resultados/ }, { timeout: 40000 });

    // tema: grupo de opções navegável pelas setas
    const automatico = screen.getByRole("radio", { name: /Tema automático/ });
    automatico.focus(); await u.keyboard("{ArrowRight}");
    expect(screen.getByRole("radio", { name: "Tema escuro" }).getAttribute("aria-checked")).toBe("true");

    await u.click(within(screen.getByRole("navigation", { name: "Área da profissional" })).getByRole("button", { name: "Nova aplicação" }));
    await u.click(screen.getByRole("button", { name: /Iniciar nesta tela/ }));
    expect(screen.getByRole("alert").textContent).toContain("Informe o código");
    await u.type(screen.getByLabelText(/Código da pessoa/), COD);
    expect(screen.queryByLabelText(/Nome/)).toBeNull();                     // sem nome do paciente nem da profissional
    await u.click(screen.getByRole("button", { name: /Iniciar nesta tela/ }));

    // modo paciente: sem acesso à navegação da profissional
    let campo = await screen.findByLabelText(/Conte, com suas palavras/);
    expect(screen.queryByRole("navigation", { name: "Área da profissional" })).toBeNull();
    await u.type(campo, "Esqueço reuniões, chego em casa sem energia e ando sem paciência.");
    await u.click(screen.getByRole("button", { name: "Continuar" }));
    while (!screen.queryByRole("heading", { name: "Questionário" })) {
      const extra = await screen.findByRole("heading", { name: /Questionário|Só mais uma pergunta/ }, { timeout: 30000 });
      if (extra.textContent === "Questionário") break;
      await u.type(screen.getByRole("textbox"), "Acontece quase todos os dias.");
      await u.click(screen.getByRole("button", { name: "Continuar" }));
      await new Promise((r) => setTimeout(r, 300));
    }
    const grupos = screen.getAllByRole("group");
    expect(grupos).toHaveLength(8);
    for (const g of grupos) await u.click(within(g).getByRole("radio", { name: /Frequentemente/ }));
    await u.click(screen.getByRole("button", { name: "Concluir questionário" }));

    await screen.findByRole("heading", { name: "Obrigado por responder" }, { timeout: 30000 });
    expect(document.body.textContent).toContain("não é um diagnóstico");
    await u.click(screen.getByRole("button", { name: /Concluir e devolver/ }));

    // PIN para voltar à área da profissional
    const dialogo = screen.getByRole("dialog", { name: "Área da profissional" });
    await u.type(within(dialogo).getByLabelText("PIN"), "0000");
    await u.click(within(dialogo).getByRole("button", { name: "Entrar" }));
    expect((await within(dialogo).findByRole("alert")).textContent).toContain("PIN incorreto");
    await u.type(within(dialogo).getByLabelText("PIN"), "1234");
    await u.click(within(dialogo).getByRole("button", { name: "Entrar" }));

    // resultado aparece "ao vivo" na lista
    const item = await screen.findByRole("button", { name: new RegExp(`${COD}.*Pronto para leitura`) }, { timeout: 60000 });
    expect(item.getAttribute("aria-label")).toContain("Novo");
    await u.click(item);

    await screen.findByRole("heading", { name: COD }, { timeout: 30000 });
    const abas = screen.getAllByRole("tab");
    abas[0].focus(); await u.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Análise de apoio (IA)" }).getAttribute("aria-selected")).toBe("true");
    await u.keyboard("{ArrowLeft}");

    await u.type(await screen.findByLabelText(/5\. Conclusão/), "Indicadores relevantes de exaustão; acompanhar.");
    await u.click(screen.getByRole("button", { name: /Salvar e assinar/ }));
    expect((await screen.findByText(/Informe seu nome e CRP/)).textContent).toBeTruthy();   // assinatura obrigatória
    await u.type(screen.getByLabelText("Nome completo"), "Dra. Ana Souza");
    await u.type(screen.getByLabelText("CRP"), "06/12345");
    await u.click(screen.getByRole("button", { name: /Salvar e assinar/ }));
    await screen.findByText(/Salvo e assinado às/);

    const lista = await (await fetch(`http://127.0.0.1:8000/atendimentos?busca=${COD}`)).json();
    expect(lista[0].visto).toBe(true);
    expect(lista[0].tem_conclusao).toBe(true);
    const html = await (await fetch(`http://127.0.0.1:8000/sessoes/${lista[0].id}/relatorio.html`)).text();
    expect(html).toContain("Indicadores relevantes de exaustão");
    expect(html).toContain("<b>");
    expect(html).toContain("Dra. Ana Souza");
    expect(html).toContain("CRP 06/12345");

    await u.click(screen.getByRole("button", { name: /Voltar aos resultados/ }));
    await waitFor(() => expect(screen.getByRole("button", { name: new RegExp(`${COD}.*Com conclusão`) })).toBeTruthy(), { timeout: 10000 });
  }, 180000);
});

describe("gerenciar a lista de atendimentos", () => {
  it("retoma uma aplicação abandonada e exclui outra", async () => {
    const u = userEvent.setup();
    const API = "http://127.0.0.1:8000";
    const criar = async (codigo) => (await (await fetch(`${API}/sessoes`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ codigo }) })).json()).id;
    const A = `R-${Date.now() % 100000}`, B = `X-${Date.now() % 100000}`;
    await criar(B); await criar(A);
    render(<App />);
    await u.click(await screen.findByRole("button", { name: `Excluir ${B}` }, { timeout: 40000 }));
    const dlg = screen.getByRole("alertdialog", { name: `Excluir ${B}?` });
    await u.click(within(dlg).getByRole("button", { name: "Excluir" }));
    await screen.findByText(`${B} excluído.`);
    await u.click(screen.getByRole("button", { name: `Retomar ${A}` }));
    expect(await screen.findByLabelText(/Conte, com suas palavras/)).toBeTruthy();       // voltou ao relato, em modo paciente
  }, 120000);
});
