export const API = "http://127.0.0.1:8000";

export async function chamar(caminho, metodo = "GET", corpo) {
  let r;
  try {
    r = await fetch(API + caminho, { method: metodo, headers: { "Content-Type": "application/json" },
      body: corpo ? JSON.stringify(corpo) : undefined });
  } catch {
    throw new Error("Não foi possível falar com o serviço local. Verifique se a API está rodando.");
  }
  const dados = await r.json().catch(() => ({}));
  if (!r.ok) {
    const d = dados.detail;
    throw new Error(typeof d === "string" ? d : d ? JSON.stringify(d) : `Erro ${r.status}`);
  }
  return dados;
}

export const ESCALA = ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"];
export const DIMENSOES = { "Exaustão": "Exaustão", "Distanciamento": "Distanciamento mental", "Cognitivo": "Prejuízo cognitivo", "Emocional": "Prejuízo emocional" };

export const NOMES_CHECAGENS = {
  estrutura_completa: "Estrutura completa",
  sem_diagnostico: "Sem linguagem de diagnóstico",
  tom_de_hipotese: "Tom de hipótese",
  numeros_fieis: "Números fiéis aos dados",
  relato_entre_aspas: "Relato citado",
  fontes_rastreaveis: "Fontes rastreáveis",
  sem_identificacao: "Sem identificação pessoal",
};

export const dataHora = (iso) => iso ? new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";
export const num = (v) => v == null ? "—" : v.toFixed(2).replace(".", ",");
