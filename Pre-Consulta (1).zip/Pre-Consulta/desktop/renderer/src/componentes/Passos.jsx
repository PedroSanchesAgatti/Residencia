import React from "react";

const PASSOS = ["Relato", "Questionário", "Concluído"];

export default function Passos({ atual }) {
  return (
    <nav aria-label="Etapas" className="passos">
      <ol>
        {PASSOS.map((p, i) => (
          <li key={p} className={i < atual ? "feito" : i === atual ? "atual" : ""} aria-current={i === atual ? "step" : undefined}>
            <span className="numero" aria-hidden="true">{i < atual ? "✓" : i + 1}</span>
            <span>{p}</span>
            {i < atual && <span className="visivel-leitor"> (concluída)</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}
