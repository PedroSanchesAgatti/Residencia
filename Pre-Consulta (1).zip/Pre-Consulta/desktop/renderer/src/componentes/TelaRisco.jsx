import React from "react";

export default function TelaRisco({ mensagem, aoEncerrar }) {
  return (
    <section className="cartao alerta" role="alert" aria-labelledby="t-risco">
      <h2 id="t-risco" tabIndex={-1}>Vamos pausar aqui</h2>
      <p>{mensagem}</p>
      <p className="destaque-contato"><b>CVV: 188</b> (24 horas, gratuito) · <b>SAMU: 192</b></p>
      <div className="acoes"><button onClick={aoEncerrar}>Chamar a profissional</button></div>
    </section>
  );
}
