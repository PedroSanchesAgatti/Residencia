import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass, faSpinner, faCircleCheck, faFileSignature, faTriangleExclamation, faHourglassHalf, faPlus, faCircle,
  faPlay, faPen, faTrashCan, faBoxArchive, faBoxOpen } from "@fortawesome/free-solid-svg-icons";
import { chamar, dataHora } from "../api.js";
import Dialogo from "./Dialogo.jsx";

const INCOMPLETOS = ["relato", "perguntas", "questionario"];

function situacao(a) {
  if (a.estado === "interrompida") return { id: "alerta", texto: "Interrompida (alerta de risco)", icone: faTriangleExclamation };
  if (a.docs_estado === "erro") return { id: "erro", texto: "Erro ao gerar documentos", icone: faTriangleExclamation };
  if (a.docs_estado === "processando") return { id: "processando", texto: "Preparando o resumo", icone: faSpinner, girar: true };
  if (a.docs_estado === "resumo") return { id: "resumo", texto: "Resumo pronto · análise em preparo", icone: faSpinner, girar: true };
  if (a.docs_estado === "parcial") return { id: "parcial", texto: "Resumo pronto · análise indisponível", icone: faTriangleExclamation };
  if (a.docs_estado === "aguardando") return { id: "andamento", texto: "Paciente respondendo", icone: faHourglassHalf };
  if (a.tem_conclusao) return { id: "concluida", texto: "Com conclusão", icone: faFileSignature };
  return { id: "pronto", texto: "Pronto para leitura", icone: faCircleCheck };
}

const FILTROS = [["todos", "Todas as situações"], ["novos", "Somente novos"], ["pronto", "Prontos para leitura"], ["resumo", "Resumo pronto"],
  ["concluida", "Com conclusão"], ["andamento", "Em andamento"], ["arquivados", "Arquivados"]];

export default function AreaResultados({ aoAbrir, aoNova, aoRetomar }) {
  const [lista, setLista] = useState(null);
  const [busca, setBusca] = useState("");
  const [filtro, setFiltro] = useState("todos");
  const [erro, setErro] = useState("");
  const [dialogo, setDialogo] = useState(null);       // {tipo: "excluir"|"codigo", a}
  const [aviso, setAviso] = useState("");
  const [versao, setVersao] = useState(0);

  useEffect(() => {
    let vivo = true;
    const carregar = () => chamar(`/atendimentos?busca=${encodeURIComponent(busca)}&arquivadas=${filtro === "arquivados"}`)
      .then((l) => { if (vivo) { setLista(l); setErro(""); } }).catch((e) => vivo && setErro(e.message));
    carregar();
    const t = setInterval(carregar, 4000);                // atualização "ao vivo"
    return () => { vivo = false; clearInterval(t); };
  }, [busca, filtro, versao]);

  const atualizar = (msg) => { setAviso(msg); setVersao((v) => v + 1); };
  async function retomar(a) {
    try { aoRetomar(await chamar(`/sessoes/${a.id}/retomar`)); } catch (x) { setErro(x.message); }
  }
  async function arquivar(a, valor) {
    try { await chamar(`/sessoes/${a.id}`, "PATCH", { arquivada: valor }); atualizar(`${a.codigo} ${valor ? "arquivado" : "desarquivado"}.`); }
    catch (x) { setErro(x.message); }
  }

  const visiveis = (lista || []).filter((a) => {
    const s = situacao(a).id;
    if (filtro === "novos") return !a.visto && ["pronto", "resumo", "parcial"].includes(s);
    if (filtro === "resumo") return ["resumo", "parcial"].includes(s);
    if (filtro === "andamento") return ["andamento", "processando"].includes(s);
    if (filtro === "arquivados") return true;
    return filtro === "todos" || s === filtro;
  });
  const novos = (lista || []).filter((a) => !a.visto && ["pronto", "resumo", "parcial"].includes(situacao(a).id)).length;

  return (
    <section className="cartao largo" aria-labelledby="t-res">
      <div className="cabecalho-docs">
        <h2 id="t-res" tabIndex={-1}>Resultados {novos > 0 && <span className="contagem">{novos} {novos === 1 ? "novo" : "novos"}</span>}</h2>
        <button className="principal" onClick={aoNova}><FontAwesomeIcon icon={faPlus} aria-hidden="true" /> Nova aplicação</button>
      </div>
      <div className="filtros">
        <div className="campo-busca">
          <label htmlFor="busca" className="visivel-leitor">Buscar por código</label>
          <FontAwesomeIcon icon={faMagnifyingGlass} aria-hidden="true" />
          <input id="busca" type="search" placeholder="Buscar por código" value={busca} onChange={(e) => setBusca(e.target.value)} />
        </div>
        <label className="filtro"><span className="visivel-leitor">Filtrar por situação</span>
          <select value={filtro} onChange={(e) => setFiltro(e.target.value)}>
            {FILTROS.map(([v, n]) => <option key={v} value={v}>{n}</option>)}
          </select>
        </label>
      </div>
      {erro && <p className="erro" role="alert">{erro}</p>}
      <p className="visivel-leitor" role="status">{lista ? `${visiveis.length} atendimentos na lista` : "Carregando"}</p>
      {aviso && <p className="aviso-sucesso" role="status">{aviso}</p>}
      {lista && visiveis.length === 0 && <p className="vazio">Nenhum atendimento por aqui ainda. Use “Nova aplicação” para começar.</p>}
      <ul className="atendimentos">
        {visiveis.map((a) => {
          const s = situacao(a);
          const clicavel = ["pronto", "concluida", "resumo", "parcial"].includes(s.id);
          const novo = !a.visto && ["pronto", "resumo", "parcial"].includes(s.id);
          const incompleta = INCOMPLETOS.includes(a.estado);
          return (
            <li key={a.id} className="linha-atendimento">
              <button className={`atendimento ${novo ? "novo" : ""}`} disabled={!clicavel && !incompleta}
                onClick={() => (incompleta ? retomar(a) : aoAbrir(a.id))}
                aria-label={`${a.codigo}. ${s.texto}. ${dataHora(a.finalizada_em || a.criada_em)}${novo ? ". Novo" : ""}${incompleta ? ". Abrir para retomar" : ""}`}>
                <span className="codigo">{novo && <FontAwesomeIcon icon={faCircle} className="ponto-novo" aria-hidden="true" />}{a.codigo}</span>
                <span className={`situacao ${s.id}`}><FontAwesomeIcon icon={s.icone} spin={s.girar} aria-hidden="true" /> {s.texto}</span>
                <span className="data">{dataHora(a.finalizada_em || a.criada_em)}</span>
              </button>
              <div className="acoes-linha" role="group" aria-label={`Ações para ${a.codigo}`}>
                {incompleta
                  ? <button className="icone" title="Retomar a aplicação" aria-label={`Retomar ${a.codigo}`} onClick={() => retomar(a)}>
                      <FontAwesomeIcon icon={faPlay} aria-hidden="true" /></button>
                  : <span className="vaga" aria-hidden="true" />}
                <button className="icone" title="Corrigir código" aria-label={`Corrigir o código de ${a.codigo}`} onClick={() => setDialogo({ tipo: "codigo", a })}>
                  <FontAwesomeIcon icon={faPen} aria-hidden="true" /></button>
                {incompleta && a.docs_estado === "aguardando"
                  ? <button className="icone perigo" title="Excluir aplicação incompleta" aria-label={`Excluir ${a.codigo}`} onClick={() => setDialogo({ tipo: "excluir", a })}>
                      <FontAwesomeIcon icon={faTrashCan} aria-hidden="true" /></button>
                  : <button className="icone" title={a.arquivada ? "Desarquivar" : "Arquivar"} aria-label={`${a.arquivada ? "Desarquivar" : "Arquivar"} ${a.codigo}`}
                      onClick={() => arquivar(a, !a.arquivada)}>
                      <FontAwesomeIcon icon={a.arquivada ? faBoxOpen : faBoxArchive} aria-hidden="true" /></button>}
              </div>
            </li>
          );
        })}
      </ul>
      {dialogo?.tipo === "excluir" && (
        <Dialogo titulo={`Excluir ${dialogo.a.codigo}?`} perigo rotuloConfirmar="Excluir"
          mensagem="A aplicação está incompleta e será apagada de vez, com o relato e as respostas já dadas. Esta ação não pode ser desfeita."
          aoCancelar={() => setDialogo(null)}
          aoConfirmar={async () => { await chamar(`/sessoes/${dialogo.a.id}`, "DELETE"); setDialogo(null); atualizar(`${dialogo.a.codigo} excluído.`); }} />
      )}
      {dialogo?.tipo === "codigo" && (
        <Dialogo titulo="Corrigir código" campo="Código do paciente" valorInicial={dialogo.a.codigo} rotuloConfirmar="Salvar"
          mensagem="Use o mesmo código sempre que for a mesma pessoa, para o histórico ficar junto."
          aoCancelar={() => setDialogo(null)}
          aoConfirmar={async (v) => { await chamar(`/sessoes/${dialogo.a.id}`, "PATCH", { codigo: v }); setDialogo(null); atualizar(`Código corrigido para ${v}.`); }} />
      )}
    </section>
  );
}
