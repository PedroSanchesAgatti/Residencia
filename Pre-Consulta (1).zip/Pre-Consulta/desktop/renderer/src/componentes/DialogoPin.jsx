import React, { useEffect, useRef, useState } from "react";
import { chamar } from "../api.js";

// PIN local para sair do modo paciente: evita acesso acidental aos resultados (não substitui login).
export default function DialogoPin({ aoConfirmar, aoCancelar }) {
  const [pin, setPin] = useState("");
  const [erro, setErro] = useState("");
  const caixa = useRef(null);
  const campo = useRef(null);

  useEffect(() => {
    const anterior = document.activeElement;
    campo.current?.focus();
    const teclado = (e) => {
      if (e.key === "Escape") aoCancelar();
      if (e.key === "Tab") {                                   // mantém o foco dentro do diálogo
        const focaveis = caixa.current.querySelectorAll("input, button");
        const [primeiro, ultimo] = [focaveis[0], focaveis[focaveis.length - 1]];
        if (e.shiftKey && document.activeElement === primeiro) { e.preventDefault(); ultimo.focus(); }
        else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primeiro.focus(); }
      }
    };
    document.addEventListener("keydown", teclado);
    return () => { document.removeEventListener("keydown", teclado); anterior?.focus?.(); };
  }, []);

  async function confirmar(e) {
    e.preventDefault();
    const r = await chamar("/config/pin", "POST", { pin }).catch(() => ({ ok: false }));
    if (r.ok) aoConfirmar(); else { setErro("PIN incorreto."); setPin(""); campo.current?.focus(); }
  }

  return (
    <div className="fundo-dialogo">
      <div className="dialogo" role="dialog" aria-modal="true" aria-labelledby="t-pin" ref={caixa}>
        <h2 id="t-pin">Área da profissional</h2>
        <p className="ajuda">Digite o PIN para voltar aos resultados.</p>
        <form onSubmit={confirmar}>
          <label htmlFor="pin">PIN</label>
          <input id="pin" ref={campo} type="password" inputMode="numeric" autoComplete="off" maxLength={8} value={pin}
            onChange={(e) => setPin(e.target.value)} aria-invalid={!!erro} aria-describedby={erro ? "erro-pin" : undefined} />
          {erro && <p className="erro" id="erro-pin" role="alert">{erro}</p>}
          <div className="acoes"><button type="button" onClick={aoCancelar}>Cancelar</button><button className="principal">Entrar</button></div>
        </form>
      </div>
    </div>
  );
}
