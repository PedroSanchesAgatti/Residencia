import React, { useState } from "react";
import { chamar, ESCALA } from "../api.js";

export default function TelaQuestionario({ sessao, itens, aoConcluir }) {
  const [respostas, setRespostas] = useState({});
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);
  const feitas = Object.keys(respostas).length;
  const completo = feitas === itens.length;

  async function concluir(e) {
    e.preventDefault();
    if (!completo) {
      const primeira = itens.find((i) => !respostas[i.item]);
      setErro(`Faltam ${itens.length - feitas} afirmações.`);
      document.querySelector(`input[name="${primeira.item}"]`)?.focus();
      return;
    }
    setEnviando(true); setErro("");
    try { await chamar(`/sessoes/${sessao.id}/respostas`, "POST", { respostas }); aoConcluir(); }
    catch (x) { setErro(x.message); setEnviando(false); }
  }

  return (
    <section className="cartao" aria-labelledby="t-quest">
      <h2 id="t-quest" tabIndex={-1}>Questionário</h2>
      <p className="ajuda">As afirmações se referem à sua situação de trabalho. Indique com que frequência cada uma se aplica a você.</p>
      <div className="progresso-linha">
        <label htmlFor="prog">{feitas} de {itens.length} respondidas</label>
        <progress id="prog" max={itens.length} value={feitas} />
      </div>
      <form onSubmit={concluir} noValidate>
        {itens.map((it, k) => (
          <fieldset key={it.item} className={`item ${respostas[it.item] ? "respondido" : ""}`}>
            <legend><span className="numero-item">{k + 1}</span> {it.texto}</legend>
            <div className="escala">
              {ESCALA.map((nome, v) => (
                <label key={nome} className="opcao">
                  <input type="radio" name={it.item} value={v + 1} checked={respostas[it.item] === v + 1}
                    onChange={() => setRespostas({ ...respostas, [it.item]: v + 1 })} />
                  <span className="opcao-caixa"><b>{v + 1}</b><span>{nome}</span></span>
                </label>
              ))}
            </div>
          </fieldset>
        ))}
        {erro && <p className="erro" role="alert">{erro}</p>}
        <div className="acoes">
          <button className="principal" disabled={enviando} aria-disabled={!completo}>
            {enviando ? "Registrando…" : "Concluir questionário"}
          </button>
        </div>
      </form>
    </section>
  );
}
