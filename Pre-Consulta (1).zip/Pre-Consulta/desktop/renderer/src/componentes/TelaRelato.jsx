import React, { useState } from "react";
import { chamar } from "../api.js";

const PERGUNTA_INICIAL = "Conte, com suas palavras, o que trouxe você aqui e como tem se sentido no trabalho.";

export default function TelaRelato({ sessao, pergunta, restantes, aoPerguntar, aoItens, aoRisco }) {
  const [texto, setTexto] = useState("");
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);
  const extra = Boolean(pergunta);
  const numeroExtra = extra ? 2 - restantes : 0;

  async function enviar(e) {
    e.preventDefault();
    if (!texto.trim()) { setErro("Escreva uma resposta para continuar."); return; }
    setEnviando(true); setErro("");
    try {
      const r = await chamar(`/sessoes/${sessao.id}/relato`, "POST", { texto: texto.trim() });
      if (r.estado === "interrompida") return aoRisco(r.mensagem);
      if (r.estado === "perguntas") return aoPerguntar(r.pergunta, r.restantes);
      aoItens(r.itens);
    } catch (x) { setErro(x.message); setEnviando(false); }
  }

  return (
    <section className="cartao" aria-labelledby="t-relato" aria-busy={enviando}>
      <h2 id="t-relato" tabIndex={-1}>{extra ? "Só mais uma pergunta" : "Relato"}</h2>
      {extra && <p className="etiqueta">Pergunta extra {numeroExtra} de 2</p>}
      <form onSubmit={enviar} noValidate>
        <label htmlFor="resposta" className="enunciado">{extra ? pergunta : PERGUNTA_INICIAL}</label>
        <p className="ajuda" id="dica-resposta">Não há resposta certa. Escreva como preferir; frases curtas também funcionam.</p>
        <textarea id="resposta" className={`campo-resposta ${texto ? "preenchido" : ""}`} value={texto} rows={6}
          onChange={(e) => setTexto(e.target.value)} disabled={enviando}
          aria-describedby={`dica-resposta${erro ? " erro-relato" : ""}`} aria-invalid={!!erro} />
        <p className="contador" aria-hidden="true">{texto.length} caracteres</p>
        {erro && <p className="erro" id="erro-relato" role="alert">{erro}</p>}
        <p className="visivel-leitor" role="status">{enviando ? "Analisando o relato, aguarde." : ""}</p>
        <div className="acoes">
          <button className="principal" disabled={enviando}>
            {enviando ? <><span className="girando" aria-hidden="true" /> Analisando…</> : "Continuar"}
          </button>
        </div>
      </form>
    </section>
  );
}
