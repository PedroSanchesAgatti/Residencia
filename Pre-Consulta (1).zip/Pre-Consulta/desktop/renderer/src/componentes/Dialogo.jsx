import React, { useEffect, useRef, useState } from "react";

// Diálogo acessível reutilizável: confirmação ou campo de texto. Foco preso dentro; Esc fecha.
export default function Dialogo({ titulo, mensagem, campo, valorInicial = "", rotuloConfirmar = "Confirmar", perigo = false,
                                  aoConfirmar, aoCancelar }) {
  const [valor, setValor] = useState(valorInicial);
  const [erro, setErro] = useState("");
  const caixa = useRef(null);
  const primeiro = useRef(null);

  useEffect(() => {
    const anterior = document.activeElement;
    primeiro.current?.focus();
    const teclado = (e) => {
      if (e.key === "Escape") aoCancelar();
      if (e.key === "Tab") {
        const f = caixa.current.querySelectorAll("input, button");
        if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
      }
    };
    document.addEventListener("keydown", teclado);
    return () => { document.removeEventListener("keydown", teclado); anterior?.focus?.(); };
  }, []);

  async function confirmar(e) {
    e.preventDefault();
    if (campo && !valor.trim()) { setErro("Preencha o campo."); return; }
    try { await aoConfirmar(valor.trim()); } catch (x) { setErro(x.message); }
  }

  return (
    <div className="fundo-dialogo">
      <div className="dialogo" role={perigo ? "alertdialog" : "dialog"} aria-modal="true" aria-labelledby="t-dialogo" aria-describedby="m-dialogo" ref={caixa}>
        <h2 id="t-dialogo">{titulo}</h2>
        <p className="ajuda" id="m-dialogo">{mensagem}</p>
        <form onSubmit={confirmar}>
          {campo && <>
            <label htmlFor="campo-dialogo">{campo}</label>
            <input id="campo-dialogo" ref={primeiro} value={valor} maxLength={40} onChange={(e) => setValor(e.target.value)} />
          </>}
          {erro && <p className="erro" role="alert">{erro}</p>}
          <div className="acoes">
            <button type="button" onClick={aoCancelar} ref={campo ? undefined : primeiro}>Cancelar</button>
            <button className={perigo ? "perigo" : "principal"}>{rotuloConfirmar}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
