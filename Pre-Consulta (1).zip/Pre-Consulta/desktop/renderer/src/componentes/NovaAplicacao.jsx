import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserPen, faWindowRestore } from "@fortawesome/free-solid-svg-icons";
import { chamar } from "../api.js";

export default function NovaAplicacao({ aoIniciarAqui, aoAbrirJanela }) {
  const [form, setForm] = useState({ codigo: "" });
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);
  const mudar = (campo) => (e) => setForm({ ...form, [campo]: e.target.value });

  async function criar(ondeAbrir) {
    if (!form.codigo.trim()) { setErro("Informe o código da pessoa para continuar."); document.getElementById("codigo")?.focus(); return; }
    setEnviando(true); setErro("");
    try {
      const r = await chamar("/sessoes", "POST", { codigo: form.codigo.trim() });
      const sessao = { id: r.id, codigo: r.codigo };
      if (ondeAbrir === "janela") {
        if (window.desktop?.abrirPaciente) await window.desktop.abrirPaciente(sessao.id, sessao.codigo);
        else window.open(`${window.location.pathname}?modo=paciente&sid=${sessao.id}&codigo=${encodeURIComponent(sessao.codigo)}`, "_blank");
        aoAbrirJanela();
      } else aoIniciarAqui(sessao);
    } catch (x) { setErro(x.message); setEnviando(false); }
  }

  return (
    <section className="cartao" aria-labelledby="t-nova">
      <h2 id="t-nova" tabIndex={-1}>Nova aplicação</h2>
      <p className="ajuda">Prepare a aplicação e entregue o dispositivo ao paciente. Por privacidade, o sistema usa só o código do paciente; a profissional se identifica na assinatura da conclusão.</p>
      <form onSubmit={(e) => { e.preventDefault(); criar("aqui"); }} noValidate>
        <div className="campo">
          <label htmlFor="codigo">Código da pessoa <span className="obrigatorio">(obrigatório)</span></label>
          <input id="codigo" value={form.codigo} onChange={mudar("codigo")} placeholder="ex.: P-0001" autoComplete="off" maxLength={40}
            aria-invalid={!!erro && !form.codigo.trim()} aria-describedby={erro ? "erro-nova" : "dica-codigo"} />
          <p className="ajuda pequena" id="dica-codigo">Use sempre o mesmo código para a mesma pessoa: assim você acompanha a evolução.</p>
        </div>
        {erro && <p className="erro" id="erro-nova" role="alert">{erro}</p>}
        <div className="acoes">
          <button type="button" disabled={enviando} onClick={() => criar("janela")}>
            <FontAwesomeIcon icon={faWindowRestore} aria-hidden="true" /> Abrir em nova janela
          </button>
          <button className="principal" disabled={enviando}>
            <FontAwesomeIcon icon={faUserPen} aria-hidden="true" /> Iniciar nesta tela
          </button>
        </div>
      </form>
    </section>
  );
}
