import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart } from "@fortawesome/free-solid-svg-icons";

export default function TelaAgradecimento({ aoEncerrar }) {
  return (
    <section className="cartao agradecimento" aria-labelledby="t-obrigado">
      <FontAwesomeIcon icon={faHeart} className="icone-grande" aria-hidden="true" />
      <h2 id="t-obrigado" tabIndex={-1}>Obrigado por responder</h2>
      <p>Suas respostas foram enviadas com segurança para a profissional responsável pelo seu atendimento.</p>
      <p>Ela vai ler o que você contou e conversar com você sobre isso na consulta. Este questionário é uma etapa de
        preparação: <b>não é um diagnóstico</b>, e nenhuma decisão é tomada sem essa conversa.</p>
      <p className="ajuda">Se em algum momento você precisar de apoio imediato, o CVV atende 24 horas pelo telefone 188, de graça.</p>
      <div className="acoes"><button className="principal" onClick={aoEncerrar}>Concluir e devolver o dispositivo</button></div>
    </section>
  );
}
