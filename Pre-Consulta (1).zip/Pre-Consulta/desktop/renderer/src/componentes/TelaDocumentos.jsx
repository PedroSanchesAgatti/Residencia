import React, { useEffect, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faPrint, faFilePdf, faRotate, faFloppyDisk } from "@fortawesome/free-solid-svg-icons";
import { API, chamar, NOMES_CHECAGENS, DIMENSOES, dataHora, num } from "../api.js";

const ABAS = [
  { id: "relatorio", nome: "Resumo de pré-consulta" },
  { id: "analise", nome: "Análise de apoio (IA)" },
];

function Checagens({ info }) {
  if (!info) return null;
  const itens = Object.entries(info.checagens).filter(([k]) => k !== "aprovado");
  return (
    <details className="checagens">
      <summary>
        <span className={`selo-check ${info.checagens.aprovado ? "ok" : "pendente"}`}>
          {info.checagens.aprovado ? "✓ Checagens aprovadas" : "! Checagens com pendências"}
        </span>
        <span className="origem">Texto: {info.origem}</span>
      </summary>
      <ul>
        {itens.map(([k, v]) => <li key={k} className={v ? "ok" : "falha"}><span aria-hidden="true">{v ? "✓" : "✗"}</span> {NOMES_CHECAGENS[k] || k}<span className="visivel-leitor">{v ? ": aprovado" : ": reprovado"}</span></li>)}
        {info.revisao?.problemas?.length > 0 && <li className="nota">Revisor: {info.revisao.problemas.join("; ")}</li>}
      </ul>
    </details>
  );
}

function Historico({ codigo, atual }) {
  const [hist, setHist] = useState([]);
  useEffect(() => { chamar(`/pacientes/${encodeURIComponent(codigo)}/historico`).then(setHist).catch(() => {}); }, [codigo]);
  if (hist.length < 2) return null;
  return (
    <details className="historico">
      <summary>Histórico de {codigo}: {hist.length} aplicações</summary>
      <div className="rolagem">
        <table>
          <caption className="visivel-leitor">Escores estimados por aplicação</caption>
          <thead><tr><th scope="col">Data</th>{Object.values(DIMENSOES).map((d) => <th scope="col" key={d}>{d}</th>)}</tr></thead>
          <tbody>
            {hist.map((h) => (
              <tr key={h.id} className={h.id === atual ? "atual" : ""}>
                <th scope="row">{dataHora(h.data)}{h.id === atual && <span className="visivel-leitor"> (esta aplicação)</span>}</th>
                {Object.keys(DIMENSOES).map((d) => <td key={d}>{num(h.escores[d])}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </details>
  );
}

function EditorConclusao({ sid, aoSalvar }) {
  // A identificação da profissional entra aqui, na assinatura, e fica lembrada neste computador.
  const lembrada = JSON.parse(localStorage.getItem("assinatura") || "{}");
  const [texto, setTexto] = useState("");
  const [nome, setNome] = useState(lembrada.nome || "");
  const [crp, setCrp] = useState(lembrada.crp || "");
  const [estado, setEstado] = useState("");
  useEffect(() => {
    chamar(`/sessoes/${sid}/conclusao`).then((c) => {
      setTexto(c.texto || "");
      if (c.profissional_nome) { setNome(c.profissional_nome); setCrp(c.profissional_crp); }
    });
  }, [sid]);

  async function salvar(e) {
    e.preventDefault();
    if (!texto.trim()) { setEstado("Escreva a conclusão antes de salvar."); return; }
    if (nome.trim().length < 3 || crp.trim().length < 3) { setEstado("Informe seu nome e CRP para assinar."); return; }
    setEstado("Salvando…");
    try {
      await chamar(`/sessoes/${sid}/conclusao`, "PUT", { texto: texto.trim(), profissional_nome: nome.trim(), profissional_crp: crp.trim() });
      localStorage.setItem("assinatura", JSON.stringify({ nome: nome.trim(), crp: crp.trim() }));
      setEstado(`Salvo e assinado às ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}. O documento foi atualizado.`);
      aoSalvar();
    } catch (x) { setEstado(x.message); }
  }

  return (
    <form className="conclusao-editor" onSubmit={salvar}>
      <label htmlFor="conclusao">5. Conclusão <span className="ajuda-inline">(escrita somente pela profissional; nenhuma IA lê ou altera este campo)</span></label>
      <textarea id="conclusao" rows={5} value={texto} onChange={(e) => setTexto(e.target.value)} aria-describedby="estado-conclusao"
        placeholder="Conclusões a partir da análise, orientações e encaminhamentos." />
      <fieldset className="assinatura-campos">
        <legend>Assinatura</legend>
        <div className="grade-2">
          <div className="campo"><label htmlFor="assinatura-nome">Nome completo</label>
            <input id="assinatura-nome" value={nome} onChange={(e) => setNome(e.target.value)} autoComplete="name" /></div>
          <div className="campo"><label htmlFor="assinatura-crp">CRP</label>
            <input id="assinatura-crp" value={crp} onChange={(e) => setCrp(e.target.value)} placeholder="ex.: 06/12345" /></div>
        </div>
      </fieldset>
      <div className="acoes compacto">
        <p id="estado-conclusao" role="status" className="estado">{estado}</p>
        <button className="principal"><FontAwesomeIcon icon={faFloppyDisk} aria-hidden="true" /> Salvar e assinar</button>
      </div>
    </form>
  );
}

export default function TelaDocumentos({ sid, aoVoltar }) {
  const [aba, setAba] = useState("relatorio");
  const [info, setInfo] = useState(null);
  const [versao, setVersao] = useState(0);
  const [refazendo, setRefazendo] = useState(false);
  const botoes = useRef([]);

  const carregar = () => chamar(`/sessoes/${sid}`).then(setInfo);
  useEffect(() => { carregar(); chamar(`/sessoes/${sid}/visto`, "POST").catch(() => {}); }, [sid]);
  // Enquanto a análise de apoio está em preparo, consulta a cada 5 s e mostra assim que ficar pronta.
  const emPreparo = info && ["processando", "resumo"].includes(info.docs_estado);
  useEffect(() => {
    if (!emPreparo) return;
    const t = setInterval(() => chamar(`/sessoes/${sid}`).then((n) => { setInfo(n); if (n.analise) setVersao((v) => v + 1); }), 5000);
    return () => clearInterval(t);
  }, [emPreparo, sid]);

  function teclado(e, i) {
    const n = ABAS.length;
    const j = { ArrowRight: (i + 1) % n, ArrowLeft: (i - 1 + n) % n, Home: 0, End: n - 1 }[e.key];
    if (j !== undefined) { e.preventDefault(); setAba(ABAS[j].id); botoes.current[j]?.focus(); }
  }

  async function refazerAnalise() {
    setRefazendo(true);
    try { await chamar(`/sessoes/${sid}/analise`, "POST"); await carregar(); setVersao((v) => v + 1); }
    finally { setRefazendo(false); }
  }

  if (!info) return <section className="cartao" aria-busy="true"><h2 tabIndex={-1}>Carregando…</h2></section>;
  const infoAba = aba === "relatorio" ? info.resumo : info.analise;
  const titulo = ABAS.find((a) => a.id === aba).nome;

  return (
    <section className="cartao largo" aria-labelledby="t-docs">
      <button className="voltar" onClick={aoVoltar}><FontAwesomeIcon icon={faArrowLeft} aria-hidden="true" /> Voltar aos resultados</button>
      <div className="cabecalho-docs">
        <h2 id="t-docs" tabIndex={-1}>{info.codigo}</h2>
        <span className="ajuda">Respondido em {dataHora(info.finalizada_em)}</span>
      </div>
      <Historico codigo={info.codigo} atual={info.id} />
      <div role="tablist" aria-label="Documentos" className="abas">
        {ABAS.map((a, i) => (
          <button key={a.id} role="tab" id={`aba-${a.id}`} aria-selected={aba === a.id} aria-controls={`painel-${a.id}`}
            tabIndex={aba === a.id ? 0 : -1} ref={(el) => (botoes.current[i] = el)}
            onClick={() => setAba(a.id)} onKeyDown={(e) => teclado(e, i)}>{a.nome}</button>
        ))}
      </div>
      <div role="tabpanel" id={`painel-${aba}`} aria-labelledby={`aba-${aba}`} className="painel">
        <Checagens info={infoAba} />
        {aba === "analise" && <p className="aviso-ia">Leitura de apoio gerada por IA, com referências bibliográficas. Traz hipóteses e sugestões, não diagnóstico.</p>}
        {infoAba
          ? <iframe key={`${aba}-${versao}`} title={titulo} src={`${API}/sessoes/${sid}/${aba}.html`} className="documento" />
          : <p className="vazio" role="status">
              {aba === "analise" && emPreparo ? <><FontAwesomeIcon icon={faRotate} spin aria-hidden="true" /> A análise de apoio está sendo escrita pela IA local. Ela aparece aqui sozinha assim que ficar pronta; enquanto isso, o resumo já pode ser lido.</>
                : aba === "analise" ? "A análise de apoio não pôde ser gerada. Use “Gerar análise novamente”." : "Documento ainda não disponível."}
            </p>}
        {aba === "relatorio" && info.resumo && <EditorConclusao sid={sid} aoSalvar={() => { setVersao((v) => v + 1); carregar(); }} />}
        <div className="acoes">
          {aba === "analise" && !emPreparo && <button onClick={refazerAnalise} disabled={refazendo}><FontAwesomeIcon icon={faRotate} spin={refazendo} aria-hidden="true" /> {refazendo ? "Gerando…" : "Gerar análise novamente"}</button>}
          <button onClick={() => window.desktop?.imprimir(sid, aba)} disabled={!window.desktop || !infoAba}><FontAwesomeIcon icon={faPrint} aria-hidden="true" /> Imprimir</button>
          <button className="principal" disabled={!window.desktop || !infoAba}
            onClick={async () => { const c = await window.desktop?.salvarPdf(sid, info.codigo, aba); if (c) alert(`PDF salvo em:\n${c}`); }}>
            <FontAwesomeIcon icon={faFilePdf} aria-hidden="true" /> Salvar PDF
          </button>
        </div>
      </div>
    </section>
  );
}
