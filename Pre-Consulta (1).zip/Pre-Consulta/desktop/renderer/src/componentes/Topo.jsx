import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSun, faMoon, faCircleHalfStroke, faInbox, faPlus, faRightFromBracket, faTriangleExclamation } from "@fortawesome/free-solid-svg-icons";

const TEMAS = [
  { id: "claro", nome: "Tema claro", icone: faSun },
  { id: "sistema", nome: "Tema automático (segue o sistema)", icone: faCircleHalfStroke },
  { id: "escuro", nome: "Tema escuro", icone: faMoon },
];

export default function Topo({ modo, tela, aoNavegar, aoSairPaciente, erroApi, avisoIA }) {
  const [tema, setTema] = useState(() => localStorage.getItem("tema") || "sistema");
  useEffect(() => { document.documentElement.dataset.tema = tema; localStorage.setItem("tema", tema); }, [tema]);

  return (
    <header className="topo">
      <h1 className="visivel-leitor">BAT · pré-consulta</h1>
      <span className="logo" aria-hidden="true">BAT</span>

      {modo === "profissional" && (
        <nav aria-label="Área da profissional" className="navegacao">
          <button className={tela !== "nova" ? "ativo" : ""} aria-current={tela !== "nova" ? "page" : undefined} onClick={() => aoNavegar("resultados")}>
            <FontAwesomeIcon icon={faInbox} aria-hidden="true" /> Resultados
          </button>
          <button className={tela === "nova" ? "ativo" : ""} aria-current={tela === "nova" ? "page" : undefined} onClick={() => aoNavegar("nova")}>
            <FontAwesomeIcon icon={faPlus} aria-hidden="true" /> Nova aplicação
          </button>
        </nav>
      )}

      <div className="topo-direita">
        {erroApi && <p className="aviso-erro" role="alert"><FontAwesomeIcon icon={faTriangleExclamation} aria-hidden="true" /> Serviço local indisponível</p>}
        {avisoIA && <p className="aviso-erro" role="status" title="Abra o app Ollama ou configure a chave da Anthropic no .env. Enquanto isso, os documentos usam o texto padrão."><FontAwesomeIcon icon={faTriangleExclamation} aria-hidden="true" /> IA indisponível</p>}
        {modo === "paciente" && (
          <button className="discreto" onClick={aoSairPaciente}>
            <FontAwesomeIcon icon={faRightFromBracket} aria-hidden="true" /> <span className="visivel-leitor">Sair do modo paciente</span>
          </button>
        )}
        <div role="radiogroup" aria-label="Tema" className="temas">
          {TEMAS.map((t) => (
            <button key={t.id} role="radio" aria-checked={tema === t.id} aria-label={t.nome} title={t.nome}
              onClick={() => setTema(t.id)}
              onKeyDown={(e) => {
                const i = TEMAS.findIndex((x) => x.id === tema);
                if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                  e.preventDefault();
                  const prox = TEMAS[(i + (e.key === "ArrowRight" ? 1 : TEMAS.length - 1)) % TEMAS.length];
                  setTema(prox.id);
                  e.currentTarget.parentElement.querySelector(`[aria-label="${prox.nome}"]`)?.focus();
                }
              }}
              tabIndex={tema === t.id ? 0 : -1}>
              <FontAwesomeIcon icon={t.icone} aria-hidden="true" />
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
