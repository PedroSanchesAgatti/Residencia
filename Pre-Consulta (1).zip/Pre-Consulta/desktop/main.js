// Processo principal do Electron: sobe a API local (FastAPI) e abre a interface React.
const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

const RAIZ = path.resolve(__dirname, "..");
const API = "http://127.0.0.1:8000";
let api = null;

function pythonDoProjeto() {
  const venv = process.platform === "win32" ? [".venv", "Scripts", "python.exe"] : [".venv", "bin", "python"];
  const caminho = path.join(RAIZ, ...venv);
  return fs.existsSync(caminho) ? caminho : (process.platform === "win32" ? "python" : "python3");
}

async function apiNoAr() {
  try { return (await fetch(`${API}/saude`)).ok; } catch { return false; }
}

async function iniciarApi() {
  if (process.env.BAT_API_EXTERNA || (await apiNoAr())) return;   // já rodando (ex.: depuração no VS Code)
  api = spawn(pythonDoProjeto(), ["-m", "uvicorn", "api.main:app", "--port", "8000"], { cwd: RAIZ });
  api.stdout.on("data", (d) => process.stdout.write(`[api] ${d}`));
  api.stderr.on("data", (d) => process.stdout.write(`[api] ${d}`));
}

async function criarJanela(query) {
  const janela = new BrowserWindow({
    width: query ? 900 : 1180, height: 860, minWidth: 420, minHeight: 560, title: query ? "BAT · paciente" : "Pre-Consulta",
    backgroundColor: "#f6f7fb", show: false,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false },
  });
  janela.once("ready-to-show", () => janela.show());
  if (process.env.BAT_VITE_URL) await janela.loadURL(process.env.BAT_VITE_URL + (query ? `?${new URLSearchParams(query)}` : ""));
  else await janela.loadFile(path.join(__dirname, "ui-dist", "index.html"), query ? { query } : undefined);
  return janela;
}

// Janela separada só para o paciente (ótima para a apresentação: lado a lado com a área da profissional)
ipcMain.handle("abrir-paciente", async (_e, sid, codigo) => {
  await criarJanela({ modo: "paciente", sid: String(sid), codigo: String(codigo) });
  return true;
});

async function janelaDoDocumento(sid, tipo) {
  const w = new BrowserWindow({ show: false });
  await w.loadURL(`${API}/sessoes/${sid}/${tipo === "analise" ? "analise" : "relatorio"}.html`);
  return w;
}

const RODAPE = (titulo) => `<div style="font-size:8px;width:100%;text-align:center;color:#555;font-family:sans-serif">${titulo} · sigiloso · página <span class="pageNumber"></span> de <span class="totalPages"></span></div>`;

ipcMain.handle("salvar-pdf", async (_e, sid, codigo, tipo) => {
  const w = await janelaDoDocumento(sid, tipo);
  const titulo = tipo === "analise" ? "Análise de apoio" : "Resumo de pré-consulta";
  const pdf = await w.webContents.printToPDF({ pageSize: "A4", printBackground: true, displayHeaderFooter: true,
    headerTemplate: "<span></span>", footerTemplate: RODAPE(titulo) });
  w.close();
  const { canceled, filePath } = await dialog.showSaveDialog({
    defaultPath: `${tipo === "analise" ? "analise" : "resumo"}_${codigo}.pdf`, filters: [{ name: "PDF", extensions: ["pdf"] }] });
  if (canceled) return null;
  fs.writeFileSync(filePath, pdf);
  return filePath;
});

ipcMain.handle("imprimir", async (_e, sid, tipo) => {
  const w = await janelaDoDocumento(sid, tipo);
  w.webContents.print({ printBackground: true }, () => w.close());
});

app.whenReady().then(async () => { await iniciarApi(); criarJanela(); });
app.on("window-all-closed", () => app.quit());
app.on("quit", () => { if (api) api.kill(); });
