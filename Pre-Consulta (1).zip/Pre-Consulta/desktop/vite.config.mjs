import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// A interface React fica em renderer/ e é gerada em ui-dist/, que o Electron carrega.
export default defineConfig({
  root: "renderer",
  base: "./",
  plugins: [react()],
  build: { outDir: "../ui-dist", emptyOutDir: true },
  server: { port: 5173, strictPort: true },
  test: { environment: "jsdom", root: ".", include: ["renderer/src/**/*.test.jsx"], testTimeout: 60000 },
});
