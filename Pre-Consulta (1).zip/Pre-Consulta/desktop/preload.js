const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("desktop", {
  salvarPdf: (sid, codigo, tipo) => ipcRenderer.invoke("salvar-pdf", sid, codigo, tipo),
  imprimir: (sid, tipo) => ipcRenderer.invoke("imprimir", sid, tipo),
  abrirPaciente: (sid, codigo) => ipcRenderer.invoke("abrir-paciente", sid, codigo),
});
