# Pre-Consulta · BAT com IA local

## Instalação rápida

**Windows:** instale Python 3.11 ou 3.12 (marcando "Add python.exe to PATH"), Node.js LTS e Ollama. Depois,
na pasta do projeto, dê dois cliques em **`instalar.bat`** (cria o `.venv`, instala tudo, baixa o modelo
qwen2.5:7b e roda os testes). Para usar: dois cliques em **`iniciar.bat`**.

**macOS / Linux:** instale Python, Node.js e Ollama; depois `./instalar.sh` e, para usar, `./iniciar.sh`.

O arquivo **`.env`** já vem configurado para o modelo 7B. O `.venv` não vai no zip porque é específico de
cada sistema e de cada pasta: o script de instalação o cria na hora.

> **O que muda na versão 2:** todos os agentes usam modelos de linguagem **locais**, pelo **Ollama**.
> Não há chave de API nem chamada a serviço externo: relato, respostas e documentos **nunca saem do
> computador**. A versão 1 (com a API da Anthropic) continua na pasta `bat-pre-consulta`.

## IA local: instalação (uma vez)

1. Instale o Ollama: baixe em https://ollama.com (app para macOS) ou rode `brew install ollama`.
2. Abra o app Ollama (ele fica na barra de menus) ou rode `ollama serve` num terminal.
3. Baixe os modelos:
   ```bash
   ollama pull qwen2.5:7b      # ~4,7 GB: analista e relator (rápido)
   ollama pull qwen2.5:14b     # ~9 GB: análise de apoio e revisor (mais qualidade)
   ```
4. Confira e meça os tempos: `python scripts/verificar_ollama.py`.

**Memória:** pensado para um Mac com chip M e 18 GB. O modelo rápido fica carregado (30 min); o modelo
da análise é carregado só quando o agente de apoio trabalha e liberado 2 minutos depois. Com 8 GB, use
`OLLAMA_MODELO_APOIO=qwen2.5:7b` no `.env`.

**Tempos esperados (M3 Pro):** relato de 5 a 15 s (o paciente espera); documentos de 1 a 3 min, em segundo
plano. A primeira análise do dia demora mais, porque o modelo grande precisa ser carregado.

**Sem o Ollama ligado**, nada quebra: o topo do app avisa "IA local desligada", e os agentes usam o
modo simulado (RAG e textos padrão do código).

**Como os agentes usam o modelo local:** cada agente envia ao Ollama o formato JSON esperado (saída
estruturada); se a resposta vier inválida, o sistema tenta mais uma vez. O agente de apoio escreve em
duas etapas (roteiro e depois o texto), o que melhora bastante a qualidade em modelos menores.

---


Protótipo da Residência IA (entregável das semanas 3 e 4). Roda **só localmente**.

A pessoa conta com as próprias palavras como está; um agente lê o relato (com até 2 perguntas extras),
o RAG liga as falas aos itens do BAT, regras escolhem 8 itens, uma **rede neural com máscara** estima os
4 escores e um agente relator monta um **resumo de pré-consulta** imprimível para a profissional, seguindo
a Resolução CFP 06/2019 (com o RAG de normas) e passando por checagens automáticas.

> Triagem, não diagnóstico. A conclusão é sempre da profissional responsável.

## Arquitetura

```
Pergunta aberta → Regra fixa de risco → Agente analista (risco + indícios) ⇄ RAG de itens → Seletor (regras, 8 itens)
→ Questionário → Rede neural com máscara → Agente relator ⇄ RAG de normas → Validação
→ Agente de apoio ⇄ RAG científico → Agente revisor → Validação → Profissional (conclusão)
```

| Pasta | Conteúdo |
|---|---|
| `api/` | FastAPI: fluxo, agentes (`agentes/`), RAG (`rag/`), seletor, rede, validação, banco SQLite |
| `desktop/` | App Electron com interface React (`renderer/`), impressão e PDF (`printToPDF`) |
| `painel/` | Painel técnico em Streamlit: raio-X das sessões e teste do RAG |
| `scripts/` | Treino da rede com máscara e avaliação do RAG |
| `conhecimento/` | Base do RAG: itens e expressões, normas, ciência (resumos + PDFs) e relatos de teste |
| `modelos/` | Rede treinada e regras |
| `tests/` | Testes do fluxo completo em modo simulado |

## Primeiros passos (VS Code)

1. Abra a pasta no VS Code e instale as extensões recomendadas.
2. **Terminal → Executar tarefa → "1. Criar ambiente Python"** (ou manualmente:
   `python3 -m venv .venv` e `.venv/bin/pip install -r requirements.txt`; no Windows, `.venv\Scripts\pip`).
3. **"2. Instalar Electron"** (precisa do Node.js 18+). Instala também React e Vite.
4. (Opcional) copie `.env.example` para `.env` para trocar modelos ou tempos. Nenhuma chave é necessária.
5. **"Rodar testes"**: devem passar 41 testes do backend (em modo simulado). Com o Ollama ligado,
   `OLLAMA_REAL=1 python -m pytest tests/test_ollama_real.py -s` testa o modelo de verdade.
6. Para usar: **"Abrir app desktop"** (sobe a API sozinho) ou, para depurar, a configuração
   **"Tudo: API + app desktop"** no painel Executar e Depurar (F5).
7. Painel técnico: configuração **"Painel técnico (Streamlit)"**, com a API ligada.

Na primeira execução, o `sentence-transformers` baixa o modelo de embeddings (cerca de 470 MB). Sem ele, o
sistema cai para TF-IDF, que serve só para testes; o painel e a rota `/saude` mostram qual está em uso.

## Ética e privacidade (versão 2.1)

- **Sem nome do paciente:** o sistema trabalha só com o código; nenhum nome é pedido nem guardado.
- **Profissional identificada na assinatura:** o formulário inicial não pede o nome da profissional. Ela
  informa nome e CRP ao salvar a conclusão, e eles aparecem na assinatura do resumo (ficam lembrados no computador).
- **Risco à vida em duas camadas:** uma regra fixa roda em todo texto, instantaneamente e sem IA; o agente
  analista, que assumiu o papel do antigo agente guardião, detecta também frases indiretas. Uma chamada ao
  modelo a menos por relato.
- **Resumo antes da análise:** assim que o resumo fica pronto, a profissional já pode lê-lo; a análise de apoio
  chega depois, sozinha. Se só a análise falhar, o resumo continua disponível ("análise indisponível").

## Modo automático: IA local ou na nuvem (versão 2.4)

No `.env`, `LLM_MODO` escolhe de onde vem a IA:

| Modo | Como funciona | Quando usar |
|---|---|---|
| `automatico` (padrão) | Tenta o Ollama; se ele falhar (falta de memória, desligado, lento), usa a Anthropic e pula o Ollama por 10 minutos | Qualquer máquina: no MacBook roda local; num notebook com pouca memória, cai para a nuvem |
| `ollama` | Só local | Quando os dados não podem sair do computador |
| `anthropic` | Só a Anthropic | Máquinas sem memória para modelos locais |
| `simulado` | Sem IA | Testes e plano B |

Para usar a Anthropic, cole a chave em `ANTHROPIC_API_KEY` no `.env`. Sem a chave, o automático funciona como
`ollama`. Os documentos indicam no fim se o texto veio da "IA local" ou da "IA na nuvem (Anthropic)".
Atenção: na nuvem, o relato e os escores (sem nome do paciente) saem do computador; use só dados simulados.

## Relato × respostas (versão 2.2)

O código compara a força dos indícios que o analista encontrou no relato com os escores das respostas.
**Divergências só aparecem quando são muito grandes**, para não virar hábito:
- o relato descreve uma dimensão com muita clareza, mas as respostas ficaram muito baixas;
- o relato não tem relação com os temas avaliados (a pessoa pode ter se confundido com a tarefa, por
  exemplo por pouca familiaridade com tecnologia), mas as respostas são altas em várias dimensões.

Nesses casos, o resumo registra a divergência de forma descritiva e a análise de apoio a explica livremente,
com hipóteses e sugestões. Respostas altas num tema que o relato não citou viram só um achado complementar,
sem alerta. A comparação só é feita quando as forças vêm do modelo de linguagem.

Também nesta versão: perguntas extras só para relatos realmente vagos, sempre de uma lista aprovada;
dimensões que o relato não indica ficam só com o item mínimo; trechos destacados não atravessam pontuação.

## Qualidade da análise de apoio (versão 2.3)

- **Hipóteses permitidas, gravidade não:** "sugere um quadro de burnout ocupacional" passa; "estágio avançado",
  "burnout grave", "corrobora" ou "confirma" são barrados pelas checagens.
- **Revisor com lista de conferência:** verifica se cada afirmação sobre o relato está no relato, se nada
  contradiz os fatos do BAT (quatro dimensões centrais) e se cada seção está no formato certo.
- **Trechos conferidos pela frase:** um trecho só é ligado a um item se a frase onde ele está combina com a
  dimensão do item (ex.: "fico triste sem saber explicar" não vira prejuízo cognitivo).
- **Seções no lugar certo:** pontos a explorar são temas; sugestões para a conversa são perguntas. Se o modelo
  trocar, o código destroca.
- **Referências sem repetição:** um número por documento.

## Gerenciar a lista de atendimentos (versão 2.5)

Cada atendimento da lista tem ações próprias:
- **Retomar** (aplicações incompletas): volta ao ponto em que o paciente parou (relato, pergunta extra ou questionário).
- **Corrigir código:** para quando o código foi digitado errado; a correção fica registrada.
- **Excluir:** só para aplicações **incompletas**, sem documentos, com confirmação.
- **Arquivar / desarquivar:** atendimentos concluídos ou com alerta de risco **não são excluídos**, porque fazem parte
  do registro do atendimento; arquivados saem da lista e aparecem no filtro "Arquivados".

O banco é atualizado sozinho, sem perder os atendimentos já feitos.

## Como funciona o atendimento

**Área da profissional** (tela inicial, aba **Resultados**): lista todos os atendimentos, atualizada a cada
poucos segundos, com busca, filtros, selo de "novo" e histórico por código (evolução dos escores).

1. **Nova aplicação:** informe o código do paciente e escolha **Iniciar nesta tela** ou **Abrir em nova janela**.
2. **Modo paciente:** relato, até 2 perguntas extras e o questionário. No fim, uma tela de agradecimento explica
   os próximos passos; o paciente **não vê escores nem documentos**.
3. Os documentos são gerados **em segundo plano**: o atendimento aparece como "Preparando documentos" e depois
   "Pronto para leitura".
4. Para sair do modo paciente na mesma tela, é pedido um **PIN local** (padrão `1234`, mude em `PIN_PROFISSIONAL`
   no `.env`). Não é segurança de verdade, só evita acesso acidental; login fica como próximo passo.

**Dica para a apresentação:** use **Abrir em nova janela** e deixe as duas janelas lado a lado. Responda como
paciente numa e veja o resultado chegar ao vivo na outra.

## Documentos gerados

- **Resumo de pré-consulta** (agente relator + RAG de normas), na estrutura da Resolução CFP 06/2019. A **conclusão
  é escrita pela profissional** na própria tela; nenhuma IA lê ou altera esse campo.
- Nos dois documentos, as **palavras do relato ligadas a cada item** são destacadas: no resumo oficial, só em
  negrito; na análise, com cores por dimensão, sublinhados distintos (funcionam impressos em preto e branco),
  rótulos e explicações. O agente analista indica as palavras, e o código só aceita as que existem no relato.
- **Análise de apoio à profissional** (agente de apoio + RAG científico + agente revisor): texto mais livre e
  humanizado, com panorama, leitura guiada do relato, leitura por dimensão, pontos a explorar, sugestões para a
  conversa, cuidados, evidências e referências bibliográficas. Não é diagnóstico nem conclusão. O revisor aponta
  problemas e a análise é refeita (até 3 tentativas); tudo passa por checagens automáticas.

Para ampliar a base científica, coloque PDFs de acesso aberto em `conhecimento/ciencia/` e reinicie a API.

## Interface e acessibilidade

Interface React (Vite) dentro do Electron, pensada para o WCAG 2.1 AA:
- fonte Segoe UI, Tahoma, Geneva, Verdana na interface e Times New Roman nos documentos;
- paleta com contraste conferido (texto ≥ 4,5:1, bordas ≥ 3:1) nos temas claro e escuro;
- temas claro, automático e escuro com ícones do Font Awesome, num grupo de opções navegável pelas setas;
- foco sempre visível, link "Pular para o conteúdo" e foco no título a cada nova tela;
- escala do questionário como grupos de opções (`fieldset` + `radio`), navegáveis pelas setas;
- abas acessíveis (setas, Home e End), erros e progresso anunciados a leitores de tela;
- alvos de clique de no mínimo 44 px e layout que se adapta a janelas estreitas;
- borda animada no campo de resposta, que para ao focar ou digitar e respeita "reduzir movimento".

Teste de ponta a ponta da interface (com a API ligada): `cd desktop && npm test`.

## Rede neural com máscara

`scripts/treinar_rede_mascara.py` treina uma rede que aceita **qualquer conjunto de 8 itens** (23 respostas
padronizadas com zeros nos itens não aplicados + 23 indicadores). Resultado no teste: MAE de 0,248 com os
8 itens base e 0,255 com conjuntos variados. O modelo treinado já está em `modelos/`.

## Avaliar o RAG

`python scripts/avaliar_rag.py` compara a busca por embeddings com palavras-chave nos relatos de
`conhecimento/relatos_teste.json`. Os 12 relatos atuais são um rascunho: a psicóloga deve revisá-los e
ampliar para 30 a 40, incluindo falas **sem** as palavras literais dos itens, onde a diferença aparece.

## API

Documentação interativa em http://127.0.0.1:8000/docs. Fluxo: `POST /sessoes` → `POST /sessoes/{id}/relato`
(repita se vier uma pergunta) → `POST /sessoes/{id}/respostas` → `POST /sessoes/{id}/relatorio` →
`POST /sessoes/{id}/analise` → `PUT /sessoes/{id}/conclusao` → `GET /sessoes/{id}/relatorio.html` e `analise.html`.

## Privacidade

Dados ficam no SQLite local (`dados/bat.db`) e todo o processamento de IA (embeddings, rede neural e
modelos de linguagem) roda no próprio computador: nada é enviado para fora. Use apenas dados simulados nos testes.

## Pendências para o grupo

- Psicóloga: revisar `conhecimento/itens_expressoes.json` e `relatos_teste.json`.
- Substituir os textos dos itens pela versão brasileira validada do BAT (Sinval et al., 2022).
- Acrescentar ao RAG de normas os modelos de relatório revisados e os artigos de validação.
