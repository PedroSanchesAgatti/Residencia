# O BAT no Brasil e os pontos de corte

## Validação brasileira
A versão brasileira do BAT foi estudada junto com a portuguesa em amostra de trabalhadores dos dois países. A estrutura de quatro dimensões foi sustentada, com evidências para as versões de 23 e de 12 itens.

## Pontos de corte
Os pontos de corte mais usados foram definidos com amostras representativas de países europeus, comparando trabalhadores em geral com pessoas com diagnóstico de burnout. Para o total do BAT-23, valores a partir de cerca de 2,59 indicam risco e a partir de cerca de 3,02 indicam burnout elevado. Os próprios autores recomendam cautela ao usar esses cortes em outros países.

## Dimensão mais frágil para classificação
O distanciamento mental mostrou a menor capacidade de separar casos e não casos entre as dimensões, o que pede cuidado ao interpretar essa dimensão isoladamente.

## Implicação para este sistema
Como não há cortes validados no Brasil, o sistema compara a pessoa com uma amostra de referência de trabalhadores brasileiros (percentil) e trata as faixas europeias apenas como referência provisória.

Referências: Sinval, J., Vazquez, A. C. S., Hutz, C. S., Schaufeli, W. B., & Silva, S. (2022). Burnout Assessment Tool (BAT): validity evidence from Brazil and Portugal. International Journal of Environmental Research and Public Health, 19(3), 1344. Schaufeli, W. B., De Witte, H., Hakanen, J. J., Kaltiainen, J., & Kok, R. (2023). How to assess severe burnout? Cutoff points for the Burnout Assessment Tool (BAT) based on three European samples. Scandinavian Journal of Work, Environment & Health, 49(4).
