# Burnout, depressão e outros quadros: pontos de atenção

## Sobreposição com sintomas depressivos
A literatura discute a sobreposição entre burnout e depressão: exaustão, perda de prazer e dificuldades cognitivas aparecem nos dois. Por isso, escores altos de burnout não excluem outros quadros, e a avaliação clínica é necessária para diferenciá-los.

## Sintomas que pedem atenção
Tristeza persistente sem relação com o trabalho, perda de interesse generalizada, alterações importantes de sono e apetite ou qualquer menção a pensamentos de morte indicam a necessidade de avaliação clínica cuidadosa, além do foco ocupacional.

## Limites de instrumentos de autorrelato
Questionários de autorrelato medem a percepção da pessoa em um momento. Eles são úteis para triagem e acompanhamento, mas não substituem a entrevista clínica.

Referências: Bianchi, R., Schonfeld, I. S., & Laurent, E. (2015). Burnout–depression overlap: a review. Clinical Psychology Review, 36. Maslach, C., & Leiter, M. P. (2016). Understanding the burnout experience: recent research and its implications for psychiatry. World Psychiatry, 15(2).
