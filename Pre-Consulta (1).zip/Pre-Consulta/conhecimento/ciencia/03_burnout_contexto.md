# Burnout como fenômeno ocupacional e fatores do trabalho

## Classificação pela OMS
Na CID-11, o burnout aparece como fenômeno ocupacional, ligado ao estresse crônico no trabalho que não foi bem gerenciado, e não como condição médica. A definição se restringe ao contexto do trabalho.

## Demandas e recursos do trabalho
O modelo de Demandas e Recursos do Trabalho propõe que o burnout se desenvolve quando as demandas (sobrecarga, pressão de tempo, exigências emocionais) superam de forma persistente os recursos disponíveis (autonomia, apoio social, feedback). Recursos também favorecem o engajamento.

## Recuperação fora do trabalho
A recuperação depois da jornada, especialmente o desligamento mental do trabalho, o relaxamento e o sono adequado, está associada a menor exaustão. Dificuldade de recuperar a energia é um dos sinais centrais do burnout.

## Implicações para a consulta
Os achados sugerem explorar, na consulta, a carga e a organização do trabalho, o apoio disponível, as oportunidades de recuperação e o sono, além dos sintomas relatados.

Referências: Organização Mundial da Saúde (2019). CID-11, código QD85. Bakker, A. B., & Demerouti, E. (2017). Job demands–resources theory: taking stock and looking forward. Journal of Occupational Health Psychology, 22(3). Sonnentag, S., & Fritz, C. (2007). The Recovery Experience Questionnaire. Journal of Occupational Health Psychology, 12(3).
