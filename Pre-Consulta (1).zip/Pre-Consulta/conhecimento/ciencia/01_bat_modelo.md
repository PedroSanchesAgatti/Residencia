# O modelo de burnout do BAT

## Definição usada pelo BAT
O Burnout Assessment Tool (BAT) entende o burnout como um estado de esgotamento relacionado ao trabalho, em que a pessoa perde a capacidade e a disposição de investir esforço. As quatro dimensões centrais são exaustão, distanciamento mental, prejuízo cognitivo e prejuízo emocional; queixas psicológicas e psicossomáticas aparecem como sintomas secundários.

## Por que quatro dimensões
A exaustão é considerada o núcleo do burnout. O distanciamento mental funciona como uma forma de proteção diante da exaustão. Os prejuízos cognitivo e emocional refletem a perda de controle sobre funções do dia a dia no trabalho, como concentração e regulação das emoções.

## Relação com o modelo anterior
O BAT foi proposto como alternativa ao modelo clássico de três dimensões. A baixa realização profissional deixou de ser tratada como sintoma central e passou a ser vista como possível consequência.

## Leitura dos escores
Os escores de cada dimensão são médias de 1 (nunca) a 5 (sempre). Valores mais altos indicam maior frequência dos sintomas. A leitura deve considerar o conjunto das dimensões, e não apenas o total.

Referências: Schaufeli, W. B., De Witte, H., & Desart, S. (2019). Manual do Burnout Assessment Tool (BAT). KU Leuven. Schaufeli, W. B., Desart, S., & De Witte, H. (2020). Burnout Assessment Tool (BAT): development, validity and reliability. International Journal of Environmental Research and Public Health, 17(24).
