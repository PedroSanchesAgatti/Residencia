# Base científica do RAG

Esta pasta alimenta o agente de **análise de apoio à profissional**.

- Os arquivos `.md` numerados são **resumos elaborados pelo grupo**, com as referências no fim de cada um.
  Servem para o sistema funcionar desde o início, mas devem ser revisados pela psicóloga.
- Coloque aqui também os **PDFs dos artigos de acesso aberto** (validações do BAT, CBI-Br, OLBI e revisões
  sobre burnout). Na inicialização, a API extrai o texto, divide em trechos e indexa com embeddings.
- Use apenas artigos cuja licença permita esse uso (por exemplo, CC BY) e mantenha a referência no nome do
  arquivo, como `Sinval_2022_BAT_Brasil_Portugal.pdf`.
