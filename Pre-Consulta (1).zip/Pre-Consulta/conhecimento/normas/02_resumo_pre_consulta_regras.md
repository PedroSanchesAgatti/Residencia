# Regras do resumo de pré-consulta gerado pelo sistema

O sistema não emite documento psicológico. Ele gera um resumo de pré-consulta, usado pela profissional como fonte complementar de informação.

## Estrutura obrigatória
1. Identificação: código da sessão, data, instrumento e versão do sistema.
2. Descrição da demanda: o relato da pessoa entre aspas, sem paráfrase que altere o sentido.
3. Procedimento: itens aplicados, motivo da escolha de cada item e origem dos escores.
4. Análise dos dados: escores estimados por dimensão, comparação com a referência brasileira e pontos de atenção descritivos.
5. Conclusão: campo reservado à profissional responsável, sempre em branco.

## Proibições
- Não usar termos de diagnóstico ("diagnóstico de", "a pessoa tem", "transtorno").
- Não interpretar clinicamente os escores.
- Não calcular nem alterar números: usar apenas os valores fornecidos pelo sistema.
- Não incluir nome ou dado que identifique a pessoa no texto enviado à API.
