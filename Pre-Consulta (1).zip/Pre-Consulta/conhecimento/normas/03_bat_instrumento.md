# Burnout Assessment Tool (BAT)

O BAT avalia burnout em quatro dimensões centrais: exaustão (8 itens), distanciamento mental (5), prejuízo cognitivo (5) e prejuízo emocional (5). As respostas vão de 1 (nunca) a 5 (sempre), e o escore de cada dimensão é a média dos seus itens.

A versão brasileira foi validada por Sinval et al. (2022), com evidências para as versões de 23 e de 12 itens. Os pontos de corte publicados (Schaufeli et al., 2023) foram definidos com amostras europeias e devem ser tratados como referência provisória no Brasil.

## Escores estimados neste sistema
O sistema aplica 8 dos 23 itens e usa uma rede neural para estimar os escores das quatro dimensões. Os escores são estimativas, com erro médio esperado informado no resumo. Para um resultado completo, a profissional pode aplicar o BAT-23.

Fontes: Schaufeli, De Witte e Desart (2019), manual do BAT; Sinval et al. (2022); Schaufeli et al. (2023).
