# Resolução CFP nº 06/2019: pontos para o resumo de pré-consulta

Fonte: Conselho Federal de Psicologia, Resolução nº 6, de 29 de março de 2019. Texto integral:
https://transparencia.cfp.org.br/wp-content/uploads/sites/23/2019/04/Resolucao-do-exercicio-profissional-6-2019-Conselho-federal-de-psicologia-BR.pdf
(Resumo elaborado pelo grupo; para qualquer decisão, consulte o texto integral.)

## Relatório psicológico (art. 11)
O relatório psicológico é uma exposição escrita, descritiva e circunstanciada que comunica a atuação profissional e pode gerar orientações e encaminhamentos. Ele não tem a finalidade de produzir diagnóstico psicológico e não deve transcrever as sessões.

## Estrutura do relatório psicológico
O relatório é composto por cinco itens: identificação, descrição da demanda, procedimento, análise e conclusão.
- Identificação: título, pessoa atendida, solicitante, finalidade e autora com inscrição no CRP.
- Descrição da demanda: o que motivou a busca pelo atendimento e quem forneceu as informações.
- Procedimento: recursos técnico-científicos utilizados, pessoas ouvidas, número de encontros e duração.
- Análise: exposição descritiva e analítica fundamentada, sem afirmações sem sustentação.
- Conclusão: conclusões a partir da análise, com possíveis orientações e encaminhamentos.

## Linguagem (art. 6)
Texto preciso, impessoal, na terceira pessoa, na norma culta, com encadeamento lógico. Informações subjetivas pedem linguagem objetiva.

## Cuidados formais
Páginas numeradas, local e data, assinatura com inscrição no CRP, prazo de validade do conteúdo no último parágrafo, guarda mínima de 5 anos e entrega em entrevista devolutiva.

## Fontes complementares
Informações produzidas por outros meios, inclusive sistemas informatizados, podem ser usadas como fonte complementar de informação, cabendo à psicóloga a análise e a conclusão.
