import os
import sys
from pathlib import Path

os.environ["LLM_MODO"] = "simulado"
os.environ["ANTHROPIC_API_KEY"] = ""          # os testes nunca chamam a API de verdade
os.environ["BANCO"] = str(Path(__file__).parent / "teste.db")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
db = Path(os.environ["BANCO"])
if db.exists():
    db.unlink()
