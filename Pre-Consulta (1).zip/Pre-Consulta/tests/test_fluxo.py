"""Testes do fluxo completo em modo simulado (sem chamar a API da Anthropic)."""
from fastapi.testclient import TestClient

from api import rede, seletor
from api.main import app
from api.validacao import checar


def cliente():
    return TestClient(app)


def test_fluxo_completo_relato_claro():
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-T1"}).json()["id"]
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Não consigo me concentrar e esqueço reuniões. Ando sem paciência com todo mundo."}).json()
        assert r["estado"] == "questionario" and len(r["itens"]) == 8
        dims = {i["dimensao"] for i in r["itens"]}
        assert dims == {"Exaustão", "Distanciamento", "Cognitivo", "Emocional"}      # cobertura mínima
        resp = c.post(f"/sessoes/{sid}/respostas", json={"respostas": {i["item"]: 3 for i in r["itens"]}}).json()
        assert resp == {"estado": "concluida"}                              # o paciente não recebe escores
        info = c.get(f"/sessoes/{sid}").json()                               # documentos gerados em segundo plano
        assert info["docs_estado"] == "pronto" and info["resumo"]["checagens"]["aprovado"], info
        assert set(info["escores"]) == dims and all(1 <= v <= 5 for v in info["escores"].values())
        html = c.get(f"/sessoes/{sid}/relatorio.html").text
        assert "Campo reservado à profissional responsável" in html and "Não consigo me concentrar" in html
        origens = [e["origem"] for e in c.get(f"/sessoes/{sid}/eventos").json()]
        for o in ["rag_itens", "analista", "seletor", "rede", "rag_normas", "relator", "validacao"]:
            assert o in origens


def test_no_maximo_duas_perguntas_extras(monkeypatch):
    """Mesmo que o analista sempre queira perguntar mais, o fluxo para em 2 perguntas extras."""
    from api.agentes import analista
    original = analista.analisar
    def sempre_pergunta(relatos, feitas):
        r = original(relatos, feitas)
        return {**r, "pergunta": "Pode contar mais?"}
    monkeypatch.setattr(analista, "analisar", sempre_pergunta)
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-T2"}).json()["id"]
        estados = []
        for t in ["Não estou bem.", "Não sei explicar.", "É difícil.", "Só isso."]:
            r = c.post(f"/sessoes/{sid}/relato", json={"texto": t}).json()
            estados.append(r.get("estado"))
            if r.get("estado") == "questionario":
                break
        assert estados == ["perguntas", "perguntas", "questionario"], estados


def test_risco_interrompe():
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-T3"}).json()["id"]
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Não quero mais viver."}).json()
        assert r["estado"] == "interrompida" and "188" in r["mensagem"]


def test_respostas_invalidas_sao_recusadas():
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-T4"}).json()["id"]
        itens = c.post(f"/sessoes/{sid}/relato", json={"texto": "Estou exausta, sem energia ao acordar."}).json()["itens"]
        assert c.post(f"/sessoes/{sid}/respostas", json={"respostas": {i["item"]: 9 for i in itens}}).status_code == 422
        assert c.post(f"/sessoes/{sid}/respostas", json={"respostas": {"BAT1": 3}}).status_code == 422


def test_seletor_distribui_oito_com_cobertura():
    cota = seletor.distribuir({"Exaustão": 1.0, "Distanciamento": 0.1, "Cognitivo": 0.6, "Emocional": 0.0})
    assert sum(cota.values()) == 8 and min(cota.values()) >= 1 and cota["Exaustão"] > cota["Emocional"]
    assert seletor.distribuir({}) == {d: 2 for d in cota}


def test_rede_aceita_qualquer_conjunto_de_8():
    est = rede.estimar({"BAT1": 5, "BAT2": 5, "BAT3": 4, "BAT9": 2, "BAT14": 1, "BAT19": 1, "BAT20": 1, "BAT5": 5})
    assert est["escores"]["Exaustão"] > est["escores"]["Emocional"]


def test_validacao_barra_diagnostico_e_numero_inventado():
    secoes = {"descricao_demanda": 'A pessoa relatou: "estou cansada"', "procedimento": "8 itens [1]",
              "analise": "Escore de 4,90 indica diagnóstico de burnout", "pontos_atencao": "nenhum"}
    chk = checar(secoes, {"3.10"}, ["estou cansada"], {1})
    from api.validacao import tem_diagnostico
    assert not tem_diagnostico("A pessoa tem relatado cansaço.") and tem_diagnostico("A pessoa tem burnout.")
    assert not chk["sem_diagnostico"] and not chk["numeros_fieis"] and not chk["aprovado"]


class _RespostaFalsa:
    def __init__(self, conteudo, status=200):
        self.status_code, self._c, self.text = status, conteudo, conteudo
    def raise_for_status(self):
        pass
    def json(self):
        return {"message": {"content": self._c}, "prompt_eval_count": 10, "eval_count": 5}


def test_ollama_recebe_esquema_modelo_e_tenta_de_novo(monkeypatch):
    """O cliente envia o esquema em `format`, escolhe o modelo pelo papel e repete se o JSON vier incompleto."""
    from api.agentes import llm
    enviados = []
    respostas = iter(['{"a": 1}', '{"a": 1, "b": 2}'])          # 1ª sem o campo "b"; 2ª completa

    def post(url, json=None, timeout=None):
        enviados.append(json)
        return _RespostaFalsa(next(respostas))

    monkeypatch.setattr(llm, "ativo", lambda: True)
    monkeypatch.setattr(llm.httpx, "post", post)
    esquema = {"type": "object", "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}}, "required": ["a", "b"]}
    r, tokens = llm.estruturado("sistema", "usuário", {"name": "f", "input_schema": esquema}, papel="apoio")
    assert r == {"a": 1, "b": 2} and tokens == (10, 5) and len(enviados) == 2
    assert enviados[0]["format"] == esquema and enviados[0]["model"] == llm.modelo_de("apoio")[0]
    from api.config import OLLAMA_MODELO, OLLAMA_MODELO_APOIO
    assert llm.modelo_de("analista")[0] == OLLAMA_MODELO and llm.modelo_de("revisor")[0] == OLLAMA_MODELO_APOIO
    # (os dois podem ser iguais: o .env do pacote usa o 7B em tudo, para rodar em qualquer máquina)


def test_ollama_desligado_vira_llm_indisponivel(monkeypatch):
    import httpx
    from api.agentes import llm

    def post(*a, **k):
        raise httpx.ConnectError("sem ollama")

    monkeypatch.setattr(llm, "ativo", lambda: True)
    monkeypatch.setattr(llm.httpx, "post", post)
    try:
        llm.estruturado("s", "u", {"name": "f", "input_schema": {"type": "object"}})
        assert False, "deveria falhar"
    except llm.LLMIndisponivel:
        pass


def test_analista_cai_para_o_rag_se_o_ollama_falhar(monkeypatch):
    from api.agentes import analista, llm
    monkeypatch.setattr(llm, "ativo", lambda: True)
    monkeypatch.setattr(llm, "estruturado", lambda *a, **k: (_ for _ in ()).throw(llm.LLMIndisponivel("x")))
    r = analista.analisar(["Esqueço reuniões e chego em casa sem energia."], 0)
    assert r["modo"].startswith("RAG sem LLM") and set(r["forcas"]) == {"Exaustão", "Distanciamento", "Cognitivo", "Emocional"}


def test_json_no_texto_como_ultimo_recurso():
    from api.agentes.llm import _json_do_texto
    assert _json_do_texto('Aqui está: ```json\n{"a": 1}\n```')["a"] == 1


def _ate_resumo(c, codigo="P-T9", relato="Chego em casa sem energia e ando sem paciência."):
    sid = c.post("/sessoes", json={"codigo": codigo}).json()["id"]
    r = c.post(f"/sessoes/{sid}/relato", json={"texto": relato}).json()
    while r["estado"] == "perguntas":                                    # responde às perguntas extras, se houver
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Isso acontece quase todos os dias no trabalho."}).json()
    itens = r["itens"]
    c.post(f"/sessoes/{sid}/respostas", json={"respostas": {i["item"]: 4 for i in itens}})
    return sid


def test_conclusao_editavel_pela_profissional():
    with cliente() as c:
        sid = _ate_resumo(c)
        assert c.get(f"/sessoes/{sid}/conclusao").json()["texto"] == ""
        assert c.put(f"/sessoes/{sid}/conclusao", json={"texto": "Sem assinatura."}).status_code == 422   # assinatura obrigatória
        assinatura = {"profissional_nome": "Dra. Teste", "profissional_crp": "06/000"}
        assert c.put(f"/sessoes/{sid}/conclusao", json={"texto": "Indicadores relevantes de exaustão.", **assinatura}).json()["ok"]
        c.put(f"/sessoes/{sid}/conclusao", json={"texto": "Versão revisada pela profissional.", **assinatura})
        html = c.get(f"/sessoes/{sid}/relatorio.html").text
        assert "Versão revisada pela profissional." in html and "Campo reservado" not in html
        assert "Dra. Teste" in html and "CRP 06/000" in html
        assert c.get(f"/sessoes/{sid}/conclusao").json()["profissional_nome"] == "Dra. Teste"


def test_conclusao_bloqueada_antes_do_resumo():
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-T10"}).json()["id"]
        assert c.put(f"/sessoes/{sid}/conclusao", json={"texto": "x", "profissional_nome": "Dra. X", "profissional_crp": "06/1"}).status_code == 409


def test_analise_de_apoio():
    with cliente() as c:
        sid = _ate_resumo(c, "P-T11")
        r = c.post(f"/sessoes/{sid}/analise").json()                        # regenerar também funciona
        assert r["checagens"]["aprovado"], r
        html = c.get(f"/sessoes/{sid}/analise.html").text
        assert "Gerada por IA" in html and "não é diagnóstico" in html and "Referências bibliográficas" in html
        assert c.get(f"/sessoes/{sid}").json()["analise"]["checagens"]["aprovado"]
        origens = {e["origem"] for e in c.get(f"/sessoes/{sid}/eventos").json()}
        assert {"rag_ciencia", "apoio", "revisor"} <= origens


def test_validacao_da_analise_barra_certeza():
    from api.validacao import checar_analise
    c = {"abertura": "Certamente há burnout [1]", "leitura_por_dimensao": [{"dimensao": "Exaustão", "leitura": "x"}],
         "pontos_a_explorar": ["z"], "evidencias": [{"afirmacao": "a", "fonte": 1}], "limitacoes": "w"}
    chk = checar_analise(c, set(), {1})
    assert not chk["tom_de_hipotese"] and not chk["aprovado"]


def test_apoio_refaz_quando_revisor_reprova(monkeypatch):
    from api.agentes import apoio
    boa = {"abertura": "Exaustão chama atenção [1].", "leitura_por_dimensao": [{"dimensao": "Exaustão", "leitura": "Cansaço."}],
           "o_que_o_relato_mostra": "x", "comentarios_trechos": [], "pontos_a_explorar": ["Vale explorar o sono [1]."],
           "sugestoes_de_conversa": ["Como tem dormido?"], "cuidados": "c", "evidencias": [{"afirmacao": "a", "fonte": 1}],
           "limitacoes": "Estimativas."}
    ruim = {**boa, "abertura": "Certamente há burnout [1]."}
    roteiro = {"destaques": ["exaustão"], "hipoteses": ["recuperação"], "fontes_uteis": [1], "perguntas": ["sono?"]}
    respostas = iter([(roteiro, (50, 20)), (ruim, (100, 50)), ({"aprovado": False, "problemas": ["tom de certeza"]}, (40, 10)),
                      (boa, (120, 60)), ({"aprovado": True, "problemas": []}, (40, 10))])
    monkeypatch.setattr(apoio.llm, "ativo", lambda: True)
    monkeypatch.setattr(apoio.llm, "estruturado", lambda *a, **k: next(respostas))
    est = {"escores": {"Exaustão": 3.5, "Distanciamento": 2.0, "Cognitivo": 2.2, "Emocional": 1.8},
           "percentis": {"Exaustão": 80, "Distanciamento": 60, "Cognitivo": 55, "Emocional": 50},
           "itens_por_dimensao": {"Exaustão": 3, "Distanciamento": 2, "Cognitivo": 2, "Emocional": 1}, "erro_medio_esperado": 0.255}
    r = apoio.analisar(["Estou exausta."], [], est)
    assert r["origem"] == "IA local (com revisão)" and r["conteudo"]["abertura"].startswith("Exaustão") and r["tokens"] == (350, 150)



def test_trechos_destacados_no_resumo_e_na_analise():
    with cliente() as c:
        sid = _ate_resumo(c, "P-T12", "Esqueço reuniões, chego em casa sem energia e ando sem paciência com todo mundo.")
        com_trecho = [i for i in c.get(f"/sessoes/{sid}/eventos").json() if i["origem"] == "seletor"]
        assert com_trecho
        resumo = c.get(f"/sessoes/{sid}/relatorio.html").text
        assert "<b>" in resumo and "<mark" not in resumo                      # oficial: só negrito
        analise = c.get(f"/sessoes/{sid}/analise.html").text
        assert "<mark class=" in analise and "Referências bibliográficas" in analise and "Leitura guiada" in analise


def test_trecho_do_agente_so_vale_se_existir_no_relato():
    from api.trechos import localizar
    partes = ["Ando sem paciência e esqueço reuniões."]
    assert localizar("esqueço reuniões", partes) == (0, 21, 37)
    assert localizar("perdi a memória", partes) is None


def test_area_da_profissional_lista_historico_e_visto():
    with cliente() as c:
        a = _ate_resumo(c, "P-HIST")
        b = _ate_resumo(c, "P-HIST", "Estou exausta e sem foco.")
        lista = c.get("/atendimentos", params={"busca": "p-hist"}).json()
        assert [x["id"] for x in lista] == [b, a] and not lista[0]["visto"] and lista[0]["docs_estado"] == "pronto"
        c.post(f"/sessoes/{b}/visto")
        assert c.get(f"/sessoes/{b}").json()["visto"]
        hist = c.get("/pacientes/P-HIST/historico").json()
        assert len(hist) == 2 and set(hist[0]["escores"]) == {"Exaustão", "Distanciamento", "Cognitivo", "Emocional"}


def test_pin_da_profissional():
    with cliente() as c:
        assert c.post("/config/pin", json={"pin": "1234"}).json()["ok"]
        assert not c.post("/config/pin", json={"pin": "0000"}).json()["ok"]



def test_sem_nome_do_paciente_nem_da_profissional_na_abertura():
    with cliente() as c:
        r = c.post("/sessoes", json={"codigo": "P-ETICA", "nome_local": "Fulana", "profissional": "Dra. X"}).json()
        info = c.get(f"/sessoes/{r['id']}").json()
        assert "nome_local" not in info and "profissional" not in info


def test_analista_detecta_risco_indireto_e_interrompe(monkeypatch):
    """Frase sem as palavras da regra fixa: quem detecta é o analista (que assumiu o papel do guardião)."""
    from api.agentes import analista
    original = analista.analisar
    monkeypatch.setattr(analista, "analisar", lambda relatos, feitas: {**original(relatos, feitas), "risco": True,
                                                                        "motivo_risco": "desejo de não acordar"})
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-RISCO2"}).json()["id"]
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Às vezes queria dormir e não acordar mais."}).json()
        assert r["estado"] == "interrompida" and "188" in r["mensagem"]
        assert any(e["origem"] == "analista" and e["descricao"] == "risco detectado" for e in c.get(f"/sessoes/{sid}/eventos").json())


def test_regra_fixa_interrompe_sem_chamar_o_analista(monkeypatch):
    from api.agentes import analista
    monkeypatch.setattr(analista, "analisar", lambda *a: (_ for _ in ()).throw(AssertionError("não deveria chamar")))
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-RISCO3"}).json()["id"]
        assert c.post(f"/sessoes/{sid}/relato", json={"texto": "Penso em me matar."}).json()["estado"] == "interrompida"


def test_resumo_fica_disponivel_antes_da_analise(monkeypatch):
    """Se a análise falhar, o resumo gerado antes continua disponível para a profissional."""
    from api import main
    monkeypatch.setattr(main, "_gerar_analise", lambda s, se: (_ for _ in ()).throw(RuntimeError("análise lenta/falhou")))
    with cliente() as c:
        sid = _ate_resumo(c, "P-PARCIAL")
        assert c.get(f"/sessoes/{sid}").json()["docs_estado"] == "parcial"
        assert c.get(f"/sessoes/{sid}/relatorio.html").status_code == 200


def test_coerencia_aponta_relato_forte_com_respostas_baixas():
    from api.coerencia import comparar
    est = {"escores": {"Exaustão": 1.24, "Distanciamento": 1.83, "Cognitivo": 1.13, "Emocional": 1.16},
           "percentis": {"Exaustão": 1, "Distanciamento": 58, "Cognitivo": 6, "Emocional": 11}}
    c = comparar({"Exaustão": 0.95, "Distanciamento": 0.0, "Cognitivo": 0.0, "Emocional": 0.0}, est)
    assert [d["dimensao"] for d in c["divergencias"]] == ["Exaustão"] and "exaustão" in c["resumo"]
    assert comparar(None, est)["disponivel"] is False


def test_analise_padrao_destaca_a_divergencia():
    from api.agentes import apoio
    from api.coerencia import comparar
    est = {"escores": {"Exaustão": 1.24, "Distanciamento": 1.83, "Cognitivo": 1.13, "Emocional": 1.16},
           "percentis": {"Exaustão": 1, "Distanciamento": 58, "Cognitivo": 6, "Emocional": 11},
           "itens_por_dimensao": {"Exaustão": 5, "Distanciamento": 1, "Cognitivo": 1, "Emocional": 1}, "erro_medio_esperado": 0.255}
    coer = comparar({"Exaustão": 0.95, "Distanciamento": 0.0, "Cognitivo": 0.0, "Emocional": 0.0}, est)
    r = apoio.analisar(["Ando exausta, sem energia."], [], est, coer)
    assert "diferença entre o relato e as respostas" in r["conteudo"]["abertura"] and r["checagens"]["aprovado"], r["checagens"]


def test_relato_claro_nao_gera_pergunta_extra():
    from api.agentes.analista import pergunta_permitida
    claro = ("Gosto do meu trabalho e da minha equipe, mas ando exausta. Chego em casa sem energia nenhuma, o corpo pesado, "
             "e mesmo dormindo oito horas acordo cansada.")
    assert pergunta_permitida(claro, {"Exaustão": 0.9, "Distanciamento": 0, "Cognitivo": 0, "Emocional": 0}, 0) is None
    vago = "Não estou bem."
    p = pergunta_permitida(vago, {"Exaustão": 0.1, "Distanciamento": 0, "Cognitivo": 0, "Emocional": 0}, 0)
    assert p and "trabalho" in p                                   # sempre da lista aprovada


def test_trechos_nao_atravessam_pontuacao_nem_dimensoes_nao_indicadas():
    from api.trechos import _janelas, associar
    partes = ["Ando exausta. Chego em casa sem energia."]
    assert all("." not in j[3] for j in _janelas(partes))
    itens = [{"item": "BAT16", "dimensao": "Cognitivo", "motivo": "dimensão indicada pelo relato; item mais informativo restante"}]
    r = associar(itens, partes, {}, {"Exaustão": 0.9, "Cognitivo": 0.0, "Distanciamento": 0, "Emocional": 0})
    assert r[0].get("trecho") is None


def test_hipotese_permitida_mas_gravidade_barrada():
    from api.validacao import checar_analise
    base = {"leitura_por_dimensao": [{"dimensao": "Exaustão", "leitura": "x"}], "pontos_a_explorar": ["z"],
            "evidencias": [{"afirmacao": "a", "fonte": 1}], "limitacoes": "w"}
    ok = checar_analise({**base, "abertura": "O relato sugere um quadro de burnout ocupacional [1]."}, set(), {1})
    assert ok["aprovado"], ok
    ruim = checar_analise({**base, "abertura": "A pessoa parece estar em um estágio avançado de esgotamento [1]."}, set(), {1})
    assert not ruim["sem_classificar_gravidade"] and not ruim["aprovado"]
    assert not checar_analise({**base, "abertura": "Os escores corroboram essa hipótese [1]."}, set(), {1})["tom_de_hipotese"]


def test_secoes_trocadas_sao_destrocadas():
    from api.agentes.apoio import ajustar_secoes
    c = ajustar_secoes({"pontos_a_explorar": ["Como você se sente?", "O que mais pesa?"],
                        "sugestoes_de_conversa": ["Explorar o reconhecimento no trabalho.", "Investigar o sono."]})
    assert c["pontos_a_explorar"][0].startswith("Explorar") and c["sugestoes_de_conversa"][0].endswith("?")


def test_referencias_numeradas_por_documento():
    from api.agentes.apoio import _fontes
    est = {"escores": {"Exaustão": 3.0, "Distanciamento": 2.0, "Cognitivo": 2.0, "Emocional": 2.0}}
    fontes, contexto = _fontes(["Ando exausta e sem energia."], est)
    assert len({f["arquivo"] for f in fontes}) == len(fontes) and [f["n"] for f in fontes] == list(range(1, len(fontes) + 1))


def test_frase_de_isola_a_frase_do_trecho():
    from api.trechos import frase_de
    t = "Durmo mal. Às vezes fico triste no meio da aula sem saber explicar o porquê. No fim do dia estou cansado."
    i = t.find("sem saber explicar")
    assert frase_de(t, i, i + 18) == "Às vezes fico triste no meio da aula sem saber explicar o porquê"


def test_respostas_altas_coerentes_nao_geram_alerta():
    """Relato do professor (distanciamento, emocional e exaustão) com respostas 4 e 5: converge, sem divergência.
    O cognitivo alto sem menção no relato vira achado complementar, não alerta."""
    from api.coerencia import comparar
    est = {"escores": {"Exaustão": 3.9, "Distanciamento": 4.1, "Cognitivo": 3.6, "Emocional": 3.0},
           "percentis": {"Exaustão": 91, "Distanciamento": 99, "Cognitivo": 95, "Emocional": 94}}
    c = comparar({"Exaustão": 0.6, "Distanciamento": 0.9, "Cognitivo": 0.1, "Emocional": 0.8}, est)
    assert c["divergencias"] == [] and [x["dimensao"] for x in c["complementares"]] == ["Cognitivo"]
    assert {x["dimensao"] for x in c["coerentes"]} == {"Exaustão", "Distanciamento", "Emocional"}


def test_divergencia_so_quando_muito_grande():
    from api.coerencia import comparar
    est = {"escores": {"Exaustão": 1.8, "Distanciamento": 1.8, "Cognitivo": 1.8, "Emocional": 1.8},
           "percentis": {"Exaustão": 25, "Distanciamento": 58, "Cognitivo": 40, "Emocional": 45}}
    moderada = comparar({"Exaustão": 0.65, "Distanciamento": 0.0, "Cognitivo": 0.0, "Emocional": 0.0}, est)
    assert moderada["divergencias"] == []                       # diferença moderada: sem alerta


def test_relato_sem_relacao_com_respostas_altas():
    from api.coerencia import comparar
    est = {"escores": {"Exaustão": 4.2, "Distanciamento": 3.9, "Cognitivo": 3.5, "Emocional": 3.1},
           "percentis": {"Exaustão": 95, "Distanciamento": 98, "Cognitivo": 93, "Emocional": 90}}
    c = comparar({"Exaustão": 0.05, "Distanciamento": 0.0, "Cognitivo": 0.1, "Emocional": 0.0}, est)
    assert [d["tipo"] for d in c["divergencias"]] == ["relato_sem_relacao"] and "confundido" in c["resumo"]


class _AnthropicFalso:
    def __init__(self, resposta):
        from types import SimpleNamespace
        self.chamadas, self._r, self.SN = 0, resposta, SimpleNamespace
        self.messages = self
    def create(self, **kw):
        self.chamadas += 1
        self.modelo = kw["model"]
        return self.SN(usage=self.SN(input_tokens=7, output_tokens=3),
                       content=[self.SN(type="tool_use", name=kw["tools"][0]["name"], input=self._r)])


def _modo(monkeypatch, modo, chave="sk-teste"):
    from api import config
    from api.agentes import llm
    monkeypatch.setattr(config, "LLM_MODO", modo)
    monkeypatch.setattr(config, "ANTHROPIC_API_KEY", chave)
    monkeypatch.setitem(llm._estado, "ollama_falhou_em", 0.0)
    return llm


def test_automatico_usa_anthropic_quando_ollama_falta_memoria(monkeypatch):
    llm = _modo(monkeypatch, "automatico")
    monkeypatch.setattr(llm.httpx, "post", lambda *a, **k: _RespostaFalsa("unable to allocate CPU_REPACK buffer", status=500))
    falso = _AnthropicFalso({"a": 1})
    monkeypatch.setattr(llm, "_cliente_anthropic", falso)
    esquema = {"type": "object", "required": ["a"]}
    r, tokens = llm.estruturado("s", "u", {"name": "f", "input_schema": esquema}, papel="apoio")
    assert r == {"a": 1} and tokens == (7, 3) and llm.ultimo_provedor() == "anthropic"
    assert falso.modelo == llm.modelo_anthropic("apoio")
    assert "500" in llm._estado["ultimo_erro_ollama"]
    # depois da falha, o Ollama fica em pausa: a próxima chamada vai direto para a Anthropic
    chamou_ollama = []
    monkeypatch.setattr(llm.httpx, "post", lambda *a, **k: chamou_ollama.append(1))
    llm.estruturado("s", "u", {"name": "f", "input_schema": esquema})
    assert chamou_ollama == [] and falso.chamadas == 2


def test_automatico_prefere_ollama_quando_funciona(monkeypatch):
    llm = _modo(monkeypatch, "automatico")
    monkeypatch.setattr(llm.httpx, "post", lambda *a, **k: _RespostaFalsa('{"a": 2}'))
    falso = _AnthropicFalso({"a": 1})
    monkeypatch.setattr(llm, "_cliente_anthropic", falso)
    r, _ = llm.estruturado("s", "u", {"name": "f", "input_schema": {"type": "object", "required": ["a"]}})
    assert r == {"a": 2} and falso.chamadas == 0 and llm.ultimo_provedor() == "ollama"


def test_automatico_sem_chave_se_comporta_como_ollama(monkeypatch):
    llm = _modo(monkeypatch, "automatico", chave="")
    monkeypatch.setattr(llm.httpx, "post", lambda *a, **k: _RespostaFalsa("erro", status=500))
    try:
        llm.estruturado("s", "u", {"name": "f", "input_schema": {"type": "object"}})
        assert False, "deveria falhar"
    except llm.LLMIndisponivel:
        pass


def test_modo_anthropic_nao_chama_ollama(monkeypatch):
    llm = _modo(monkeypatch, "anthropic")
    monkeypatch.setattr(llm.httpx, "post", lambda *a, **k: (_ for _ in ()).throw(AssertionError("não deveria chamar o Ollama")))
    monkeypatch.setattr(llm, "_cliente_anthropic", _AnthropicFalso({"a": 1}))
    r, _ = llm.estruturado("s", "u", {"name": "f", "input_schema": {"type": "object", "required": ["a"]}}, papel="analista")
    assert r == {"a": 1} and llm.nome_provedor(llm.ultimo_provedor()) == "IA na nuvem (Anthropic)"


def test_nova_sessao_nao_trava_enquanto_a_ia_escreve(monkeypatch):
    """Reproduz o "database is locked": a análise demora (IA lenta) e, enquanto isso, outra sessão é criada."""
    import threading, time
    from api import main
    from api.agentes import apoio
    original = apoio.analisar
    def lenta(*a, **k):
        time.sleep(6)                      # mais que o tempo limite antigo do SQLite (5 s)
        return original(*a, **k)
    monkeypatch.setattr(apoio, "analisar", lenta)
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-LENTO"}).json()["id"]
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Chego em casa sem energia e esqueço reuniões."}).json()
        while r["estado"] == "perguntas":
            r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Todo dia."}).json()
        from sqlmodel import Session
        from api.banco import Resposta, Sessao, motor
        with Session(motor) as s:                                    # respostas gravadas sem disparar a tarefa
            for i in r["itens"]:
                s.add(Resposta(sessao_id=sid, item=i["item"], valor=4))
            se = s.get(Sessao, sid); se.estado = "resultado"; s.commit()
        t = threading.Thread(target=main.gerar_documentos, args=(sid,)); t.start()
        time.sleep(1.5)                                              # a análise está "escrevendo"
        t0 = time.time()
        assert c.post("/sessoes", json={"codigo": "P-OUTRA"}).status_code == 200
        assert time.time() - t0 < 3                                  # não ficou esperando o banco
        t.join()


def test_crud_da_lista_retomar_editar_arquivar_excluir():
    with cliente() as c:
        sid = c.post("/sessoes", json={"codigo": "P-ERRO"}).json()["id"]
        assert c.get(f"/sessoes/{sid}/retomar").json()["estado"] == "relato"            # saiu antes do relato
        r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Chego em casa sem energia e esqueço reuniões."}).json()
        while r["estado"] == "perguntas":
            r = c.post(f"/sessoes/{sid}/relato", json={"texto": "Todo dia."}).json()
        ret = c.get(f"/sessoes/{sid}/retomar").json()                                    # saiu no questionário
        assert ret["estado"] == "questionario" and len(ret["itens"]) == 8 and "texto" in ret["itens"][0]
        assert c.patch(f"/sessoes/{sid}", json={"codigo": "P-004"}).json()["codigo"] == "P-004"
        assert c.delete(f"/sessoes/{sid}").json()["ok"]                                   # incompleta: pode excluir
        assert c.get(f"/sessoes/{sid}").status_code == 404
        concluida = _ate_resumo(c, "P-FEITO")
        assert c.delete(f"/sessoes/{concluida}").status_code == 409                       # concluída: não exclui
        c.patch(f"/sessoes/{concluida}", json={"arquivada": True})
        assert all(x["id"] != concluida for x in c.get("/atendimentos").json())
        assert any(x["id"] == concluida for x in c.get("/atendimentos", params={"arquivadas": True}).json())
        assert c.get(f"/sessoes/{concluida}/retomar").status_code == 409
