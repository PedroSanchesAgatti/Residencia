"""Teste opcional com o Ollama de verdade. Só roda se o Ollama estiver ligado e o modelo instalado:
    OLLAMA_REAL=1 python -m pytest tests/test_ollama_real.py -s"""
import os

import pytest

pytestmark = pytest.mark.skipif(os.getenv("OLLAMA_REAL") != "1", reason="defina OLLAMA_REAL=1 com o Ollama ligado")


def test_analista_com_modelo_local(monkeypatch):
    import time
    from api.agentes import analista, llm
    monkeypatch.setattr(llm, "ativo", lambda: True)
    assert llm.situacao().get("ollama") == "ok", llm.situacao()
    t0 = time.time()
    r = analista.analisar(["Esqueço reuniões, chego em casa sem energia e ando sem paciência com todo mundo."], 0)
    print(f"\\nAnalista em {time.time() - t0:.1f} s: {r['forcas']} | trechos: {r['trechos_itens']}")
    assert r["modo"] == "ollama" and max(r["forcas"].values()) > 0
