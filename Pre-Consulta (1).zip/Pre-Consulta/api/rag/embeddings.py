"""Embeddings locais. Usa sentence-transformers; sem ele (ou sem internet na 1ª execução),
cai para TF-IDF de caracteres, que serve para testes, mas NÃO é o modo de produção do entregável."""
from functools import lru_cache

import numpy as np

from ..config import EMBEDDINGS_MODELO


@lru_cache
def _modelo():
    try:
        from sentence_transformers import SentenceTransformer
        return ("st", SentenceTransformer(EMBEDDINGS_MODELO))
    except Exception:
        return ("tfidf", None)


def tipo() -> str:
    return "sentence-transformers" if _modelo()[0] == "st" else "tfidf (modo de teste)"


class Codificador:
    """Transforma textos em vetores normalizados (similaridade de cosseno = produto interno)."""

    def __init__(self, corpus: list[str]):
        self.modo, self.st = _modelo()
        if self.modo == "tfidf":
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.tfidf = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), lowercase=True).fit(corpus)

    def __call__(self, textos: list[str]) -> np.ndarray:
        if self.modo == "st":
            v = self.st.encode(textos, normalize_embeddings=True)
        else:
            v = self.tfidf.transform(textos).toarray()
            v = v / (np.linalg.norm(v, axis=1, keepdims=True) + 1e-12)
        return np.asarray(v, dtype=np.float32)
