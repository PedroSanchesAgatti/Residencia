"""Dois índices vetoriais simples (NumPy em memória, montados na inicialização):
- itens: os 23 itens do BAT + expressões do dia a dia, para mapear o relato aos itens;
- normas: trechos da Resolução CFP 06/2019, regras do resumo e descrição do BAT, para o relator.
Com ~100 trechos, NumPy é suficiente; para bases grandes, troque por Chroma ou FAISS."""
import json
import re
from functools import lru_cache

import numpy as np

from ..config import PASTA_CONHECIMENTO
from .embeddings import Codificador


@lru_cache
def base_itens() -> dict:
    return json.loads((PASTA_CONHECIMENTO / "itens_expressoes.json").read_text(encoding="utf-8"))


def _trechos_pasta(pasta) -> list[dict]:
    """Lê .md (dividido por seção "## ") e .pdf (texto extraído, em blocos de ~900 caracteres)."""
    trechos = []
    for arq in sorted(pasta.glob("*")):
        if arq.name.startswith("00_"):
            continue
        if arq.suffix == ".md":
            partes = re.split(r"\n(?=## )", arq.read_text(encoding="utf-8"))
            titulo_doc = partes[0].splitlines()[0].lstrip("# ").strip()
            refs = re.search(r"Referências?:(.*)$", partes[-1], re.S)
            referencia = refs.group(1).strip() if refs else titulo_doc
            for p in partes:
                texto = re.sub(r"\nReferências?:.*$", "", p.strip(), flags=re.S).strip()
                if len(texto) > 40:
                    trechos.append({"fonte": arq.name, "documento": titulo_doc, "referencia": referencia, "texto": texto})
        elif arq.suffix == ".pdf":
            try:
                from pypdf import PdfReader
                texto = " ".join((pg.extract_text() or "") for pg in PdfReader(str(arq)).pages)
            except Exception:
                continue
            texto = re.sub(r"\s+", " ", texto)
            nome = arq.stem.replace("_", " ")
            for i in range(0, len(texto), 800):
                bloco = texto[i:i + 900].strip()
                if len(bloco) > 200:
                    trechos.append({"fonte": arq.name, "documento": nome, "referencia": nome, "texto": bloco})
    return trechos


class Indice:
    def __init__(self, documentos: list[dict], campo_texto: str = "texto"):
        self.docs = documentos
        textos = [d[campo_texto] for d in documentos]
        self.cod = Codificador(textos)
        self.vetores = self.cod(textos)

    def buscar(self, consulta: str, k: int = 5) -> list[dict]:
        q = self.cod([consulta])[0]
        sim = self.vetores @ q
        ordem = np.argsort(-sim)[:k]
        return [{**self.docs[i], "similaridade": round(float(sim[i]), 3)} for i in ordem]


@lru_cache
def indice_itens() -> Indice:
    b = base_itens()
    docs = []
    for it in b["itens"]:
        # um documento por item e um por expressão: a busca encontra o item pela fala da pessoa
        docs.append({"item": it["id"], "dimensao": it["dimensao"], "texto": it["texto"]})
        for e in it["expressoes"]:
            docs.append({"item": it["id"], "dimensao": it["dimensao"], "texto": e})
    return Indice(docs)


@lru_cache
def indice_normas() -> Indice:
    return Indice(_trechos_pasta(PASTA_CONHECIMENTO / "normas"))


@lru_cache
def indice_ciencia() -> Indice:
    return Indice(_trechos_pasta(PASTA_CONHECIMENTO / "ciencia"))


def itens_do_relato(relato: str, k: int = 12) -> list[dict]:
    """Busca por trechos do relato (frases) e agrega a maior similaridade por item."""
    frases = [f.strip() for f in re.split(r"[.!?;\n]+", relato) if len(f.strip()) > 3] or [relato]
    melhor = {}
    for f in frases:
        for r in indice_itens().buscar(f, k=k):
            atual = melhor.get(r["item"])
            if atual is None or r["similaridade"] > atual["similaridade"]:
                melhor[r["item"]] = {"item": r["item"], "dimensao": r["dimensao"], "similaridade": r["similaridade"],
                                     "trecho_relato": f, "texto_encontrado": r["texto"]}
    return sorted(melhor.values(), key=lambda x: -x["similaridade"])
