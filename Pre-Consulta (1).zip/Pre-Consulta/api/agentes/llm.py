"""Cliente dos modelos de linguagem com saída estruturada: Ollama (local) e Anthropic (nuvem).

Cada agente descreve a resposta que espera como um esquema JSON ("ferramenta"). Modos (LLM_MODO):
- ollama: só local; nenhum dado sai do computador;
- anthropic: só a API da Anthropic;
- automatico: tenta o Ollama e, se ele falhar (falta de memória, desligado, lento, resposta inválida),
  usa a Anthropic. Depois de uma falha, pula o Ollama por alguns minutos para não perder tempo.
Se tudo falhar, o agente usa o texto padrão do código."""
import json
import re
import time

import httpx

from .. import config as C


class LLMIndisponivel(RuntimeError):
    pass


_estado = {"ultimo_provedor": None, "ollama_falhou_em": 0.0, "ultimo_erro_ollama": ""}


def ativo() -> bool:
    """O sistema deve tentar usar um modelo de linguagem? (False no modo simulado)."""
    return C.LLM_MODO in ("ollama", "anthropic", "automatico")


def ultimo_provedor() -> str | None:
    return _estado["ultimo_provedor"]


def nome_provedor(p: str | None) -> str:
    return {"ollama": "IA local", "anthropic": "IA na nuvem (Anthropic)"}.get(p or "", "IA")


def modelo_de(papel: str) -> tuple[str, str]:
    """(modelo do Ollama, tempo carregado) para cada papel: apoio e revisor usam o modelo maior."""
    if papel in ("apoio", "revisor"):
        return C.OLLAMA_MODELO_APOIO, C.OLLAMA_MANTER_APOIO
    return C.OLLAMA_MODELO, C.OLLAMA_MANTER


def modelo_anthropic(papel: str) -> str:
    return C.ANTHROPIC_MODELO_APOIO if papel in ("apoio", "revisor") else C.ANTHROPIC_MODELO


# ---------------------------------------------------------------- situação (para /saude e o painel)
def _situacao_ollama() -> dict:
    try:
        tags = httpx.get(f"{C.OLLAMA_URL}/api/tags", timeout=3).json()
        instalados = {m["name"] for m in tags.get("models", [])}
        def ok(m): return m in instalados or f"{m}:latest" in instalados
        return {"ollama": "ok", "modelo": C.OLLAMA_MODELO, "modelo_instalado": ok(C.OLLAMA_MODELO),
                "modelo_apoio": C.OLLAMA_MODELO_APOIO, "modelo_apoio_instalado": ok(C.OLLAMA_MODELO_APOIO)}
    except Exception as e:
        return {"ollama": f"indisponível ({type(e).__name__}). Abra o app Ollama ou rode 'ollama serve'."}


def situacao() -> dict:
    if not ativo():
        return {"modo": C.LLM_MODO, "ollama": "desligado (modo simulado)", "ia_disponivel": False}
    s = {"modo": C.LLM_MODO, "anthropic": "chave configurada" if C.ANTHROPIC_API_KEY else "sem chave"}
    if C.LLM_MODO in ("ollama", "automatico"):
        s.update(_situacao_ollama())
        if _estado["ultimo_erro_ollama"]:
            s["ultima_falha_ollama"] = _estado["ultimo_erro_ollama"]
    ollama_ok = s.get("ollama") == "ok" and s.get("modelo_instalado", False)
    s["ia_disponivel"] = {"ollama": ollama_ok, "anthropic": bool(C.ANTHROPIC_API_KEY),
                          "automatico": ollama_ok or bool(C.ANTHROPIC_API_KEY)}[C.LLM_MODO]
    return s


def aquecer():
    """Carrega o modelo local na memória, para a primeira resposta ao paciente não demorar."""
    if C.LLM_MODO not in ("ollama", "automatico"):
        return
    try:
        httpx.post(f"{C.OLLAMA_URL}/api/generate", json={"model": C.OLLAMA_MODELO, "prompt": "", "keep_alive": C.OLLAMA_MANTER},
                   timeout=C.OLLAMA_TIMEOUT)
    except Exception:
        pass


# ---------------------------------------------------------------- utilidades
def _json_do_texto(texto: str) -> dict:
    texto = re.sub(r"```(?:json)?", "", texto or "")
    ini, fim = texto.find("{"), texto.rfind("}")
    if ini < 0 or fim <= ini:
        raise ValueError("Resposta sem JSON.")
    return json.loads(texto[ini:fim + 1])


def _faltando(resposta: dict, esquema: dict) -> list[str]:
    return [k for k in esquema.get("required", []) if k not in resposta]


# ---------------------------------------------------------------- Ollama
def _ollama(sistema, usuario, ferramenta, max_tokens, papel, temperatura):
    modelo, manter = modelo_de(papel)
    esquema = ferramenta["input_schema"]
    mensagens = [{"role": "system", "content": sistema + "\n\nResponda SOMENTE com um objeto JSON no formato pedido."},
                 {"role": "user", "content": usuario}]
    erro = None
    for _ in range(2):
        try:
            r = httpx.post(f"{C.OLLAMA_URL}/api/chat", timeout=C.OLLAMA_TIMEOUT, json={
                "model": modelo, "messages": mensagens, "stream": False, "format": esquema, "keep_alive": manter,
                "options": {"temperature": temperatura, "num_predict": max_tokens, "num_ctx": C.OLLAMA_CONTEXTO}})
        except httpx.HTTPError as e:
            raise LLMIndisponivel(f"Ollama não respondeu ({type(e).__name__}).") from e
        if r.status_code == 404:
            raise LLMIndisponivel(f"Modelo '{modelo}' não instalado. Rode: ollama pull {modelo}")
        if r.status_code >= 400:                       # ex.: 500 por falta de memória ao carregar o modelo
            raise LLMIndisponivel(f"Ollama devolveu erro {r.status_code}: {r.text[:200]}")
        dados = r.json()
        tokens = (dados.get("prompt_eval_count"), dados.get("eval_count"))
        try:
            resposta = _json_do_texto(dados.get("message", {}).get("content", ""))
            faltam = _faltando(resposta, esquema)
            if not faltam:
                return resposta, tokens
            erro = f"faltaram os campos {faltam}"
        except (ValueError, json.JSONDecodeError) as e:
            erro = f"JSON inválido ({e})"
        mensagens = mensagens + [{"role": "user", "content": f"A resposta anterior veio com problema: {erro}. "
                                                               "Responda de novo, só com o JSON completo no formato pedido."}]
    raise ValueError(f"O modelo local não produziu uma resposta válida: {erro}")


# ---------------------------------------------------------------- Anthropic
_cliente_anthropic = None
_forcar_ferramenta = True             # alguns modelos recusam tool_choice "tool": aí passa para "auto"


def _anthropic(sistema, usuario, ferramenta, max_tokens, papel, temperatura):
    global _cliente_anthropic, _forcar_ferramenta
    if not C.ANTHROPIC_API_KEY:
        raise LLMIndisponivel("Sem ANTHROPIC_API_KEY no .env.")
    import anthropic
    if _cliente_anthropic is None:
        _cliente_anthropic = anthropic.Anthropic(api_key=C.ANTHROPIC_API_KEY)
    modelo = modelo_anthropic(papel)

    def criar(forcar):
        sist = sistema if forcar else sistema + f"\n\nIMPORTANTE: responda chamando a ferramenta `{ferramenta['name']}`."
        escolha = {"type": "tool", "name": ferramenta["name"]} if forcar else {"type": "auto"}
        # sem "temperature": versões recentes da biblioteca/modelos não aceitam esse parâmetro
        return _cliente_anthropic.messages.create(model=modelo, max_tokens=max_tokens, system=sist,
                                                  tools=[ferramenta], tool_choice=escolha,
                                                  messages=[{"role": "user", "content": usuario}])
    try:
        r = criar(_forcar_ferramenta)
    except anthropic.BadRequestError as e:
        if _forcar_ferramenta and "tool_choice" in str(e):
            _forcar_ferramenta = False
            r = criar(False)
        else:
            raise
    except (anthropic.APIError, TypeError) as e:        # qualquer falha vira "indisponível", com o motivo registrado
        raise LLMIndisponivel(f"Anthropic indisponível ({type(e).__name__}: {str(e)[:200]}).") from e
    tokens = (r.usage.input_tokens, r.usage.output_tokens)
    bloco = next((b for b in r.content if getattr(b, "type", "") == "tool_use" and b.name == ferramenta["name"]), None)
    resposta = bloco.input if bloco is not None else _json_do_texto("".join(getattr(b, "text", "") for b in r.content))
    faltam = _faltando(resposta, ferramenta["input_schema"])
    if faltam:
        raise ValueError(f"A resposta da Anthropic não trouxe os campos {faltam}")
    return resposta, tokens


# ---------------------------------------------------------------- entrada única dos agentes
def estruturado(sistema: str, usuario: str, ferramenta: dict, max_tokens: int = 1500,
                papel: str = "geral", temperatura: float = 0.2) -> tuple[dict, tuple]:
    """Pede uma resposta no formato de `ferramenta["input_schema"]`. Devolve (resposta, (tokens entrada, saída))."""
    if not ativo():
        raise LLMIndisponivel("LLM em modo simulado.")
    if C.LLM_MODO == "anthropic":
        ordem = ["anthropic"]
    elif C.LLM_MODO == "ollama":
        ordem = ["ollama"]
    else:                                              # automático
        pausado = time.time() - _estado["ollama_falhou_em"] < C.PAUSA_OLLAMA
        ordem = (["anthropic"] if pausado and C.ANTHROPIC_API_KEY else ["ollama"]) + (["anthropic"] if C.ANTHROPIC_API_KEY else [])
        ordem = list(dict.fromkeys(ordem))
    erro = None
    for provedor in ordem:
        try:
            if provedor == "ollama":
                resposta, tokens = _ollama(sistema, usuario, ferramenta, max_tokens, papel, temperatura)
            else:
                resposta, tokens = _anthropic(sistema, usuario, ferramenta, max_tokens, papel, temperatura)
            _estado["ultimo_provedor"] = provedor
            return resposta, tokens
        except (LLMIndisponivel, ValueError) as e:
            erro = e
            if provedor == "ollama":
                _estado["ollama_falhou_em"] = time.time()
                _estado["ultimo_erro_ollama"] = str(e)[:200]
    raise erro if isinstance(erro, LLMIndisponivel) else LLMIndisponivel(str(erro))
