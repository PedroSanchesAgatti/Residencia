"""Agente analista: lê o relato, verifica risco à vida, usa o RAG de itens e devolve indícios estruturados.
Pode pedir até 2 perguntas extras quando o relato é vago. Assumiu a função do antigo agente guardião:
uma chamada ao modelo a menos por relato. A regra fixa de api/seguranca.py roda antes, como rede de segurança."""
from ..config import MAX_PERGUNTAS_EXTRAS
from ..rag.indice import base_itens, itens_do_relato
from . import llm

FERRAMENTA = {
    "name": "registrar_indicios",
    "description": "Registra os indícios do relato em cada dimensão do BAT e, se necessário, uma pergunta de esclarecimento.",
    "input_schema": {"type": "object", "properties": {
        "forcas": {"type": "object", "description": "Força do indício por dimensão, de 0 a 1.",
                   "properties": {d: {"type": "number"} for d in ["Exaustão", "Distanciamento", "Cognitivo", "Emocional"]},
                   "required": ["Exaustão", "Distanciamento", "Cognitivo", "Emocional"]},
        "trechos": {"type": "array", "items": {"type": "object", "properties": {
            "dimensao": {"type": "string"}, "trecho": {"type": "string"}}, "required": ["dimensao", "trecho"]}},
        "trechos_itens": {"type": "array", "description": "Para cada item da lista do RAG que o relato realmente menciona, as palavras EXATAS do relato (2 a 8 palavras, copiadas sem alteração) que se referem a ele.",
                          "items": {"type": "object", "properties": {"item": {"type": "string"}, "trecho": {"type": "string"}},
                                    "required": ["item", "trecho"]}},
        "pergunta": {"type": "string", "description": "Pergunta aberta de esclarecimento, ou texto vazio se não precisar."},
        "risco": {"type": "boolean", "description": "true só se o texto indicar risco à vida (ideação suicida, autolesão, intenção de se machucar)."},
        "motivo_risco": {"type": "string", "description": "Trecho e motivo, se risco = true; senão, vazio."}},
        "required": ["risco", "motivo_risco", "forcas", "trechos", "trechos_itens", "pergunta"]}}

SISTEMA = """Você analisa o relato de uma pessoa antes de uma consulta sobre burnout. Escreva em português do Brasil.

Tarefa:
0. risco: antes de tudo, verifique se o texto indica RISCO À VIDA (ideação suicida, autolesão, intenção de se
   machucar, mesmo de forma indireta, como "queria dormir e não acordar"). Cansaço, tristeza ou estresse sem
   esses elementos NÃO são risco. Na dúvida real, marque true: a profissional será avisada.
1. forcas: para cada dimensão, a força dos indícios no relato, de 0 (nenhum) a 1 (muito claro).
2. trechos: frases do relato ligadas a cada dimensão, copiadas sem alteração.
3. trechos_itens: para cada item da lista do RAG que o relato realmente menciona, só as palavras-chave
   EXATAS do relato (2 a 8 palavras). Palavras que não estiverem no relato serão descartadas.
4. pergunta: escreva "sim" só se o relato for vago demais para indicar qualquer dimensão (ex.: "não estou
   bem"); senão, "". O sistema escolhe a pergunta. Perguntas já feitas: {feitas} de {maximo}.

Dimensões:
{dimensoes}

Não interprete clinicamente nem faça diagnóstico.

Exemplo:
Relato: "Esqueço reuniões e chego em casa sem energia nenhuma."
Resposta: {{"forcas": {{"Exaustão": 0.8, "Distanciamento": 0.0, "Cognitivo": 0.8, "Emocional": 0.0}},
"trechos": [{{"dimensao": "Cognitivo", "trecho": "Esqueço reuniões"}}, {{"dimensao": "Exaustão", "trecho": "chego em casa sem energia nenhuma"}}],
"trechos_itens": [{{"item": "BAT16", "trecho": "Esqueço reuniões"}}, {{"item": "BAT3", "trecho": "sem energia nenhuma"}}],
"pergunta": "", "risco": false, "motivo_risco": ""}}"""

# Perguntas extras aprovadas (para revisão da psicóloga). O modelo nunca escreve a pergunta livremente:
# o código decide se o relato é vago o bastante para perguntar e escolhe a pergunta desta lista.
PALAVRAS_MINIMAS = 25          # relatos com menos palavras que isso podem ser vagos
FORCA_CLARA = 0.5              # se alguma dimensão tem indício com essa força, o relato não é vago

PERGUNTAS_PADRAO = [
    "Pode contar um pouco mais sobre como o trabalho tem afetado você no dia a dia?",
    "Pensando nas últimas semanas, o que mais tem mudado: sua energia, sua concentração, seu humor ou sua vontade de trabalhar?",
]


def analisar(relatos: list[str], perguntas_feitas: int) -> dict:
    texto = "\n".join(relatos)
    rag = itens_do_relato(texto)
    if llm.ativo():
        try:
            return _analisar_llm(texto, rag, perguntas_feitas)
        except Exception as e:      # falha do LLM não derruba a sessão: segue com a análise do RAG
            simulado = _analisar_rag(rag, perguntas_feitas)
            return {**simulado, "modo": f"RAG sem LLM (LLM falhou: {type(e).__name__})"}
    return _analisar_rag(rag, perguntas_feitas)


def _analisar_llm(texto, rag, perguntas_feitas):
    dims = "\n".join(f"- {d}: {t}" for d, t in base_itens()["dimensoes"].items())
    contexto = "\n".join(f'- {x["item"]} ({x["dimensao"]}, similaridade {x["similaridade"]}): '
                         f'"{x["texto_encontrado"]}" ↔ trecho "{x["trecho_relato"]}"' for x in rag[:10])
    r, tokens = llm.estruturado(SISTEMA.format(dimensoes=dims, feitas=perguntas_feitas, maximo=MAX_PERGUNTAS_EXTRAS),
                                f"RELATO:\n{texto}\n\nITENS ENCONTRADOS PELO RAG:\n{contexto}", FERRAMENTA,
                                max_tokens=700, papel="analista", temperatura=0.1)
    r["risco"] = bool(r.get("risco"))
    r["motivo_risco"] = (r.get("motivo_risco") or "").strip()
    if perguntas_feitas >= MAX_PERGUNTAS_EXTRAS:
        r["pergunta"] = None
    dims = list(base_itens()["dimensoes"])
    r["forcas"] = {d: min(1.0, max(0.0, float((r.get("forcas") or {}).get(d, 0) or 0))) for d in dims}
    r["pergunta"] = pergunta_permitida(texto, r["forcas"], perguntas_feitas, bool((r.get("pergunta") or "").strip()))
    lista = r.get("trechos_itens") or []
    r["trechos_itens"] = {t["item"]: t["trecho"] for t in lista if isinstance(t, dict) and t.get("item") and t.get("trecho")}
    return {**r, "rag": rag, "tokens": tokens, "modo": llm.ultimo_provedor() or "llm"}


def relato_vago(texto: str, forcas: dict) -> bool:
    """Critério objetivo: relato curto E sem nenhuma dimensão com indício claro."""
    return len(texto.split()) < PALAVRAS_MINIMAS and max(forcas.values() or [0]) < FORCA_CLARA


def pergunta_permitida(texto, forcas, feitas, modelo_quer_perguntar=True):
    """Só pergunta se o relato for vago (regra do código) e ainda houver pergunta disponível;
    a pergunta vem sempre da lista aprovada."""
    if feitas >= MAX_PERGUNTAS_EXTRAS or not relato_vago(texto, forcas):
        return None
    return PERGUNTAS_PADRAO[feitas] if (modelo_quer_perguntar or max(forcas.values() or [0]) < 0.3) else None


def _analisar_rag(rag, perguntas_feitas):
    """Sem LLM: força = maior similaridade de cada dimensão, normalizada."""
    forcas = {d: 0.0 for d in base_itens()["dimensoes"]}
    for x in rag:
        forcas[x["dimensao"]] = max(forcas[x["dimensao"]], x["similaridade"])
    maior = max(forcas.values()) or 1
    forcas = {d: round(v / maior, 2) for d, v in forcas.items()}
    vago = max(x["similaridade"] for x in rag) < 0.3 if rag else True
    pergunta = PERGUNTAS_PADRAO[perguntas_feitas] if vago and perguntas_feitas < MAX_PERGUNTAS_EXTRAS else None
    # (sem LLM, a força vem da similaridade relativa, então o critério de vagueza usa a similaridade absoluta)
    trechos = [{"dimensao": x["dimensao"], "trecho": x["trecho_relato"]} for x in rag[:4]]
    return {"forcas": forcas, "trechos": trechos, "trechos_itens": {}, "pergunta": pergunta, "rag": rag,
            "risco": False, "motivo_risco": "", "tokens": (None, None), "modo": "simulado"}
