"""Agente de análise de apoio à profissional + agente revisor.

Texto mais livre e humanizado: ajuda a profissional a pensar o caso, sugere caminhos para a conversa
e traz a literatura (RAG científico) com referências. Continua sem diagnóstico e sem conclusão, que
são da profissional. O revisor aponta problemas e a análise é refeita (até 3 tentativas)."""
from ..rag.indice import indice_ciencia
from ..validacao import checar_analise
from . import llm

DIMENSOES = ["Exaustão", "Distanciamento", "Cognitivo", "Emocional"]

FERRAMENTA = {"name": "escrever_analise", "description": "Escreve a análise de apoio à profissional.",
              "input_schema": {"type": "object", "properties": {
                  "abertura": {"type": "string", "description": "Parágrafo acolhedor (3 a 5 frases) com o panorama do caso."},
                  "leitura_por_dimensao": {"type": "array", "items": {"type": "object", "properties": {
                      "dimensao": {"type": "string", "enum": DIMENSOES}, "leitura": {"type": "string"}},
                      "required": ["dimensao", "leitura"]}, "description": "Uma leitura curta para cada uma das 4 dimensões."},
                  "o_que_o_relato_mostra": {"type": "string", "description": "Como o relato da pessoa conversa com os escores."},
                  "coerencia": {"type": "string", "description": "Leitura da coerência entre relato e respostas: o que converge, o que diverge, hipóteses para a divergência e como explorá-la na consulta."},
                  "comentarios_trechos": {"type": "array", "items": {"type": "object", "properties": {
                      "trecho": {"type": "string"}, "comentario": {"type": "string"}}, "required": ["trecho", "comentario"]},
                      "description": "Comentário breve sobre cada trecho destacado do relato (use o trecho exatamente como fornecido)."},
                  "pontos_a_explorar": {"type": "array", "items": {"type": "string"},
                                        "description": "TEMAS para a profissional investigar, escritos como afirmações curtas (não como perguntas). Ex.: 'Falta de reconhecimento no trabalho e o quanto pesa no desgaste.'"},
                  "sugestoes_de_conversa": {"type": "array", "items": {"type": "string"},
                                            "description": "PERGUNTAS abertas e acolhedoras que a profissional pode fazer ao paciente, cada uma terminando com '?'. Ex.: 'O que tem sido mais pesado para você no trabalho nas últimas semanas?'"},
                  "cuidados": {"type": "string", "description": "Sinais que merecem atenção e possíveis caminhos de cuidado, sem decidir por ela."},
                  "evidencias": {"type": "array", "items": {"type": "object", "properties": {
                      "afirmacao": {"type": "string"}, "fonte": {"type": "integer"}}, "required": ["afirmacao", "fonte"]}},
                  "limitacoes": {"type": "string"}},
                  "required": ["abertura", "leitura_por_dimensao", "o_que_o_relato_mostra", "coerencia", "comentarios_trechos",
                               "pontos_a_explorar", "sugestoes_de_conversa", "cuidados", "evidencias", "limitacoes"]}}

SISTEMA = """Você é uma colega experiente que escreve uma ANÁLISE DE APOIO para a profissional de saúde
(psicóloga ou médica) que vai atender uma pessoa, a partir de uma triagem de burnout (BAT) e de trechos
da literatura científica (RAG). Escreva em português do Brasil.

Tom: humano, acolhedor e técnico ao mesmo tempo, como uma conversa de supervisão entre colegas. Você tem
LIBERDADE para interpretar os dados, levantar hipóteses, relacionar o relato com os escores, sugerir
perguntas para a consulta e apontar caminhos de cuidado. Quem decide e conclui é a profissional.

Atenção especial à COERÊNCIA ENTRE RELATO E RESPOSTAS, fornecida pelo sistema. Só há DIVERGÊNCIA quando o
relato descreve uma dimensão com clareza e as respostas aos itens ficaram baixas: nesse caso, diga isso com destaque,
logo na abertura e no campo "coerencia". Exemplo de tom: "Pelo relato, seria esperado que a pessoa marcasse
frequências altas nos itens de exaustão, mas as respostas ficaram baixas nessa dimensão." Levante hipóteses
para a divergência (minimização dos sintomas, resposta apressada, leitura diferente dos itens, desejo de
causar boa impressão, mudança recente) e sugira como explorar na consulta, por exemplo retomando os itens
com a pessoa ou aplicando o BAT-23 completo. Nunca trate a divergência como erro da pessoa.
O sistema só aponta divergência quando ela é MUITO grande; não invente divergências que ele não apontou.
Se o sistema indicar que o relato não tem relação com os temas avaliados, explique com liberdade e sem julgar:
a pessoa pode ter se confundido com a tarefa (por exemplo, por pouca familiaridade com tecnologia), escrito
sobre outro assunto ou não ter se sentido à vontade para relatar; sugira conferir com ela o que quis dizer.
Respostas altas num tema que o relato não mencionou NÃO são divergência: o relato não precisa cobrir tudo.
Trate como achado complementar, a explorar na consulta, sem tom de alerta. Se o sistema informar que relato e
respostas convergem, diga que convergem.

FATOS DO BAT (não contradiga): o BAT tem QUATRO dimensões centrais: exaustão, distanciamento mental, prejuízo
cognitivo e prejuízo emocional. Os sintomas SECUNDÁRIOS são outros: queixas psicológicas (humor deprimido,
sofrimento psicológico) e psicossomáticas. Os escores vão de 1 (nunca) a 5 (sempre).

Limites que você nunca ultrapassa:
- Você pode levantar hipóteses ("sugere um quadro de burnout ocupacional"), mas NÃO classifique a gravidade
  nem o estágio (nada de "estágio avançado", "burnout grave", "grau moderado"): isso é avaliação clínica.
- Ao dizer o que o relato mostra, use só o que a pessoa realmente escreveu. Não atribua ao relato falas
  que ele não contém.
- Não faça diagnóstico nem conclusão: nada de "diagnóstico de", "a pessoa tem", "transtorno",
  "certamente", "com certeza", "confirma", "comprova". Prefira "sugere", "chama atenção", "vale explorar".
- Use só os números fornecidos, escritos exatamente como estão. Não calcule novos valores.
- Toda afirmação da literatura deve vir dos trechos fornecidos, citada com [n]. Não invente autores nem estudos.
- Lembre, com naturalidade, que os escores são estimados a partir de 8 itens.
- Em comentarios_trechos, use os trechos exatamente como foram fornecidos."""

SISTEMA_REVISOR = """Você revisa uma análise de apoio escrita por outra IA para uma profissional de saúde.
O texto PODE ser livre, acolhedor e interpretativo, e PODE levantar hipóteses como "sugere um quadro de burnout".

FATOS DO BAT (não contradiga): o BAT tem QUATRO dimensões centrais: exaustão, distanciamento mental, prejuízo
cognitivo e prejuízo emocional. Os sintomas SECUNDÁRIOS são outros: queixas psicológicas (humor deprimido,
sofrimento psicológico) e psicossomáticas. Os escores vão de 1 (nunca) a 5 (sempre).

Confira, item por item, e aponte só problemas reais:
1. Toda afirmação sobre "o que o relato diz" está mesmo no RELATO fornecido? (cite a afirmação que não está)
2. Alguma afirmação contradiz os FATOS DO BAT? (ex.: chamar uma dimensão central de sintoma secundário)
3. Há classificação de gravidade ou estágio, diagnóstico ou certeza indevida?
4. Afirmações da literatura têm fonte entre os trechos fornecidos? Os números estão nos dados?
5. "pontos_a_explorar" são temas (afirmações) e "sugestoes_de_conversa" são perguntas ao paciente?
6. O tom é alarmista ou minimiza sinais importantes? Há limitações?
Se estiver adequada, aprovado = true e problemas = []."""

FERRAMENTA_REVISOR = {"name": "revisar", "description": "Resultado da revisão.",
                      "input_schema": {"type": "object", "properties": {
                          "aprovado": {"type": "boolean"}, "problemas": {"type": "array", "items": {"type": "string"}}},
                          "required": ["aprovado", "problemas"]}}


FERRAMENTA_ROTEIRO = {"name": "planejar_analise", "description": "Roteiro da análise, antes de escrever.",
                      "input_schema": {"type": "object", "properties": {
                          "destaques": {"type": "array", "items": {"type": "string"}, "description": "O que mais chama atenção nos dados e no relato."},
                          "hipoteses": {"type": "array", "items": {"type": "string"}, "description": "Hipóteses a explorar, nunca diagnósticos."},
                          "fontes_uteis": {"type": "array", "items": {"type": "integer"}, "description": "Números dos trechos da literatura que ajudam."},
                          "perguntas": {"type": "array", "items": {"type": "string"}, "description": "Perguntas abertas para a consulta."}},
                          "required": ["destaques", "hipoteses", "fontes_uteis", "perguntas"]}}

SISTEMA_ROTEIRO = """Antes de escrever uma análise de apoio para uma profissional de saúde, faça um ROTEIRO curto
em português do Brasil: o que mais chama atenção nos escores e no relato, hipóteses a explorar (nunca
diagnóstico), quais trechos da literatura ajudam (pelo número) e perguntas abertas para a consulta."""

MAX_TENTATIVAS = 2          # escrever → revisar → reescrever uma vez, se preciso (equilíbrio com a velocidade)


def _br(v): return f"{v:.2f}".replace(".", ",")


def _fontes(relatos, est):
    ordem = sorted(est["escores"], key=lambda d: -est["escores"][d])
    consultas = [f"interpretação da dimensão {ordem[0]} no burnout", " ".join(relatos)[:400],
                 "demandas, recursos e recuperação no trabalho", "pontos de corte e limites dos escores do BAT",
                 "sobreposição com outros quadros e limites do autorrelato"]
    vistos, trechos = set(), []
    for q in consultas:
        for t in indice_ciencia().buscar(q, k=3):
            chave = (t["fonte"], t["texto"][:60])
            if chave not in vistos:
                vistos.add(chave); trechos.append(t)
    trechos = trechos[:8]
    # um número por DOCUMENTO (e não por trecho): a lista de referências fica sem repetições
    numero, fontes = {}, []
    for t in trechos:
        if t["fonte"] not in numero:
            numero[t["fonte"]] = len(numero) + 1
            fontes.append({"n": numero[t["fonte"]], "documento": t["documento"],
                           "referencia": t.get("referencia", t["documento"]), "arquivo": t["fonte"]})
    contexto = "\n\n".join(f"[{numero[t['fonte']]}] {t['documento']}\n{t['texto']}" for t in trechos)
    return fontes, contexto


def ajustar_secoes(c: dict) -> dict:
    """Se o modelo trocar as seções (perguntas em 'pontos a explorar' e explicações em 'sugestões'), destroca."""
    pontos, sugestoes = c.get("pontos_a_explorar") or [], c.get("sugestoes_de_conversa") or []
    perg = lambda xs: sum(str(x).strip().endswith("?") for x in xs)
    if pontos and sugestoes and perg(pontos) > len(pontos) / 2 and perg(sugestoes) < len(sugestoes) / 2:
        c["pontos_a_explorar"], c["sugestoes_de_conversa"] = sugestoes, pontos
    return c


def _forca_em_palavras(f):
    return "forte" if f >= 0.6 else "moderada" if f >= 0.35 else "fraca ou ausente"


def _dados(relatos, itens, est, coer=None):
    trechos = [f'"{i["trecho"]}" → {i["item"]} ({i["dimensao"]})' for i in itens if i.get("trecho")]
    coer = coer or {}
    indicios = {d["dimensao"]: _forca_em_palavras(d.get("forca_relato", 0))
                for d in coer.get("divergencias", []) + coer.get("coerentes", []) + coer.get("complementares", [])}
    return (f"RELATO DA PESSOA: {relatos}\nTRECHOS DESTACADOS: {trechos or 'nenhum'}\n"
            f"COERÊNCIA ENTRE RELATO E RESPOSTAS (calculada pelo sistema): {coer.get('resumo', 'não disponível')}\n"
            f"FORÇA DOS INDÍCIOS NO RELATO (dimensões com destaque): {indicios or 'sem destaque'}\n"
            f"ITENS APLICADOS E MOTIVOS: {[(i['item'], i['dimensao'], i['motivo']) for i in itens]}\n"
            f"ESCORES ESTIMADOS (1 a 5): { {d: _br(v) for d, v in est['escores'].items()} }\n"
            f"PERCENTIS (% da referência brasileira com escore menor): {est['percentis']}\n"
            f"ITENS POR DIMENSÃO: {est['itens_por_dimensao']}\nERRO MÉDIO ESPERADO: {_br(est['erro_medio_esperado'])}")


def _n(fontes, palavra, padrao=1):
    return next((f["n"] for f in fontes if palavra in f["documento"].lower()), padrao)


def _padrao(relatos, itens, est, fontes, coer=None):
    ordem = sorted(est["escores"], key=lambda d: -est["escores"][d])
    alto, baixo = ordem[0], ordem[-1]
    coer = coer or {}
    divergencias = coer.get("divergencias", [])
    todos_baixos = max(est["percentis"].values()) < 50
    n_bat, n_ctx, n_dif = _n(fontes, "bat"), _n(fontes, "ocupacional"), _n(fontes, "depressão")
    leituras = {
        "Exaustão": "Fala do cansaço físico e mental e da dificuldade de recuperar a energia.",
        "Distanciamento": "Mostra o quanto a pessoa tem se afastado mentalmente do trabalho.",
        "Cognitivo": "Reúne queixas de foco, memória e concentração no trabalho.",
        "Emocional": "Indica como anda a regulação das emoções no trabalho.",
    }
    if divergencias:
        abertura = ("O ponto que mais chama atenção é a diferença entre o relato e as respostas aos itens. "
                    + " ".join(d["texto"] for d in divergencias)
                    + f" Vale retomar essas respostas com a pessoa antes de interpretar os escores [{n_bat}].")
    elif todos_baixos:
        abertura = (f"Os escores estimados ficaram baixos em todas as dimensões: o mais alto foi {alto} "
                    f"({_br(est['escores'][alto])}), acima de {est['percentis'][alto]}% da referência brasileira [{n_bat}].")
    else:
        abertura = (f"Os dados chamam atenção principalmente para {alto}, com escore estimado de {_br(est['escores'][alto])}, "
                    f"acima de {est['percentis'][alto]}% da referência brasileira. {baixo} aparece como a dimensão mais baixa "
                    f"({_br(est['escores'][baixo])}). Vale olhar esse desenho junto com o relato, que ajuda a dar contexto [{n_bat}].")
    sem_relacao = any(d["tipo"] == "relato_sem_relacao" for d in divergencias)
    hipoteses = (" Hipóteses possíveis: confusão com a tarefa do relato (por exemplo, por pouca familiaridade com a "
                 "tecnologia), relato sobre outro assunto ou desconforto em relatar. Vale conferir com a pessoa o que quis dizer."
                 if sem_relacao else
                 " Hipóteses possíveis: minimização dos sintomas, resposta apressada, leitura diferente dos itens ou mudança "
                 "recente. Vale retomar os itens na consulta ou aplicar o BAT-23 completo.")
    coerencia_txt = (" ".join(d["texto"] for d in divergencias) + hipoteses) if divergencias \
        else coer.get("resumo", "Comparação indisponível nesta sessão.")
    foco = divergencias[0]["dimensao"] if divergencias and divergencias[0]["dimensao"] in est["escores"] else alto
    return {
        "abertura": abertura,
        "coerencia": coerencia_txt,
        "leitura_por_dimensao": [{"dimensao": d, "leitura": f"{leituras[d]} Escore estimado de {_br(est['escores'][d])}, "
                                  f"acima de {est['percentis'][d]}% da referência."} for d in DIMENSOES],
        "o_que_o_relato_mostra": "Os trechos destacados mostram as palavras da pessoa que levaram o sistema a escolher cada item.",
        "comentarios_trechos": [{"trecho": i["trecho"], "comentario": f"Associado a {i['item']} ({i['dimensao']})."}
                                for i in itens if i.get("trecho")],
        "pontos_a_explorar": [f"Como {foco.lower()} aparece no dia a dia de trabalho e há quanto tempo.",
                              f"Carga, organização do trabalho e apoio disponível [{n_ctx}].",
                              f"Recuperação depois da jornada e qualidade do sono [{n_ctx}].",
                              "Se vale aplicar o BAT-23 completo para ter escores calculados."],
        "sugestoes_de_conversa": ["O que tem sido mais pesado para você no trabalho nas últimas semanas?",
                                  "Como você se sente quando chega em casa depois do trabalho?",
                                  "O que costumava te ajudar a recarregar as energias?"],
        "cuidados": f"Vale observar sinais que vão além do trabalho, como tristeza persistente ou mudanças importantes de sono [{n_dif}].",
        "evidencias": [{"afirmacao": "Recuperação insuficiente e demandas persistentes estão associadas à exaustão.", "fonte": n_ctx},
                       {"afirmacao": "Questionários de autorrelato apoiam a triagem, mas não substituem a entrevista clínica.", "fonte": n_dif}],
        "limitacoes": ("Escores estimados por rede neural a partir de 8 itens; referência brasileira baseada em amostra de "
                       "conveniência; pontos de corte disponíveis definidos em amostras europeias."),
    }


def analisar(relatos: list[str], itens: list[dict], est: dict, coer: dict | None = None) -> dict:
    fontes, contexto = _fontes(relatos, est)
    validas = {f["n"] for f in fontes}
    permitidos = {_br(v) for v in est["escores"].values()} | {_br(est["erro_medio_esperado"]), "2,59", "3,02"}
    permitidos |= {f"{v:.1f}".replace(".", ",") for v in est["escores"].values()}      # arredondamentos aceitos
    eventos, tokens_total, revisao = [], [0, 0], {}

    def somar(t):
        if t and t[0]:
            tokens_total[0] += t[0]; tokens_total[1] += t[1]

    if llm.ativo():
        dados = _dados(relatos, itens, est, coer) + f"\n\nTRECHOS DA LITERATURA (cite pelo número):\n{contexto}"
        roteiro = ""
        try:                         # etapa 1: roteiro (modelos locais escrevem melhor com um plano)
            plano, t = llm.estruturado(SISTEMA_ROTEIRO, dados, FERRAMENTA_ROTEIRO, max_tokens=900, papel="apoio", temperatura=0.3); somar(t)
            roteiro = "\n\nSEU ROTEIRO (siga-o ao escrever):\n" + "\n".join(
                f"- {k}: {v}" for k, v in plano.items())
            eventos.append(f"roteiro: {plano}")
        except Exception as e:
            eventos.append(f"roteiro indisponível ({type(e).__name__})")
        retorno = ""
        for tentativa in range(MAX_TENTATIVAS):
            try:                     # etapa 2: o texto
                conteudo, t = llm.estruturado(SISTEMA, dados + roteiro + retorno, FERRAMENTA, max_tokens=3000,
                                              papel="apoio", temperatura=0.6); somar(t)
                conteudo = ajustar_secoes(conteudo)
            except Exception as e:
                eventos.append(f"LLM indisponível ({type(e).__name__}: {e})"); break
            chk = checar_analise(conteudo, permitidos, validas)
            try:                     # etapa 3: revisão por um segundo agente
                revisao, t = llm.estruturado(SISTEMA_REVISOR, f"DADOS:\n{dados}\n\nANÁLISE:\n{conteudo}", FERRAMENTA_REVISOR,
                                             max_tokens=600, papel="revisor", temperatura=0.0); somar(t)
            except Exception as e:
                revisao = {"aprovado": True, "problemas": [f"revisor indisponível ({type(e).__name__})"]}
            eventos.append(f"tentativa {tentativa + 1}: checagens {'ok' if chk['aprovado'] else chk}; revisor {revisao}")
            if chk["aprovado"] and revisao.get("aprovado"):
                return {"conteudo": conteudo, "checagens": chk, "revisao": revisao, "fontes": fontes,
                        "tokens": tuple(tokens_total), "eventos": eventos, "origem": f"{llm.nome_provedor(llm.ultimo_provedor())} (com revisão)"}
            problemas = [k for k, v in chk.items() if k != "aprovado" and not v] + revisao.get("problemas", [])
            retorno = "\n\nA VERSÃO ANTERIOR FOI REPROVADA. Corrija estes problemas: " + "; ".join(map(str, problemas))
    conteudo = _padrao(relatos, itens, est, fontes, coer)
    chk = checar_analise(conteudo, permitidos, validas)
    return {"conteudo": conteudo, "checagens": chk, "revisao": revisao, "fontes": fontes,
            "tokens": tuple(tokens_total) if tokens_total[0] else (None, None),
            "eventos": eventos + ["texto padrão do código"], "origem": "código"}
