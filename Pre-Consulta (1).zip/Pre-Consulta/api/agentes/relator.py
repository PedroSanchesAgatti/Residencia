"""Agente relator: escreve as partes descritivas do resumo de pré-consulta com apoio do RAG de normas.
Os números ficam fora do alcance do LLM: a tabela de escores é montada pelo código."""
from ..rag.indice import indice_normas
from ..validacao import checar
from . import llm

FERRAMENTA = {"name": "escrever_resumo", "description": "Escreve as seções descritivas do resumo de pré-consulta.",
              "input_schema": {"type": "object", "properties": {
                  "descricao_demanda": {"type": "string"}, "procedimento": {"type": "string"},
                  "analise": {"type": "string"}, "pontos_atencao": {"type": "string"}},
                  "required": ["descricao_demanda", "procedimento", "analise", "pontos_atencao"]}}

SISTEMA = """Você redige as seções descritivas de um RESUMO DE PRÉ-CONSULTA (não é documento psicológico),
em português do Brasil, para uso exclusivo da profissional de saúde responsável.

Regras obrigatórias:
- Linguagem impessoal, terceira pessoa, norma culta, objetiva (Resolução CFP 06/2019, art. 6).
- descricao_demanda: cite o relato da pessoa entre aspas, sem paráfrase que mude o sentido.
- procedimento: diga quais itens foram aplicados e por quê, usando os motivos fornecidos.
- analise: descreva os escores apenas em palavras e com os números EXATOS fornecidos; nunca recalcule.
- pontos_atencao: só fatos descritivos (ex.: dimensão medida com 1 item), nunca hipóteses clínicas.
- Proibido: diagnóstico, "a pessoa tem", "transtorno", qualquer conclusão ou encaminhamento.
- Cite as normas usadas com o número entre colchetes, ex.: [1].
- Não escreva a conclusão: ela é da profissional."""


def _contexto_normas(consulta: str):
    trechos = indice_normas().buscar(consulta, k=4)
    numero = {}
    for t in trechos:
        numero.setdefault(t["fonte"], len(numero) + 1)
        t["n"] = numero[t["fonte"]]
    return trechos, "\n\n".join(f"[{t['n']}] ({t['documento']})\n{t['texto']}" for t in trechos)


def _br(v): return f"{v:.2f}".replace(".", ",")


def _texto_padrao(relatos, itens, est):
    dims = sorted(est["escores"], key=lambda d: -est["escores"][d])
    poucos = [d for d, n in est["itens_por_dimensao"].items() if n == 1]
    return {
        "descricao_demanda": "A pessoa relatou: " + " ".join(f'"{r}"' for r in relatos),
        "procedimento": (f"Foram aplicados {len(itens)} itens do BAT, escolhidos a partir do relato e de regras de "
                         "cobertura das quatro dimensões [1]. Os escores foram estimados por rede neural."),
        "analise": (f"A dimensão com escore estimado mais alto foi {dims[0]} ({est["escores"][dims[0]]:.2f}), "
                    f"e a mais baixa, {dims[-1]} ({est['escores'][dims[-1]]:.2f}). Os valores são estimativas."),
        "pontos_atencao": ("Dimensões medidas com apenas 1 item: " + ", ".join(poucos) + ".") if poucos
                          else "Todas as dimensões foram medidas com pelo menos 2 itens.",
    }


def redigir(relatos: list[str], itens: list[dict], est: dict, coer: dict | None = None) -> dict:
    trechos, contexto = _contexto_normas("estrutura do relatório, linguagem, descrição da demanda, procedimento e análise")
    fontes = list({t["n"]: {"n": t["n"], "documento": t["documento"], "arquivo": t["fonte"]} for t in trechos}.values())
    permitidos = {f"{v:.2f}" for v in est["escores"].values()} | {f"{est['erro_medio_esperado']:.2f}"}
    eventos, secoes, tokens = [], None, (None, None)
    if llm.ativo():
        dados = (f"RELATO: {relatos}\nITENS APLICADOS E MOTIVOS: {itens}\n"
                 f"ESCORES ESTIMADOS (escala 1 a 5): {est['escores']}\nPERCENTIS (% da referência brasileira com escore menor): "
                 f"{est['percentis']}\nITENS POR DIMENSÃO: {est['itens_por_dimensao']}\n"
                 f"ERRO MÉDIO ESPERADO DA ESTIMATIVA: {est['erro_medio_esperado']:.2f}\n"
                 f"COERÊNCIA ENTRE RELATO E RESPOSTAS (calculada pelo sistema; cite de forma descritiva nos pontos de atenção): "
                 f"{(coer or {}).get('resumo', 'não disponível')}\n\nNORMAS RECUPERADAS:\n{contexto}")
        for tentativa in range(2):
            try:
                secoes, tokens = llm.estruturado(SISTEMA, dados, FERRAMENTA, max_tokens=1500, papel="relator", temperatura=0.2)
            except Exception as e:
                eventos.append(f"LLM indisponível ({type(e).__name__})"); break
            chk = checar(secoes, permitidos, relatos, {f["n"] for f in fontes})
            eventos.append(f"tentativa {tentativa + 1}: {'aprovado' if chk['aprovado'] else 'reprovado'} {chk}")
            if chk["aprovado"]:
                return {"secoes": secoes, "checagens": chk, "fontes": fontes, "tokens": tokens, "eventos": eventos, "origem": llm.nome_provedor(llm.ultimo_provedor())}
    secoes = _texto_padrao(relatos, itens, est)
    if coer and coer.get("divergencias"):
        secoes["pontos_atencao"] += " " + " ".join(d["texto"] for d in coer["divergencias"])
    chk = checar(secoes, permitidos, relatos, {f["n"] for f in fontes})
    return {"secoes": secoes, "checagens": chk, "fontes": fontes, "tokens": tokens,
            "eventos": eventos + ["texto padrão do código"], "origem": "código"}
