"""Rede neural com máscara: estima os 4 escores do BAT-23 a partir de qualquer conjunto de 8 itens."""
import json
import os
from functools import lru_cache

import numpy as np
import pandas as pd

from .config import PASTA_MODELOS, RAIZ

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")


@lru_cache
def regras() -> dict:
    return json.loads((PASTA_MODELOS / "regras.json").read_text(encoding="utf-8"))


@lru_cache
def _rede():
    import keras
    return keras.models.load_model(PASTA_MODELOS / "rede_mascara.keras")


@lru_cache
def _referencia() -> pd.DataFrame:
    """Escores BAT-23 dos trabalhadores brasileiros do dataset, para os percentis."""
    r = regras()
    df = pd.read_csv(RAIZ / "dados" / "bat_workers_ppfi_brasil.csv")[r["itens"]]
    return pd.DataFrame({d: df[its].mean(axis=1) for d, its in r["dimensoes"].items()})


def codificar(respostas: dict) -> np.ndarray:
    r = regras()
    valores = np.array([(respostas[c] - 3) / 2 if c in respostas else 0.0 for c in r["itens"]])
    mascara = np.array([1.0 if c in respostas else 0.0 for c in r["itens"]])
    return np.concatenate([valores, mascara])[None, :]


def estimar(respostas: dict) -> dict:
    """respostas: {"BAT1": 4, ...} com os itens aplicados (valores de 1 a 5)."""
    if any(not 1 <= int(v) <= 5 for v in respostas.values()):
        raise ValueError("As respostas devem estar entre 1 e 5.")
    r = regras()
    saida = np.clip(_rede()(codificar(respostas), training=False).numpy()[0], 1, 5)
    escores = {d: round(float(v), 2) for d, v in zip(r["dimensoes"], saida)}
    ref = _referencia()
    percentis = {d: int(round(100 * (ref[d] < v).mean())) for d, v in escores.items()}
    itens_por_dim = {d: sum(1 for c in respostas if c in its) for d, its in r["dimensoes"].items()}
    return {"escores": escores, "percentis": percentis, "itens_por_dimensao": itens_por_dim,
            "erro_medio_esperado": r["metricas_teste"]["mae_itens_variados"], "modelo": "rede_mascara"}
