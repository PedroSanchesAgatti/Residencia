"""Banco SQLite com SQLModel: sessões, relatos, itens, respostas, estimativas, relatórios e eventos."""
import json
from datetime import datetime
from typing import Optional

from sqlmodel import Field, Session, SQLModel, create_engine, select

from .config import BANCO

from sqlalchemy import event

# timeout: espera até 30 s por uma gravação em andamento, em vez de falhar em 5 s
motor = create_engine(f"sqlite:///{BANCO}", connect_args={"check_same_thread": False, "timeout": 30})


@event.listens_for(motor, "connect")
def _modo_wal(conexao, _):
    """WAL: leituras não esperam as gravações, e gravações curtas não travam o app."""
    cur = conexao.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA busy_timeout=30000")
    cur.close()


def agora() -> str:
    return datetime.now().isoformat(timespec="seconds")


class Sessao(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    codigo: str                                  # só o código: o sistema não guarda o nome do paciente
    estado: str = "relato"                       # relato → perguntas → questionario → resultado → relatorio
    perguntas_feitas: int = 0
    docs_estado: str = "aguardando"              # aguardando → processando → resumo (análise em preparo) → pronto (ou erro)
    visto: bool = False                          # a profissional já abriu os resultados?
    finalizada_em: Optional[str] = None          # quando o paciente concluiu o questionário
    arquivada: bool = False                      # some da lista principal, mas os dados ficam guardados
    criada_em: str = Field(default_factory=agora)


class Relato(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    tipo: str                                    # "inicial", "pergunta" ou "resposta"
    texto: str
    criado_em: str = Field(default_factory=agora)


class ItemSelecionado(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    ordem: int
    item: str
    dimensao: str
    motivo: str
    # trecho do relato ligado ao item (palavras exatas da pessoa) e onde ele está
    trecho: Optional[str] = None
    parte: Optional[int] = None                  # 0 = relato inicial; 1 e 2 = respostas às perguntas extras
    inicio: Optional[int] = None
    fim: Optional[int] = None
    forca: Optional[str] = None                  # "forte" ou "moderada"
    expressao: Optional[str] = None              # expressão da base que mais se parece com o trecho
    origem_trecho: Optional[str] = None          # "agente" ou "busca"


class Resposta(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    item: str
    valor: int


class Estimativa(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    escores_json: str                            # {"Exaustão": 3.2, ...}
    percentis_json: str
    modelo: str
    criada_em: str = Field(default_factory=agora)


class Relatorio(SQLModel, table=True):
    """Resumo de pré-consulta. Guarda as seções; o HTML é montado na hora (com a conclusão atual)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    secoes_json: str
    fontes_json: str
    checagens_json: str
    origem: str = "código"
    criado_em: str = Field(default_factory=agora)


class Conclusao(SQLModel, table=True):
    """Escrita só pela profissional. O LLM nunca lê nem escreve este campo."""
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id", unique=True)
    texto: str
    profissional_nome: str                       # a identificação da profissional entra na assinatura
    profissional_crp: str
    atualizada_em: str = Field(default_factory=agora)


class AnaliseApoio(SQLModel, table=True):
    """Análise de apoio à profissional, gerada por IA a partir do resumo e da literatura (RAG)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    conteudo_json: str
    fontes_json: str
    checagens_json: str
    revisao_json: str = "{}"
    origem: str = "código"
    criado_em: str = Field(default_factory=agora)


class Evento(SQLModel, table=True):
    """Tudo o que agentes, RAG e modelos fizeram: alimenta o raio-X do painel."""
    id: Optional[int] = Field(default=None, primary_key=True)
    sessao_id: int = Field(foreign_key="sessao.id")
    origem: str                                  # seguranca, analista, rag_itens, seletor, rede, relator, validacao
    descricao: str
    dados_json: str = "{}"
    tokens_entrada: Optional[int] = None
    tokens_saida: Optional[int] = None
    criado_em: str = Field(default_factory=agora)


VERSAO_ESQUEMA = 5


def criar_tabelas():
    """Cria as tabelas. Se o banco for de uma versão antiga do protótipo, guarda uma cópia e recomeça."""
    import os
    import sqlite3
    import time
    if os.path.exists(BANCO):
        with sqlite3.connect(BANCO) as c:
            versao = c.execute("PRAGMA user_version").fetchone()[0]
        if versao == 4:                          # migração 4 → 5 sem perder os atendimentos
            with sqlite3.connect(BANCO) as c:
                c.execute("ALTER TABLE sessao ADD COLUMN arquivada BOOLEAN NOT NULL DEFAULT 0")
        elif versao != VERSAO_ESQUEMA:
            motor.dispose()
            os.replace(BANCO, f"{BANCO}.antigo_{int(time.time())}")
    SQLModel.metadata.create_all(motor)
    with sqlite3.connect(BANCO) as c:
        c.execute(f"PRAGMA user_version = {VERSAO_ESQUEMA}")


def registrar(s: Session, sessao_id: int, origem: str, descricao: str, dados=None, tokens=(None, None)):
    s.add(Evento(sessao_id=sessao_id, origem=origem, descricao=descricao,
                 dados_json=json.dumps(dados or {}, ensure_ascii=False), tokens_entrada=tokens[0], tokens_saida=tokens[1]))


def textos(s: Session, sessao_id: int, tipo: Optional[str] = None):
    q = select(Relato).where(Relato.sessao_id == sessao_id)
    if tipo:
        q = q.where(Relato.tipo == tipo)
    return list(s.exec(q.order_by(Relato.id)))
