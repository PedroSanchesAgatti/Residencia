"""Checagens automáticas do texto escrito pelo relator, antes de chegar à profissional."""
import re

# Linguagem de diagnóstico. "A pessoa tem" só é proibido quando seguido de um quadro clínico,
# para não barrar frases legítimas como "a pessoa tem relatado cansaço".
PROIBIDOS = [r"diagn[óo]stico d[eo]", r"\btranstorno", r"sofre de", r"\bportador", r"burnout confirmad",
             r"est[áa] com (burnout|depress|ansiedade)",
             r"(a pessoa|voc[êe]|o paciente|a paciente) tem (burnout|depress|ansiedade|s[íi]ndrome|um quadro)"]
TERMOS_PROIBIDOS = PROIBIDOS


def tem_diagnostico(texto: str) -> bool:
    return any(re.search(p, texto.lower()) for p in PROIBIDOS)
SECOES = ["descricao_demanda", "procedimento", "analise", "pontos_atencao"]


def _numeros(texto: str) -> set[str]:
    return {n.replace(",", ".") for n in re.findall(r"\d+[.,]\d+", texto)}


def checar(secoes: dict, permitidos: set[str], relatos: list[str], fontes_validas: set[int]) -> dict:
    texto = " ".join(str(secoes.get(s, "")) for s in SECOES)
    baixo = texto.lower()
    resultado = {
        "estrutura_completa": all(str(secoes.get(s, "")).strip() for s in SECOES),
        "sem_diagnostico": not tem_diagnostico(texto),
        "numeros_fieis": _numeros(texto) <= {p.replace(",", ".") for p in permitidos},
        "relato_entre_aspas": any(f'"{r.strip()[:25]}' in texto or f"“{r.strip()[:25]}" in texto for r in relatos if r.strip()),
        "fontes_rastreaveis": {int(n) for n in re.findall(r"\[(\d+)\]", texto)} <= fontes_validas,
    }
    resultado["aprovado"] = all(resultado.values())
    return resultado


TERMOS_CERTEZA = ["certamente", "com certeza", "confirma o", "confirma a", "comprova", "sem dúvida", "sem dúvidas",
                  "corrobora", "corroboram"]
# Hipóteses ("sugere um quadro de burnout") são permitidas. Classificar a gravidade ou o estágio, não:
GRAVIDADE = [r"est[áa]gio (inicial|intermedi[áa]rio|avan[çc]ado|grave|severo)", r"\bgrau (leve|moderado|grave|severo)",
             r"burnout (leve|moderado|grave|severo|avan[çc]ado)", r"esgotamento (grave|severo|avan[çc]ado)",
             r"quadro (grave|severo|avan[çc]ado)", r"\bem fase (inicial|avan[çc]ada)"]


def classifica_gravidade(texto: str) -> bool:
    return any(re.search(p, texto.lower()) for p in GRAVIDADE)


def _textos_analise(c: dict) -> list[str]:
    partes = [c.get("abertura", ""), c.get("o_que_o_relato_mostra", ""), c.get("coerencia", ""), c.get("cuidados", ""), c.get("limitacoes", "")]
    partes += [d.get("leitura", "") for d in c.get("leitura_por_dimensao", [])]
    partes += [t.get("comentario", "") for t in c.get("comentarios_trechos", [])]
    partes += list(c.get("pontos_a_explorar", [])) + list(c.get("sugestoes_de_conversa", []))
    partes += [e.get("afirmacao", "") for e in c.get("evidencias", [])]
    return [str(p) for p in partes]


def checar_analise(c: dict, permitidos: set[str], fontes_validas: set[int]) -> dict:
    """Checagens da análise de apoio. O texto é mais livre e acolhedor, mas continua sem diagnóstico,
    sem certezas clínicas, com números fiéis e fontes rastreáveis."""
    texto = " ".join(_textos_analise(c))
    baixo = texto.lower()
    citadas = {int(n) for n in re.findall(r"\[(\d+)\]", texto)} | {int(e.get("fonte", 0)) for e in c.get("evidencias", [])}
    resultado = {
        "estrutura_completa": all(c.get(k) for k in ["abertura", "leitura_por_dimensao", "pontos_a_explorar", "evidencias", "limitacoes"]),
        "sem_diagnostico": not tem_diagnostico(texto),
        "tom_de_hipotese": not any(t in baixo for t in TERMOS_CERTEZA),
        "sem_classificar_gravidade": not classifica_gravidade(texto),
        "numeros_fieis": _numeros(texto) <= {p.replace(",", ".") for p in permitidos},
        "fontes_rastreaveis": bool(citadas) and citadas <= fontes_validas,
    }
    resultado["aprovado"] = all(resultado.values())
    return resultado
