"""Liga cada item escolhido às palavras exatas do relato que o justificam.

1. Se o agente analista indicou um trecho para o item, ele só é aceito se existir LITERALMENTE no relato.
2. Senão, procura a janela de 2 a 6 palavras do relato mais parecida (embeddings) com o item e suas expressões.
O relato nunca é alterado: guardamos apenas a posição do trecho, para destacar na hora de mostrar."""
import re

from .rag.indice import base_itens, indice_itens

LIMIAR_TRECHO = 0.45
LIMIAR_FORTE = 0.62


def localizar(trecho: str, partes: list[str]):
    """Devolve (parte, inicio, fim) se o trecho existe no relato (sem diferenciar maiúsculas), senão None."""
    alvo = (trecho or "").strip().strip('"“”\'').strip()
    if len(alvo) < 3:
        return None
    for k, texto in enumerate(partes):
        i = texto.lower().find(alvo.lower())
        if i >= 0:
            return k, i, i + len(alvo)
    return None


def _janelas(partes: list[str], minimo=2, maximo=6):
    """Grupos de 2 a 6 palavras seguidas, sem atravessar pontuação (vírgula, ponto, ponto e vírgula...)."""
    for k, texto in enumerate(partes):
        for frase in re.finditer(r"[^.,;:!?\n]+", texto):
            palavras = [(frase.start() + m.start(), frase.start() + m.end())
                        for m in re.finditer(r"[\wÀ-ÿ'-]+", frase.group())]
            for n in range(minimo, maximo + 1):
                for a in range(0, max(0, len(palavras) - n + 1)):
                    ini, fim = palavras[a][0], palavras[a + n - 1][1]
                    yield k, ini, fim, texto[ini:fim]


def melhor_janela(item: str, partes: list[str]):
    """Janela do relato mais parecida com o item (texto oficial + expressões). Devolve dict ou None."""
    idx = indice_itens()
    alvos = [d for d in idx.docs if d["item"] == item]
    if not alvos:
        return None
    janelas = list(_janelas(partes))
    if not janelas:
        return None
    v_jan = idx.cod([j[3] for j in janelas])
    v_alvo = idx.cod([d["texto"] for d in alvos])
    sim = v_jan @ v_alvo.T                                   # (janelas × alvos)
    i, j = divmod(int(sim.argmax()), sim.shape[1])
    melhor = float(sim[i, j])
    if melhor < LIMIAR_TRECHO:
        return None
    k, ini, fim, texto = janelas[i]
    return {"trecho": texto, "parte": k, "inicio": ini, "fim": fim, "similaridade": round(melhor, 3), "expressao": alvos[j]["texto"]}


LIMIAR_DIMENSAO = 0.35     # só procura trecho por busca se o relato indicar a dimensão do item
MARGEM_DIMENSAO = 0.05     # a frase do trecho precisa "soar" mais como a dimensão do item do que como as outras


def frase_de(texto: str, ini: int, fim: int) -> str:
    """A frase inteira (entre pontos finais) onde o trecho está."""
    a = max(texto.rfind(c, 0, ini) for c in ".!?;\n") + 1
    fins = [i for i in (texto.find(c, fim) for c in ".!?;\n") if i >= 0]
    return texto[a:min(fins) if fins else len(texto)].strip()


def similaridade_por_dimensao(frase: str) -> dict:
    idx = indice_itens()
    sim = idx.vetores @ idx.cod([frase])[0]
    por_dim = {}
    for d, v in zip((x["dimensao"] for x in idx.docs), sim):
        por_dim[d] = max(por_dim.get(d, -1.0), float(v))
    return por_dim


def compativel(item_dim: str, texto: str, ini: int, fim: int) -> bool:
    """O trecho só vale para o item se a frase onde ele está combina com a dimensão do item.
    Evita, por exemplo, ligar "sem saber explicar" (de "fico triste sem saber explicar") à concentração."""
    sims = similaridade_por_dimensao(frase_de(texto, ini, fim))
    return sims.get(item_dim, -1) >= max(sims.values()) - MARGEM_DIMENSAO


def associar(itens: list[dict], partes: list[str], trechos_agente: dict[str, str], forcas: dict | None = None) -> list[dict]:
    """Acrescenta a cada item escolhido o trecho do relato (quando houver).
    Itens de dimensões que o relato não indica (só cobertura mínima) não recebem trecho pela busca,
    para não ligar, por exemplo, "esgotada" a um item de concentração."""
    textos_itens = {i["id"]: i for i in base_itens()["itens"]}
    saida = []
    for it in itens:
        novo = dict(it)
        pos = localizar(trechos_agente.get(it["item"], ""), partes)
        if pos and not compativel(it["dimensao"], partes[pos[0]], pos[1], pos[2]):
            pos = None
        if pos:
            k, ini, fim = pos
            jan = melhor_janela(it["item"], [partes[k][ini:fim]]) or {}
            novo.update(trecho=partes[k][ini:fim], parte=k, inicio=ini, fim=fim, origem_trecho="agente",
                        forca="forte" if jan.get("similaridade", 0) >= LIMIAR_FORTE else "moderada",
                        expressao=jan.get("expressao") or textos_itens[it["item"]]["expressoes"][0])
        elif not it["motivo"].startswith("cobertura") and (forcas is None or forcas.get(it["dimensao"], 0) >= LIMIAR_DIMENSAO):
            jan = melhor_janela(it["item"], partes)
            if jan and not compativel(it["dimensao"], partes[jan["parte"]], jan["inicio"], jan["fim"]):
                jan = None
            if jan:
                novo.update(trecho=jan["trecho"], parte=jan["parte"], inicio=jan["inicio"], fim=jan["fim"],
                            origem_trecho="busca", expressao=jan["expressao"],
                            forca="forte" if jan["similaridade"] >= LIMIAR_FORTE else "moderada")
        if novo.get("trecho") and novo["motivo"].startswith("ligado"):
            novo["motivo"] = "ligado ao relato"
        saida.append(novo)
    return saida


def destaques_por_parte(itens: list[dict], n_partes: int) -> list[list[dict]]:
    """Agrupa os trechos por parte do relato, juntando sobreposições (um destaque pode servir a vários itens)."""
    grupos = [[] for _ in range(n_partes)]
    for it in itens:
        if it.get("trecho") is not None and it.get("parte") is not None and it["parte"] < n_partes:
            grupos[it["parte"]].append({"inicio": it["inicio"], "fim": it["fim"], "itens": [it["item"]],
                                        "dimensoes": [it["dimensao"]], "forca": it.get("forca")})
    for g in grupos:
        g.sort(key=lambda x: x["inicio"])
        juntos = []
        for d in g:
            if juntos and d["inicio"] < juntos[-1]["fim"]:
                u = juntos[-1]
                u["fim"] = max(u["fim"], d["fim"]); u["itens"] += d["itens"]
                u["dimensoes"] += [x for x in d["dimensoes"] if x not in u["dimensoes"]]
            else:
                juntos.append(d)
        g[:] = juntos
    return grupos
