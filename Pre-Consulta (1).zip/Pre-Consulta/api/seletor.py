"""Seletor de itens (código, não agente): escolhe os 8 itens com regras fixas e auditáveis.

Regras:
1. Pelo menos 1 item por dimensão, para nenhuma ficar sem medida.
2. Os outros 4 vão para as dimensões indicadas pelo relato, na proporção da força de cada indício.
   Sem indícios claros, usa 2 itens por dimensão (os mais informativos).
3. Dentro de cada dimensão, primeiro os itens que o RAG ligou ao relato; depois os mais informativos.
"""
from .rede import regras

LIMIAR_INDICIO = 0.35        # força mínima para uma dimensão receber itens extras
LIMIAR_SIMILARIDADE = 0.45   # similaridade mínima para dizer que o item "apareceu" no relato


def distribuir(forcas: dict, total: int = 8) -> dict:
    dims = list(regras()["dimensoes"])
    cota = {d: 1 for d in dims}
    extras = total - len(dims)
    indicadas = {d: f for d, f in forcas.items() if f >= LIMIAR_INDICIO}
    if not indicadas:
        return {d: 2 for d in dims}
    soma = sum(indicadas.values())
    brutos = {d: extras * f / soma for d, f in indicadas.items()}
    for d, v in brutos.items():
        cota[d] += int(v)
    sobra = total - sum(cota.values())
    for d in sorted(brutos, key=lambda x: brutos[x] - int(brutos[x]), reverse=True)[:sobra]:
        cota[d] += 1
    tamanho = {d: len(its) for d, its in regras()["dimensoes"].items()}
    for d in dims:                                   # nunca mais itens do que a dimensão tem
        excesso = cota[d] - tamanho[d]
        if excesso > 0:
            cota[d] = tamanho[d]
            for outra in sorted(dims, key=lambda x: -forcas.get(x, 0)):
                livre = tamanho[outra] - cota[outra]
                dar = min(livre, excesso)
                cota[outra] += dar; excesso -= dar
    return cota


def selecionar(forcas: dict, itens_rag: list[dict], total: int = 8) -> list[dict]:
    r = regras()
    cota = distribuir(forcas, total)
    citados = {x["item"]: x for x in itens_rag if x["similaridade"] >= LIMIAR_SIMILARIDADE}
    escolhidos = []
    indicadas = {k for k, f in forcas.items() if f >= LIMIAR_INDICIO}
    for d, n in cota.items():
        # numa dimensão que o relato não indica, a ligação do RAG é ruído: vale só a cobertura mínima
        cit = citados if d in indicadas else {}
        candidatos = sorted(r["dimensoes"][d], key=lambda c: (c not in cit,
                                                              -(cit[c]["similaridade"] if c in cit else 0),
                                                              r["ranking"][d].index(c)))
        for c in candidatos[:n]:
            if c in cit:
                motivo = f'ligado ao relato: "{cit[c]["trecho_relato"]}"'
            elif n > 1 and d in indicadas:
                motivo = "dimensão indicada pelo relato; item mais informativo restante"
            else:
                motivo = "cobertura mínima da dimensão; item mais informativo"
            escolhidos.append({"item": c, "dimensao": d, "motivo": motivo})
    return escolhidos
