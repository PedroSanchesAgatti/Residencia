"""Configurações lidas do .env (com valores padrão seguros para rodar localmente)."""
import os
from pathlib import Path

from dotenv import load_dotenv

RAIZ = Path(__file__).resolve().parent.parent
load_dotenv(RAIZ / ".env")

BANCO = os.getenv("BANCO", str(RAIZ / "dados" / "bat.db"))
PASTA_MODELOS = RAIZ / "modelos"
PASTA_CONHECIMENTO = RAIZ / "conhecimento"

# Modo do modelo de linguagem:
#   "ollama"     → só modelos locais (nenhum dado sai do computador)
#   "anthropic"  → só a API da Anthropic (precisa de ANTHROPIC_API_KEY e internet)
#   "automatico" → tenta o Ollama; se ele falhar (ex.: falta de memória), usa a Anthropic
#   "simulado"   → sem modelo de linguagem (testes e plano B)
LLM_MODO = os.getenv("LLM_MODO", "ollama").lower().replace("á", "a")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
# Modelo rápido para analista e relator; modelo mais forte para a análise de apoio e o revisor
ANTHROPIC_MODELO = os.getenv("ANTHROPIC_MODELO", "claude-haiku-5-5")
ANTHROPIC_MODELO_APOIO = os.getenv("ANTHROPIC_MODELO_APOIO", "claude-sonnet-5-5")
# No modo automático, depois de uma falha do Ollama, vai direto para a Anthropic por este tempo (segundos)
PAUSA_OLLAMA = float(os.getenv("PAUSA_OLLAMA", "600"))
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
# Modelo rápido para as etapas em que alguém espera (guardião, analista, relator)
OLLAMA_MODELO = os.getenv("OLLAMA_MODELO", "qwen2.5:7b")
# Modelo maior para a análise de apoio e o revisor (rodam em segundo plano)
OLLAMA_MODELO_APOIO = os.getenv("OLLAMA_MODELO_APOIO", "qwen2.5:14b")
# Quanto tempo cada modelo fica carregado na memória depois de usado
OLLAMA_MANTER = os.getenv("OLLAMA_MANTER", "30m")              # modelo rápido: fica pronto
OLLAMA_MANTER_APOIO = os.getenv("OLLAMA_MANTER_APOIO", "2m")    # modelo grande: libera a memória logo
OLLAMA_CONTEXTO = int(os.getenv("OLLAMA_CONTEXTO", "8192"))
OLLAMA_TIMEOUT = float(os.getenv("OLLAMA_TIMEOUT", "300"))

# Modelo de embeddings local (baixado na primeira execução pelo sentence-transformers)
EMBEDDINGS_MODELO = os.getenv("EMBEDDINGS_MODELO", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

MAX_PERGUNTAS_EXTRAS = 2
TOTAL_ITENS = 8

# PIN local para sair do modo paciente (não é segurança de verdade: evita acesso acidental na demonstração)
PIN_PROFISSIONAL = os.getenv("PIN_PROFISSIONAL", "1234")
