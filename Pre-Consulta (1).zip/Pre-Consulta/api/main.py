"""API do check-in BAT de pré-consulta. Rode com:  uvicorn api.main:app --reload
Documentação interativa: http://127.0.0.1:8000/docs"""
import json
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from . import banco, coerencia, rede, seguranca, seletor, trechos
from .agentes import analista, apoio, llm, relator
from .banco import (AnaliseApoio, Conclusao, Estimativa, Evento, ItemSelecionado, Relato, Relatorio, Resposta, Sessao,
                    registrar, textos)
from .config import LLM_MODO, MAX_PERGUNTAS_EXTRAS, PIN_PROFISSIONAL
from .documento import html_analise, html_resumo
from .rag.embeddings import tipo as tipo_embeddings
from .rag.indice import base_itens, indice_ciencia, indice_itens, indice_normas, itens_do_relato


@asynccontextmanager
async def ciclo(app):
    banco.criar_tabelas()
    indice_itens(); indice_normas(); indice_ciencia(); rede.regras()      # aquece índices e modelo
    import threading
    threading.Thread(target=llm.aquecer, daemon=True).start()            # carrega o modelo local sem travar a API
    yield

app = FastAPI(title="Pre-Consulta", version="2.4.0", lifespan=ciclo)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def sessao_bd():
    with Session(banco.motor) as s:
        yield s


def obter(s: Session, sid: int) -> Sessao:
    se = s.get(Sessao, sid)
    if not se:
        raise HTTPException(404, "Sessão não encontrada.")
    return se


class NovaSessao(BaseModel):
    codigo: str = Field(min_length=1, max_length=40)       # só o código: o sistema não recebe o nome do paciente


class Texto(BaseModel):
    texto: str = Field(min_length=1)


class Respostas(BaseModel):
    respostas: dict[str, int]


class TextoConclusao(BaseModel):
    texto: str = Field(min_length=1, max_length=8000)
    profissional_nome: str = Field(min_length=3, max_length=120)
    profissional_crp: str = Field(min_length=3, max_length=30)


class Pin(BaseModel):
    pin: str


class EdicaoSessao(BaseModel):
    codigo: str | None = Field(default=None, min_length=1, max_length=40)
    arquivada: bool | None = None


# ---------------------------------------------------------------- utilidades
def _partes(s: Session, sid: int) -> list[str]:
    return [r.texto for r in textos(s, sid) if r.tipo in ("inicial", "resposta")]


def _blocos(s: Session, sid: int) -> list[dict]:
    """Relato em partes, com títulos: relato inicial e respostas às perguntas extras."""
    blocos, pergunta, n = [], None, 0
    for r in textos(s, sid):
        if r.tipo == "inicial":
            blocos.append({"titulo": "Relato inicial", "texto": r.texto})
        elif r.tipo == "pergunta":
            pergunta = r.texto; n += 1
        elif r.tipo == "resposta":
            blocos.append({"titulo": f"Resposta à pergunta extra {n}: {pergunta}", "texto": r.texto})
    return blocos


def _itens(s: Session, sid: int) -> list[dict]:
    campos = ["item", "dimensao", "motivo", "trecho", "parte", "inicio", "fim", "forca", "expressao", "origem_trecho"]
    lst = s.exec(select(ItemSelecionado).where(ItemSelecionado.sessao_id == sid).order_by(ItemSelecionado.ordem)).all()
    return [{c: getattr(i, c) for c in campos} for i in lst]


def _com_texto(itens):
    textos_itens = {i["id"]: i["texto"] for i in base_itens()["itens"]}
    return [{**i, "texto": textos_itens[i["item"]]} for i in itens]


def _respostas(s: Session, sid: int) -> dict:
    return {r.item: r.valor for r in s.exec(select(Resposta).where(Resposta.sessao_id == sid))}


def _forcas(s: Session, sid: int) -> dict | None:
    """Forças dos indícios do relato (última análise do agente analista nesta sessão).
    Só valem quando vieram do modelo de linguagem: sem ele, as forças são relativas (vindas só da busca)
    e não servem para comparar com os escores."""
    ev = s.exec(select(Evento).where(Evento.sessao_id == sid, Evento.origem == "analista")
                .order_by(Evento.id.desc())).first()
    if not ev or "simulado" in ev.descricao or "RAG sem LLM" in ev.descricao:
        return None
    return json.loads(ev.dados_json).get("forcas")


def _ultimo(s: Session, modelo, sid: int):
    return s.exec(select(modelo).where(modelo.sessao_id == sid).order_by(modelo.id.desc())).first()


# ---------------------------------------------------------------- configuração
@app.get("/saude")
def saude():
    return {"ok": True, "llm": LLM_MODO, "local": llm.situacao(), "embeddings": tipo_embeddings(),
            "rede": rede.regras()["metricas_teste"]}


@app.post("/config/pin")
def verificar_pin(dados: Pin):
    return {"ok": dados.pin == PIN_PROFISSIONAL}


# ---------------------------------------------------------------- fluxo do paciente
@app.post("/sessoes")
def criar(dados: NovaSessao, s: Session = Depends(sessao_bd)):
    se = Sessao(**dados.model_dump()); s.add(se); s.commit(); s.refresh(se)
    return {"id": se.id, "codigo": se.codigo, "estado": se.estado}


@app.post("/sessoes/{sid}/relato")
def relato(sid: int, dados: Texto, s: Session = Depends(sessao_bd)):
    """Recebe o relato inicial ou a resposta a uma pergunta extra. Devolve nova pergunta ou os 8 itens."""
    se = obter(s, sid)
    if se.estado not in ("relato", "perguntas"):
        raise HTTPException(409, f"A sessão está na etapa '{se.estado}'.")
    s.add(Relato(sessao_id=sid, tipo="inicial" if se.estado == "relato" else "resposta", texto=dados.texto))

    def interromper(origem, motivo, tokens=(None, None)):
        registrar(s, sid, origem, "risco detectado", {"motivo": motivo}, tokens)
        se.estado = "interrompida"; se.docs_estado = "interrompida"; se.finalizada_em = banco.agora(); s.commit()
        return {"estado": "interrompida", "mensagem": seguranca.MENSAGEM}

    if seguranca.risco_explicito(dados.texto):            # rede de segurança: regra fixa, instantânea
        return interromper("seguranca", "regra fixa")

    s.commit()                                              # libera o banco antes da chamada à IA
    partes = _partes(s, sid)
    a = analista.analisar(partes, se.perguntas_feitas)      # o analista também verifica risco (frases indiretas)
    registrar(s, sid, "rag_itens", "itens próximos do relato", {"itens": a["rag"][:8]})
    if a.get("risco"):
        return interromper("analista", a.get("motivo_risco") or "indicado pelo analista", a["tokens"])
    registrar(s, sid, "analista", f"indícios ({a['modo']})", {"forcas": a["forcas"], "trechos_itens": a["trechos_itens"],
              "pergunta": a["pergunta"], "risco": False}, a["tokens"])

    if a["pergunta"] and se.perguntas_feitas < MAX_PERGUNTAS_EXTRAS:
        se.perguntas_feitas += 1; se.estado = "perguntas"
        s.add(Relato(sessao_id=sid, tipo="pergunta", texto=a["pergunta"])); s.commit()
        return {"estado": "perguntas", "pergunta": a["pergunta"], "restantes": MAX_PERGUNTAS_EXTRAS - se.perguntas_feitas}

    itens = trechos.associar(seletor.selecionar(a["forcas"], a["rag"]), partes, a["trechos_itens"], a["forcas"])
    for k, it in enumerate(itens):
        s.add(ItemSelecionado(sessao_id=sid, ordem=k, **it))
    registrar(s, sid, "seletor", "8 itens escolhidos", {"cota": seletor.distribuir(a["forcas"]), "itens": itens})
    se.estado = "questionario"; s.commit()
    return {"estado": "questionario", "itens": [{k: v for k, v in i.items() if k in ("item", "dimensao", "texto")} for i in _com_texto(itens)]}


@app.post("/sessoes/{sid}/respostas")
def responder(sid: int, dados: Respostas, tarefas: BackgroundTasks, s: Session = Depends(sessao_bd)):
    """Registra as respostas e prepara os documentos em segundo plano: o paciente não espera."""
    se = obter(s, sid)
    if se.estado != "questionario":
        raise HTTPException(409, f"A sessão está na etapa '{se.estado}'.")
    esperados = {i["item"] for i in _itens(s, sid)}
    if set(dados.respostas) != esperados:
        raise HTTPException(422, f"Responda exatamente aos itens selecionados: {sorted(esperados)}")
    if any(not 1 <= v <= 5 for v in dados.respostas.values()):
        raise HTTPException(422, "As respostas devem estar entre 1 e 5.")
    for item, v in dados.respostas.items():
        s.add(Resposta(sessao_id=sid, item=item, valor=v))
    est = rede.estimar(dados.respostas)
    s.add(Estimativa(sessao_id=sid, escores_json=json.dumps(est["escores"], ensure_ascii=False),
                     percentis_json=json.dumps(est["percentis"], ensure_ascii=False), modelo=est["modelo"]))
    registrar(s, sid, "rede", "escores estimados", est)
    se.estado, se.docs_estado, se.finalizada_em = "resultado", "processando", banco.agora()
    s.commit()
    tarefas.add_task(gerar_documentos, sid)
    return {"estado": "concluida"}           # o paciente não recebe escores


# ---------------------------------------------------------------- documentos
def _gerar_resumo(s: Session, se: Sessao) -> dict:
    sid = se.id
    itens, est = _itens(s, sid), rede.estimar(_respostas(s, sid))
    coer = coerencia.comparar(_forcas(s, sid), est)
    partes = _partes(s, sid)
    s.commit()                                              # nenhuma transação aberta durante a IA
    rel = relator.redigir(partes, itens, est, coer)
    registrar(s, sid, "rag_normas", "trechos usados pelo relator", {"fontes": rel["fontes"]})
    registrar(s, sid, "relator", f"resumo redigido ({rel['origem']})", {"eventos": rel["eventos"]}, rel["tokens"])
    registrar(s, sid, "validacao", "resumo " + ("aprovado" if rel["checagens"]["aprovado"] else "reprovado"), rel["checagens"])
    s.add(Relatorio(sessao_id=sid, secoes_json=json.dumps(rel["secoes"], ensure_ascii=False),
                    fontes_json=json.dumps(rel["fontes"], ensure_ascii=False),
                    checagens_json=json.dumps(rel["checagens"], ensure_ascii=False), origem=rel["origem"]))
    se.estado = "relatorio"; s.commit()
    return rel


def _gerar_analise(s: Session, se: Sessao) -> dict:
    sid = se.id
    itens, est = _itens(s, sid), rede.estimar(_respostas(s, sid))
    coer = coerencia.comparar(_forcas(s, sid), est)
    partes = _partes(s, sid)
    s.commit()                                              # nenhuma gravação aberta durante a IA (pode levar minutos)
    a = apoio.analisar(partes, itens, est, coer)
    registrar(s, sid, "coerencia", "relato × respostas", coer)
    registrar(s, sid, "rag_ciencia", "literatura recuperada", {"fontes": a["fontes"]})
    registrar(s, sid, "apoio", f"análise redigida ({a['origem']})", {"eventos": a["eventos"]}, a["tokens"])
    registrar(s, sid, "revisor", "revisão da análise", a["revisao"] or {"observacao": "sem revisor (modo simulado)"})
    registrar(s, sid, "validacao", "análise " + ("aprovada" if a["checagens"]["aprovado"] else "reprovada"), a["checagens"])
    s.add(AnaliseApoio(sessao_id=sid, conteudo_json=json.dumps(a["conteudo"], ensure_ascii=False),
                       fontes_json=json.dumps(a["fontes"], ensure_ascii=False), checagens_json=json.dumps(a["checagens"], ensure_ascii=False),
                       revisao_json=json.dumps(a["revisao"], ensure_ascii=False), origem=a["origem"]))
    s.commit()
    return a


def gerar_documentos(sid: int):
    """Tarefa em segundo plano. O resumo sai primeiro (a profissional já pode lê-lo); depois vem a análise.
    Situações: processando → resumo (análise em preparo) → pronto; se só a análise falhar → parcial."""
    with Session(banco.motor) as s:
        se = s.get(Sessao, sid)
        try:
            _gerar_resumo(s, se)
        except Exception as e:
            s.rollback(); se = s.get(Sessao, sid); se.docs_estado = "erro"
            registrar(s, sid, "sistema", "falha ao gerar o resumo", {"erro": f"{type(e).__name__}: {e}"})
            s.add(se); s.commit(); return
        se.docs_estado = "resumo"
        s.add(se); s.commit()
        try:
            _gerar_analise(s, se)
            se.docs_estado = "pronto"
        except Exception as e:
            s.rollback(); se = s.get(Sessao, sid); se.docs_estado = "parcial"
            registrar(s, sid, "sistema", "falha ao gerar a análise de apoio", {"erro": f"{type(e).__name__}: {e}"})
        s.add(se); s.commit()


@app.post("/sessoes/{sid}/relatorio")
def gerar_relatorio(sid: int, s: Session = Depends(sessao_bd)):
    se = obter(s, sid)
    if se.estado not in ("resultado", "relatorio"):
        raise HTTPException(409, f"A sessão está na etapa '{se.estado}'.")
    rel = _gerar_resumo(s, se)
    return {"estado": "relatorio", "checagens": rel["checagens"], "origem": rel["origem"]}


@app.post("/sessoes/{sid}/analise")
def gerar_analise(sid: int, s: Session = Depends(sessao_bd)):
    se = obter(s, sid)
    if not _ultimo(s, Relatorio, sid):
        raise HTTPException(409, "Gere o resumo antes da análise de apoio.")
    a = _gerar_analise(s, se)
    if se.docs_estado in ("resumo", "parcial"):
        se.docs_estado = "pronto"; s.add(se); s.commit()
    return {"checagens": a["checagens"], "origem": a["origem"], "revisao": a["revisao"]}


@app.get("/sessoes/{sid}/relatorio.html", response_class=HTMLResponse)
def relatorio_html(sid: int, s: Session = Depends(sessao_bd)):
    se = obter(s, sid)
    r = _ultimo(s, Relatorio, sid)
    if not r:
        raise HTTPException(404, "Resumo ainda não gerado.")
    conclusao = s.exec(select(Conclusao).where(Conclusao.sessao_id == sid)).first()
    est = rede.estimar(_respostas(s, sid))
    return html_resumo(se, _blocos(s, sid), _itens(s, sid), est,
                       json.loads(r.secoes_json), json.loads(r.fontes_json), conclusao, coerencia.comparar(_forcas(s, sid), est))


@app.get("/sessoes/{sid}/analise.html", response_class=HTMLResponse)
def analise_html(sid: int, s: Session = Depends(sessao_bd)):
    se = obter(s, sid)
    a = _ultimo(s, AnaliseApoio, sid)
    if not a:
        raise HTTPException(404, "Análise ainda não gerada.")
    est = rede.estimar(_respostas(s, sid))
    return html_analise(se, _blocos(s, sid), _itens(s, sid), est,
                        {"conteudo": json.loads(a.conteudo_json), "fontes": json.loads(a.fontes_json), "origem": a.origem},
                        coerencia.comparar(_forcas(s, sid), est))


@app.get("/sessoes/{sid}/conclusao")
def ler_conclusao(sid: int, s: Session = Depends(sessao_bd)):
    obter(s, sid)
    c = s.exec(select(Conclusao).where(Conclusao.sessao_id == sid)).first()
    return {"texto": c.texto if c else "", "atualizada_em": c.atualizada_em if c else None,
            "profissional_nome": c.profissional_nome if c else "", "profissional_crp": c.profissional_crp if c else ""}


@app.put("/sessoes/{sid}/conclusao")
def salvar_conclusao(sid: int, dados: TextoConclusao, s: Session = Depends(sessao_bd)):
    """Escrita pela profissional. Não passa por nenhum LLM."""
    se = obter(s, sid)
    if se.estado != "relatorio":
        raise HTTPException(409, "Gere o resumo antes de escrever a conclusão.")
    c = s.exec(select(Conclusao).where(Conclusao.sessao_id == sid)).first()
    if c:
        c.texto, c.atualizada_em = dados.texto, banco.agora()
        c.profissional_nome, c.profissional_crp = dados.profissional_nome.strip(), dados.profissional_crp.strip()
    else:
        c = Conclusao(sessao_id=sid, texto=dados.texto, profissional_nome=dados.profissional_nome.strip(),
                      profissional_crp=dados.profissional_crp.strip()); s.add(c)
    registrar(s, sid, "profissional", "conclusão salva", {"caracteres": len(dados.texto)})
    s.commit()
    return {"ok": True, "atualizada_em": c.atualizada_em}


# ---------------------------------------------------------------- área da profissional
def _resumo_sessao(s: Session, se: Sessao) -> dict:
    est = _ultimo(s, Estimativa, se.id)
    r, a = _ultimo(s, Relatorio, se.id), _ultimo(s, AnaliseApoio, se.id)
    tem_conclusao = s.exec(select(Conclusao).where(Conclusao.sessao_id == se.id)).first() is not None
    return {"id": se.id, "codigo": se.codigo, "arquivada": se.arquivada,
            "estado": se.estado, "docs_estado": se.docs_estado, "visto": se.visto, "criada_em": se.criada_em,
            "finalizada_em": se.finalizada_em, "tem_conclusao": tem_conclusao,
            "escores": json.loads(est.escores_json) if est else None,
            "resumo": {"checagens": json.loads(r.checagens_json), "origem": r.origem} if r else None,
            "analise": {"checagens": json.loads(a.checagens_json), "origem": a.origem, "revisao": json.loads(a.revisao_json)} if a else None}


@app.get("/atendimentos")
def atendimentos(busca: str = "", arquivadas: bool = False, s: Session = Depends(sessao_bd)):
    """Atendimentos do mais recente ao mais antigo. Arquivados só aparecem quando pedidos."""
    q = select(Sessao).where(Sessao.arquivada == arquivadas).order_by(Sessao.id.desc())
    lst = [se for se in s.exec(q) if busca.lower() in se.codigo.lower()]
    return [_resumo_sessao(s, se) for se in lst]


# ---------------------------------------------------------------- gerenciar a lista (CRUD)
INCOMPLETOS = ("relato", "perguntas", "questionario")


@app.get("/sessoes/{sid}/retomar")
def retomar(sid: int, s: Session = Depends(sessao_bd)):
    """Para continuar uma aplicação interrompida (ex.: o paciente saiu antes de terminar)."""
    se = obter(s, sid)
    if se.estado not in INCOMPLETOS:
        raise HTTPException(409, "Esta aplicação já foi concluída.")
    r = {"id": se.id, "codigo": se.codigo, "estado": se.estado}
    if se.estado == "perguntas":
        ultima = [x for x in textos(s, sid) if x.tipo == "pergunta"][-1]
        r.update(pergunta=ultima.texto, restantes=MAX_PERGUNTAS_EXTRAS - se.perguntas_feitas)
    if se.estado == "questionario":
        r["itens"] = [{k: v for k, v in i.items() if k in ("item", "dimensao", "texto")} for i in _com_texto(_itens(s, sid))]
    return r


@app.patch("/sessoes/{sid}")
def editar(sid: int, dados: EdicaoSessao, s: Session = Depends(sessao_bd)):
    """Corrige o código do paciente e/ou arquiva/desarquiva o atendimento."""
    se = obter(s, sid)
    if dados.codigo is not None:
        registrar(s, sid, "profissional", "código corrigido", {"antes": se.codigo, "depois": dados.codigo.strip()})
        se.codigo = dados.codigo.strip()
    if dados.arquivada is not None:
        se.arquivada = dados.arquivada
        registrar(s, sid, "profissional", "arquivado" if dados.arquivada else "desarquivado")
    s.commit()
    return _resumo_sessao(s, se)


@app.delete("/sessoes/{sid}")
def excluir(sid: int, s: Session = Depends(sessao_bd)):
    """Exclui só aplicações INCOMPLETAS (sem documentos). Atendimentos concluídos ou com alerta de risco
    não são excluídos, porque fazem parte do registro do atendimento: para tirá-los da lista, use arquivar."""
    se = obter(s, sid)
    if se.estado not in INCOMPLETOS or se.docs_estado != "aguardando":
        raise HTTPException(409, "Só aplicações incompletas podem ser excluídas. Para atendimentos concluídos, use Arquivar.")
    for modelo in (Relato, ItemSelecionado, Resposta, Estimativa, Relatorio, AnaliseApoio, Conclusao, Evento):
        for x in s.exec(select(modelo).where(modelo.sessao_id == sid)):
            s.delete(x)
    s.delete(se); s.commit()
    return {"ok": True}


@app.get("/sessoes/{sid}")
def detalhe(sid: int, s: Session = Depends(sessao_bd)):
    return _resumo_sessao(s, obter(s, sid))


@app.post("/sessoes/{sid}/visto")
def marcar_visto(sid: int, s: Session = Depends(sessao_bd)):
    se = obter(s, sid); se.visto = True; s.commit()
    return {"ok": True}


@app.get("/pacientes/{codigo}/historico")
def historico(codigo: str, s: Session = Depends(sessao_bd)):
    """Escores de todas as aplicações do mesmo código, para acompanhar a evolução."""
    saida = []
    for se in s.exec(select(Sessao).where(Sessao.codigo == codigo).order_by(Sessao.id)):
        est = _ultimo(s, Estimativa, se.id)
        if est:
            saida.append({"id": se.id, "data": se.finalizada_em or se.criada_em, "escores": json.loads(est.escores_json)})
    return saida


@app.get("/rag/itens")
def rag_itens(texto: str):
    """Para o painel técnico: quais itens o RAG liga a um texto."""
    return itens_do_relato(texto)[:10]


@app.get("/sessoes")
def listar(s: Session = Depends(sessao_bd)):
    return s.exec(select(Sessao).order_by(Sessao.id.desc())).all()


@app.get("/sessoes/{sid}/eventos")
def eventos(sid: int, s: Session = Depends(sessao_bd)):
    obter(s, sid)
    return s.exec(select(Evento).where(Evento.sessao_id == sid).order_by(Evento.id)).all()
