"""Rede de segurança determinística para risco à vida (não é um agente).

Roda em todo texto livre, antes do agente analista, em milissegundos e sem depender do modelo de
linguagem. O analista faz a segunda camada, entendendo frases indiretas. Assim, mesmo com o Ollama
desligado, um relato com sinais claros de risco nunca segue para o questionário."""
import re
import unicodedata

PADROES = [r"suicid", r"me matar", r"tirar (a )?minha (propria )?vida", r"nao quero (mais )?viver",
           r"acabar com (a minha vida|tudo)", r"quero morrer", r"queria (estar )?morrer",
           r"me machucar", r"automutila", r"me cortar", r"sumir de vez"]

MENSAGEM = ("Obrigado por compartilhar. O que você está sentindo é importante. Vamos pausar o questionário "
            "agora. Converse com alguém agora: CVV, telefone 188 (24 horas, gratuito) ou chat em cvv.org.br. "
            "Em emergência, ligue 192 (SAMU). A profissional responsável foi avisada.")


def _normalizar(t: str) -> str:
    return unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()


def risco_explicito(texto: str) -> bool:
    t = _normalizar(texto)
    return any(re.search(p, t) for p in PADROES)
