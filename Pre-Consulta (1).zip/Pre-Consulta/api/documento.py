"""Documentos em HTML prontos para tela e impressão A4.

- Resumo de pré-consulta (oficial): sóbrio; palavras-chave do relato apenas em negrito.
- Análise de apoio (IA): leitura guiada do relato com cores por dimensão, rótulos escritos e
  sublinhados distintos (funciona em preto e branco), explicações e referências bibliográficas."""
import html
from datetime import date

from .rag.indice import base_itens
from .trechos import destaques_por_parte

FONTE = '"Times New Roman", Times, serif'
DIM_CLASSE = {"Exaustão": "exa", "Distanciamento": "dis", "Cognitivo": "cog", "Emocional": "emo"}
DIM_NOME = {"Exaustão": "Exaustão", "Distanciamento": "Distanciamento mental", "Cognitivo": "Prejuízo cognitivo",
            "Emocional": "Prejuízo emocional"}

ESTILO = f"""
:root {{ color-scheme: light; }}
@page {{ size: A4; margin: 16mm 15mm 18mm; }}
* {{ box-sizing: border-box; }}
body {{ font-family: {FONTE}; color: #1b1f2a; background: #fff; font-size: 12pt; line-height: 1.5; margin: 0; padding: 20px; }}
.folha {{ max-width: 790px; margin: 0 auto; border: 1px solid #c9ced9; border-top: 4px solid #2f3e9e; padding: 26px 30px 22px; }}
header {{ display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; border-bottom: 1px solid #c9ced9; padding-bottom: 10px; margin-bottom: 14px; }}
h1 {{ font-size: 16pt; margin: 0 0 2px; }}
h2 {{ font-size: 13pt; margin: 18px 0 6px; color: #23307d; break-after: avoid; }}
h3 {{ font-size: 12pt; margin: 10px 0 4px; }}
.selo {{ font-size: 9pt; text-transform: uppercase; letter-spacing: .8px; color: #2f3e9e; border: 1px solid #2f3e9e; border-radius: 4px; padding: 3px 7px; white-space: nowrap; }}
.aviso {{ font-size: 10pt; color: #3d4455; margin: 0; }}
table {{ border-collapse: collapse; width: 100%; font-size: 11pt; break-inside: avoid; }}
th, td {{ border: 1px solid #c9ced9; padding: 5px 7px; text-align: left; vertical-align: top; }} th {{ background: #eef0f7; }}
ul, ol {{ margin: 4px 0 8px 20px; padding: 0; }} li {{ margin-bottom: 4px; }}
blockquote {{ margin: 6px 0 10px; padding: 8px 12px; border-left: 3px solid #8a91a5; background: #f7f8fb; }}
blockquote .rotulo {{ display: block; font-size: 10pt; color: #3d4455; margin-bottom: 2px; }}
.reservado {{ border: 1px dashed #8a90a0; padding: 14px; color: #4a5163; font-style: italic; }}
.conclusao {{ border-left: 3px solid #2f3e9e; padding: 6px 12px; white-space: pre-wrap; }}
.assinatura {{ margin-top: 26px; text-align: right; }}
.ia {{ background: #f3f4fb; border: 1px solid #c9ced9; border-radius: 6px; padding: 8px 12px; font-size: 10.5pt; }}
footer {{ margin-top: 20px; font-size: 10pt; color: #3d4455; border-top: 1px solid #c9ced9; padding-top: 8px; }}
/* Destaques da análise: cor + sublinhado próprio + rótulo escrito (não depende só da cor) */
mark {{ color: #1b1f2a; padding: 0 2px; border-radius: 2px; text-decoration-thickness: 2px; text-underline-offset: 3px; }}
mark.exa {{ background: #fde2c8; text-decoration: underline solid #b45309; }}
mark.dis {{ background: #dbe4ff; text-decoration: underline dashed #3647b5; }}
mark.cog {{ background: #d9f2e4; text-decoration: underline dotted #1f7a4d; }}
mark.emo {{ background: #f6dcef; text-decoration: underline double #9d2b7a; }}
mark sup {{ font-size: 7.5pt; margin-left: 2px; color: #3d4455; }}
.legenda {{ display: flex; flex-wrap: wrap; gap: 6px 14px; font-size: 10pt; margin: 4px 0 8px; }}
.trechos li {{ margin-bottom: 8px; }} .forca {{ font-size: 9.5pt; color: #3d4455; }}
.dimensoes {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px 14px; }}
.dimensao {{ border: 1px solid #c9ced9; border-radius: 6px; padding: 8px 10px; break-inside: avoid; }}
.dimensao b {{ display: block; }}
.refs li {{ font-size: 10.5pt; }}
.coerencia {{ border: 1px solid #c9ced9; border-left: 4px solid #2f3e9e; border-radius: 6px; padding: 8px 12px; break-inside: avoid; }}
.coerencia.divergente {{ border-left-color: #b45309; background: #fff7ed; }}
.coerencia b {{ display: block; margin-bottom: 2px; }}
@media print {{ body {{ padding: 0; }} .folha {{ border: 0; border-top: 4px solid #2f3e9e; padding: 0; }} }}
"""


def esc(t):
    return html.escape(str(t))


def br(v):
    return f"{v:.2f}".replace(".", ",")


def _pagina(titulo, corpo):
    return (f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{esc(titulo)}</title><style>{ESTILO}</style></head><body><main class=\"folha\">{corpo}</main></body></html>")


def marcar(texto: str, destaques: list[dict], modo: str) -> str:
    """Devolve o texto escapado com os trechos destacados (negrito ou cores por dimensão)."""
    saida, pos = [], 0
    for d in destaques:
        saida.append(esc(texto[pos:d["inicio"]]))
        trecho = esc(texto[d["inicio"]:d["fim"]])
        if modo == "negrito":
            saida.append(f"<b>{trecho}</b>")
        else:
            dim = d["dimensoes"][0]
            rotulo = " · ".join(DIM_NOME[x] for x in d["dimensoes"])
            saida.append(f'<mark class="{DIM_CLASSE[dim]}" title="{esc(rotulo)}">{trecho}<sup>{esc(", ".join(d["itens"]))}</sup></mark>')
        pos = d["fim"]
    saida.append(esc(texto[pos:]))
    return "".join(saida)


def _relato(blocos, itens, modo):
    destaques = destaques_por_parte(itens, len(blocos))
    html_blocos = []
    for b, d in zip(blocos, destaques):
        html_blocos.append(f'<blockquote><span class="rotulo">{esc(b["titulo"])}</span>“{marcar(b["texto"], d, modo)}”</blockquote>')
    return "".join(html_blocos)


def _contexto(blocos, it, folga=32):
    """Trecho com um pouco do texto em volta, para a lista de itens do resumo."""
    texto = blocos[it["parte"]]["texto"]
    a, b = max(0, it["inicio"] - folga), min(len(texto), it["fim"] + folga)
    while 0 < a < it["inicio"] and not texto[a - 1].isspace():      # não corta palavras ao meio
        a += 1
    while it["fim"] < b < len(texto) and not texto[b].isspace():
        b -= 1
    antes = ("…" if a > 0 else "") + esc(texto[a:it["inicio"]])
    depois = esc(texto[it["fim"]:b]) + ("…" if b < len(texto) else "")
    return f"“{antes}<b>{esc(texto[it['inicio']:it['fim']])}</b>{depois}”"


def _tabela(est):
    linhas = "".join(f"<tr><td>{esc(DIM_NOME[d])}</td><td>{br(v)}</td><td>{est['itens_por_dimensao'][d]}</td><td>{est['percentis'][d]}%</td></tr>"
                     for d, v in est["escores"].items())
    return ("<table><caption class='aviso' style='text-align:left;caption-side:bottom;padding-top:4px'>Escores estimados por rede neural "
            f"a partir de 8 itens; erro médio esperado de cerca de {br(est['erro_medio_esperado'])} ponto.</caption>"
            "<thead><tr><th scope='col'>Dimensão</th><th scope='col'>Escore estimado (1 a 5)</th><th scope='col'>Itens aplicados</th>"
            f"<th scope='col'>Maior que % da referência brasileira</th></tr></thead><tbody>{linhas}</tbody></table>")


def _coerencia_resumo(coer):
    if not coer or not coer.get("divergencias"):
        return ""
    return ("<p><b>Relato × respostas:</b> " + esc(" ".join(d["texto"] for d in coer["divergencias"]))
            + " Comparação descritiva feita pelo sistema.</p>")


def html_resumo(sessao, blocos, itens, est, secoes, fontes, conclusao, coer=None) -> str:
    def linha_item(i):
        base = f"<li><b>{esc(i['item'])}</b> ({esc(DIM_NOME[i['dimensao']])}): {esc(i['motivo'])}"
        return base + (f" — {_contexto(blocos, i)}</li>" if i.get("trecho") else "</li>")
    itens_html = "".join(linha_item(i) for i in itens)
    fontes_html = "".join(f"<li>[{f['n']}] {esc(f['documento'])}</li>" for f in fontes)
    if conclusao:
        data = "/".join(reversed(conclusao.atualizada_em[:10].split("-")))
        quinto = (f"<div class='conclusao'>{esc(conclusao.texto)}</div>"
                  f"<div class='assinatura'>_______________________________<br>{esc(conclusao.profissional_nome)}<br>"
                  f"CRP {esc(conclusao.profissional_crp)}<br><span class='aviso'>Conclusão elaborada em {esc(data)}</span></div>")
        responsavel = f"{esc(conclusao.profissional_nome)} — CRP {esc(conclusao.profissional_crp)}"
    else:
        quinto = "<div class='reservado'>Campo reservado à profissional responsável, que se identifica na assinatura.</div>"
        responsavel = "identificada na assinatura da conclusão"
    corpo = f"""<header><div><h1>Resumo de pré-consulta</h1>
<p class="aviso">Uso exclusivo da profissional responsável. Documento auxiliar gerado por sistema: não é documento psicológico nem diagnóstico.</p></div>
<span class="selo">Sigiloso</span></header>
<h2>1. Identificação</h2>
<p>Código do paciente: {esc(sessao.codigo)}<br>Data: {date.today().strftime('%d/%m/%Y')}<br>
Instrumento: Burnout Assessment Tool (BAT), 8 itens selecionados a partir do relato<br>Profissional responsável: {responsavel}</p>
<h2>2. Descrição da demanda</h2><p>{esc(secoes['descricao_demanda'])}</p>
{_relato(blocos, itens, "negrito")}
<p class="aviso">Trechos em negrito: palavras do relato associadas pelo sistema aos itens aplicados.</p>
<h2>3. Procedimento</h2><p>{esc(secoes['procedimento'])}</p><ul>{itens_html}</ul>
<h2>4. Análise dos dados</h2>{_tabela(est)}
<p>{esc(secoes['analise'])}</p><p><b>Pontos de atenção:</b> {esc(secoes['pontos_atencao'])}</p>
{_coerencia_resumo(coer)}
<h2>5. Conclusão</h2>{quinto}
<footer>Fontes:<ol>{fontes_html}</ol>Validade do conteúdo: até a consulta de devolutiva. Para resultado completo, aplicar o BAT-23.</footer>"""
    return _pagina(f"Resumo de pré-consulta {sessao.codigo}", corpo)


def html_analise(sessao, blocos, itens, est, analise, coer=None) -> str:
    c = analise["conteudo"]
    textos_itens = {i["id"]: i["texto"] for i in base_itens()["itens"]}
    comentarios = {t.get("trecho", "").strip().lower(): t.get("comentario", "") for t in c.get("comentarios_trechos", [])}
    lista = lambda xs: "".join(f"<li>{esc(x)}</li>" for x in xs)

    legenda = "".join(f'<span><mark class="{k}">{esc(DIM_NOME[d])}</mark></span>' for d, k in DIM_CLASSE.items())
    trechos = []
    for i in itens:
        if not i.get("trecho"):
            continue
        comentario = comentarios.get(i["trecho"].strip().lower(), "")
        explicacao = (f"Ligado a <b>{esc(i['item'])}</b> — “{esc(textos_itens[i['item']])}”. "
                      f"Associação {esc(i.get('forca') or 'moderada')}, pela semelhança com “{esc(i.get('expressao') or '')}”.")
        trechos.append(f'<li><mark class="{DIM_CLASSE[i["dimensao"]]}">{esc(i["trecho"])}</mark> '
                       f'<span class="forca">({esc(DIM_NOME[i["dimensao"]])})</span><br>{explicacao}'
                       + (f"<br><i>{esc(comentario)}</i>" if comentario else "") + "</li>")
    sem_trecho = [d for d in DIM_CLASSE if not any(i.get("trecho") and i["dimensao"] == d for i in itens)]
    nota_ausentes = (f"<p class='aviso'>O relato não trouxe palavras associadas a: {esc(', '.join(DIM_NOME[d] for d in sem_trecho))}. "
                     "Os escores dessas dimensões vêm só das respostas aos itens.</p>") if sem_trecho else ""

    leituras = {d.get("dimensao"): d.get("leitura", "") for d in c.get("leitura_por_dimensao", [])}
    cartoes = "".join(f'<div class="dimensao"><b><mark class="{k}">{esc(DIM_NOME[d])}</mark> · {br(est["escores"][d])} '
                      f'(maior que {est["percentis"][d]}%)</b>{esc(leituras.get(d, ""))}</div>' for d, k in DIM_CLASSE.items())
    evid = "".join(f"<li>{esc(e['afirmacao'])} [{e['fonte']}]</li>" for e in c.get("evidencias", []))
    refs, vistos = [], set()
    for f in analise["fontes"]:
        chave = f["referencia"]
        refs.append(f"<li>[{f['n']}] {esc(f['documento'])}" + ("" if chave in vistos else f"<br><span class='aviso'>{esc(chave)}</span>") + "</li>")
        vistos.add(chave)

    corpo = f"""<header><div><h1>Análise de apoio à profissional</h1>
<p class="aviso">Código do paciente {esc(sessao.codigo)} · {date.today().strftime('%d/%m/%Y')} · uso exclusivo da profissional responsável.</p></div>
<span class="selo">Gerada por IA</span></header>
<p class="ia">Texto gerado por inteligência artificial a partir do resumo de pré-consulta e de literatura científica.
Traz uma leitura de apoio, hipóteses e sugestões; <b>não é diagnóstico nem conclusão</b>. As decisões são da profissional.</p>
<h2>Panorama</h2><p>{esc(c.get('abertura', ''))}</p>
<h2>Relato × respostas</h2>
<div class="coerencia{' divergente' if coer and coer.get('divergencias') else ''}"><b>{'Divergência entre o que a pessoa contou e o que respondeu' if coer and coer.get('divergencias') else ('Relato e respostas convergem' if coer and coer.get('coerentes') else 'Comparação entre o relato e as respostas')}</b>{esc(c.get('coerencia') or (coer or {}).get('resumo', ''))}</div>
<h2>Leitura guiada do relato</h2>
<div class="legenda" aria-label="Legenda das cores">{legenda}</div>
{_relato(blocos, itens, "cores")}
<p>{esc(c.get('o_que_o_relato_mostra', ''))}</p>
<ul class="trechos">{''.join(trechos) or '<li>Nenhum trecho do relato foi associado a itens específicos.</li>'}</ul>{nota_ausentes}
<h2>Leitura por dimensão</h2><div class="dimensoes">{cartoes}</div>
<p class="aviso">Escores estimados a partir de 8 itens; erro médio esperado de cerca de {br(est['erro_medio_esperado'])} ponto.</p>
<h2>Pontos a explorar na consulta</h2><ul>{lista(c.get('pontos_a_explorar', []))}</ul>
<h2>Sugestões para a conversa</h2><ul>{lista(c.get('sugestoes_de_conversa', []))}</ul>
<h2>Cuidados</h2><p>{esc(c.get('cuidados', ''))}</p>
<h2>O que diz a literatura</h2><ul>{evid}</ul>
<h2>Limitações</h2><p>{esc(c.get('limitacoes', ''))}</p>
<footer><b>Referências bibliográficas</b><ol class="refs">{''.join(refs)}</ol>Origem do texto: {esc(analise['origem'])}.</footer>"""
    return _pagina(f"Análise de apoio {sessao.codigo}", corpo)
