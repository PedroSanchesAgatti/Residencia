"""Coerência entre o relato e as respostas aos itens (calculada pelo código, sem IA).

Compara a força dos indícios que o analista encontrou no relato, por dimensão, com o escore estimado a
partir das respostas. Para não virar hábito, só é apontada DIVERGÊNCIA quando a diferença é muito grande:

- relato_forte_escore_baixo: o relato descreve a dimensão com muita clareza, mas as respostas ficaram muito
  baixas (ex.: fala de exaustão o tempo todo e marca "nunca" nos itens de exaustão);
- relato_sem_relacao: o relato não traz nada dos temas avaliados (por exemplo, a pessoa se confundiu com a
  tarefa ou escreveu sobre outro assunto), mas as respostas indicam escores altos em várias dimensões.

Respostas altas num tema que o relato não citou, num relato que fala de outros temas, não são divergência:
viram um achado complementar, sem alerta. O sistema não interpreta o motivo; isso fica com o agente de
apoio (como hipótese) e com a profissional."""

FORTE_MUITO = 0.75         # indício muito claro no relato (0 a 1)
FRACO = 0.20               # indício fraco ou ausente
SEM_RELACAO = 0.20         # se TODAS as dimensões ficam abaixo disso, o relato não fala dos temas avaliados
BAIXO_MUITO = 15           # percentil muito baixo na referência brasileira
ALTO = 75                  # percentil alto
MIN_DIMENSOES_ALTAS = 2    # para "relato sem relação": pelo menos 2 dimensões com escore alto

NOMES = {"Exaustão": "exaustão", "Distanciamento": "distanciamento mental", "Cognitivo": "prejuízo cognitivo",
         "Emocional": "prejuízo emocional"}


def comparar(forcas: dict | None, est: dict) -> dict:
    """Devolve {"disponivel", "divergencias", "complementares", "coerentes", "resumo"}."""
    vazio = {"divergencias": [], "complementares": [], "coerentes": []}
    if not forcas:
        return {"disponivel": False, **vazio, "resumo": "Não foi possível comparar o relato com as respostas nesta sessão."}
    divergencias, complementares, coerentes = [], [], []
    altas = [d for d, p in est["percentis"].items() if p >= ALTO]

    if max(float(v or 0) for v in forcas.values()) < SEM_RELACAO and len(altas) >= MIN_DIMENSOES_ALTAS:
        nomes = ", ".join(NOMES[d] for d in altas)
        divergencias.append({"dimensao": "Geral", "tipo": "relato_sem_relacao",
                             "texto": f"O relato não traz relação com os temas avaliados, mas as respostas indicam escores "
                                      f"altos em {nomes}. A pessoa pode ter se confundido com a tarefa do relato."})
    else:
        for d, escore in est["escores"].items():
            f, p = float(forcas.get(d, 0) or 0), est["percentis"][d]
            item = {"dimensao": d, "forca_relato": round(f, 2), "escore": escore, "percentil": p}
            if f >= FORTE_MUITO and p <= BAIXO_MUITO:
                divergencias.append({**item, "tipo": "relato_forte_escore_baixo",
                                     "texto": f"O relato descreve {NOMES[d]} com muita clareza, mas as respostas aos itens "
                                              f"ficaram muito baixas (maior que só {p}% da referência)."})
            elif f <= FRACO and p >= ALTO:
                complementares.append({**item, "tipo": "escore_alto_sem_relato",
                                       "texto": f"As respostas também indicam {NOMES[d]} elevado (maior que {p}% da referência), "
                                                f"tema que não apareceu no relato e pode ser explorado na consulta."})
            elif f >= 0.6 and p >= 50:
                coerentes.append({**item, "texto": f"Relato e respostas convergem em {NOMES[d]}."})

    partes = [x["texto"] for x in divergencias] + [x["texto"] for x in coerentes] + [x["texto"] for x in complementares]
    resumo = " ".join(partes) if partes else "Não há divergências marcantes entre o relato e as respostas aos itens."
    return {"disponivel": True, "divergencias": divergencias, "complementares": complementares,
            "coerentes": coerentes, "resumo": resumo}
