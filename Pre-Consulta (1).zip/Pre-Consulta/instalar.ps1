# Instalacao da Pre-Consulta no Windows. Use o atalho instalar.bat (dois cliques) ou:
#   powershell -ExecutionPolicy Bypass -File instalar.ps1
Set-Location $PSScriptRoot
function Passo($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }
function Erro($t)  { Write-Host "`nERRO: $t" -ForegroundColor Red; Read-Host "Pressione Enter para sair"; exit 1 }

Passo "1/6 Conferindo o Python (3.11 ou 3.12)"
$py = $null
foreach ($c in @("py -3.12", "py -3.11", "python", "py")) {
    $v = cmd /c "$c --version 2>&1"
    if ($LASTEXITCODE -eq 0 -and "$v" -match "Python 3\.(11|12|13)") { $py = $c; Write-Host "Encontrado: $v ($c)"; break }
}
if (-not $py) { Erro "Python 3.11 ou 3.12 nao encontrado. Instale em python.org marcando 'Add python.exe to PATH' e rode de novo." }

Passo "2/6 Conferindo o Node.js"
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Erro "Node.js nao encontrado. Instale a versao LTS em nodejs.org e rode de novo." }
Write-Host "Encontrado: $(node --version)"

Passo "3/6 Criando o ambiente Python (.venv) e instalando as bibliotecas (5 a 15 minutos)"
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    cmd /c "$py -m venv .venv"
    if ($LASTEXITCODE -ne 0) { Erro "Nao foi possivel criar o .venv." }
}
$vpy = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
& $vpy -m pip install --upgrade pip
& $vpy -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) {
    Erro ("A instalacao das bibliotecas falhou. Se a mensagem fala em 'long path', abra o PowerShell como administrador, rode:`n" +
          'New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force' +
          "`nreinicie o computador e rode instalar.bat de novo.")
}

Passo "4/6 Baixando o modelo de linguagem qwen2.5:7b (cerca de 5 GB)"
if (Get-Command ollama -ErrorAction SilentlyContinue) {
    ollama pull qwen2.5:7b
    if ($LASTEXITCODE -ne 0) { Write-Host "Nao foi possivel baixar o modelo agora. Abra o Ollama e rode: ollama pull qwen2.5:7b" -ForegroundColor Yellow }
} else {
    Write-Host "Ollama nao encontrado. Instale em ollama.com e depois rode: ollama pull qwen2.5:7b" -ForegroundColor Yellow
    Write-Host "Sem o Ollama o app funciona, mas sem a IA (textos padrao)." -ForegroundColor Yellow
}

Passo "5/6 Instalando a interface (Electron, React)"
Push-Location desktop
npm install
$npmOk = $LASTEXITCODE
Pop-Location
if ($npmOk -ne 0) { Erro "npm install falhou." }

Passo "6/6 Rodando os testes"
& $vpy -m pytest -q tests

Write-Host "`nPronto! Para abrir o app, de dois cliques em iniciar.bat (ou rode: .\iniciar.ps1)." -ForegroundColor Green
Read-Host "Pressione Enter para fechar"
