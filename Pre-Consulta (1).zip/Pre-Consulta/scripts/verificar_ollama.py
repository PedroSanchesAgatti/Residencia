"""Confere o Ollama e mede o tempo de cada agente com um relato de exemplo.
Uso (com o Ollama aberto):  python scripts/verificar_ollama.py
Útil para escolher os modelos e para mostrar os tempos na apresentação."""
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("LLM_MODO", "ollama")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from api import rede, seletor, trechos  # noqa: E402
from api import seguranca  # noqa: E402
from api.agentes import analista, apoio, llm, relator  # noqa: E402

RELATO = "Esqueço reuniões, chego em casa sem energia e ando sem paciência com todo mundo no trabalho."

print("Situação:", llm.situacao())
if llm.situacao().get("ollama") != "ok":
    sys.exit("Abra o app Ollama (ou rode 'ollama serve') e baixe os modelos com 'ollama pull'.")

def medir(nome, f):
    t0 = time.time(); r = f(); print(f"{nome:10s} {time.time() - t0:6.1f} s"); return r

medir("aquecer", llm.aquecer)
medir("segurança", lambda: seguranca.risco_explicito(RELATO))
a = medir("analista", lambda: analista.analisar([RELATO], 0))
itens = trechos.associar(seletor.selecionar(a["forcas"], a["rag"]), [RELATO], a["trechos_itens"])
est = rede.estimar({i["item"]: 4 for i in itens})
r = medir("relator", lambda: relator.redigir([RELATO], itens, est, None))
p = medir("apoio", lambda: apoio.analisar([RELATO], itens, est, None))
print("\nForças:", a["forcas"], "| modo do analista:", a["modo"])
print("Itens:", [(i["item"], i.get("trecho")) for i in itens])
print("Resumo:", r["origem"], "| checagens:", r["checagens"]["aprovado"])
print("Análise:", p["origem"], "| checagens:", p["checagens"]["aprovado"], "| revisor:", p["revisao"])
print("\nAbertura da análise:\n", p["conteudo"].get("abertura"))
