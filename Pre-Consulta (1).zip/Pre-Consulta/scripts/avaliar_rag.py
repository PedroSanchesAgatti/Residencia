"""Avalia o RAG de itens contra uma busca por palavras-chave (os "ifs").
Métrica: acerto da dimensão principal (top-1) e cobertura das dimensões rotuladas entre as 2 mais fortes.
Uso: python scripts/avaliar_rag.py"""
import json
import re
import sys
import unicodedata
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
from api.rag.embeddings import tipo  # noqa: E402
from api.rag.indice import base_itens, itens_do_relato  # noqa: E402


def norm(t):
    return unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()


def forcas_rag(relato):
    f = {d: 0.0 for d in base_itens()["dimensoes"]}
    for x in itens_do_relato(relato):
        f[x["dimensao"]] = max(f[x["dimensao"]], x["similaridade"])
    return f


def forcas_palavras(relato):
    """Linha de base: conta palavras (com 5+ letras) das expressões/itens que aparecem literalmente no relato."""
    texto = set(re.findall(r"\w{5,}", norm(relato)))
    f = {d: 0.0 for d in base_itens()["dimensoes"]}
    for it in base_itens()["itens"]:
        palavras = set(re.findall(r"\w{5,}", norm(" ".join(it["expressoes"] + [it["texto"]]))))
        f[it["dimensao"]] += len(texto & palavras)
    return f


def avaliar(metodo):
    casos = json.loads((RAIZ / "conhecimento" / "relatos_teste.json").read_text(encoding="utf-8"))["casos"]
    top1 = cob = 0
    for c in casos:
        f = metodo(c["relato"])
        ordem = sorted(f, key=lambda d: -f[d])
        top1 += ordem[0] in c["dimensoes"] and f[ordem[0]] > 0
        cob += sum(d in ordem[:2] for d in c["dimensoes"]) / len(c["dimensoes"])
    return top1 / len(casos), cob / len(casos), len(casos)


if __name__ == "__main__":
    print(f"Embeddings: {tipo()}")
    for nome, m in [("RAG (embeddings)", forcas_rag), ("Palavras-chave", forcas_palavras)]:
        a, c, n = avaliar(m)
        print(f"{nome:18s} acerto da dimensão principal: {a:.0%} | cobertura nas 2 primeiras: {c:.0%} | {n} relatos")
