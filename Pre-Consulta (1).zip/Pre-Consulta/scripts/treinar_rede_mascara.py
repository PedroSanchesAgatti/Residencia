"""Treina a rede neural com máscara: estima os 4 escores do BAT-23 a partir de QUALQUER conjunto de 8 itens.

Entrada da rede (46 números):
  - 23 valores: resposta padronizada ((v - 3) / 2) nos itens respondidos, 0 nos não respondidos;
  - 23 indicadores: 1 se o item foi respondido, 0 se não.
No treino, cada pessoa aparece várias vezes, cada vez com um sorteio diferente de 8 itens
(pelo menos 1 por dimensão). Assim, uma única rede aprende a lidar com qualquer combinação.

Uso: python scripts/treinar_rede_mascara.py
Gera: modelos/rede_mascara.keras e modelos/regras.json
"""
import json
import os
import time
from pathlib import Path

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
import numpy as np
import pandas as pd
import keras
from keras import layers, regularizers
from sklearn.model_selection import train_test_split

RAIZ = Path(__file__).resolve().parent.parent
SEMENTE = 42
ITENS = [f"BAT{i}" for i in range(1, 24)]
DIMENSOES = {"Exaustão": list(range(1, 9)), "Distanciamento": list(range(9, 14)),
             "Cognitivo": list(range(14, 19)), "Emocional": list(range(19, 24))}
DIM_IDX = {d: [i - 1 for i in its] for d, its in DIMENSOES.items()}
SORTEIOS_POR_PESSOA = 60


def carregar():
    df = pd.read_csv(RAIZ / "dados" / "bat_workers_ppfi_brasil.csv")[ITENS].apply(pd.to_numeric, errors="coerce")
    df = df.where((df >= 1) & (df <= 5))
    df = df[~(df.isna().any(axis=1) | (df.std(axis=1) == 0))].astype(int).reset_index(drop=True)
    Y = np.stack([df[[f"BAT{i}" for i in its]].mean(axis=1) for its in DIMENSOES.values()], axis=1)
    return df, Y


def sortear_mascara(rng, total=8):
    """Pelo menos 1 item por dimensão; os demais sorteados entre os restantes."""
    m = np.zeros(23)
    for idx in DIM_IDX.values():
        m[rng.choice(idx)] = 1
    livres = np.where(m == 0)[0]
    m[rng.choice(livres, total - 4, replace=False)] = 1
    return m


def codificar(respostas_23, mascara):
    """respostas_23: valores 1..5 (qualquer valor onde a máscara é 0)."""
    valores = (np.asarray(respostas_23, float) - 3) / 2 * mascara
    return np.concatenate([valores, mascara])


def aumentar(X, Y, rng, n):
    entradas, alvos = [], []
    for x, y in zip(X, Y):
        for _ in range(n):
            entradas.append(codificar(x, sortear_mascara(rng))); alvos.append(y)
    return np.array(entradas), np.array(alvos)


def ranking_itens(df):
    """Correlação de cada item com a média dos outros itens da mesma dimensão (informatividade)."""
    rank = {}
    for d, its in DIMENSOES.items():
        cols = [f"BAT{i}" for i in its]
        r = {c: float(df[c].corr(df[[x for x in cols if x != c]].mean(axis=1))) for c in cols}
        rank[d] = sorted(r, key=r.get, reverse=True)
    return rank


def main():
    t0 = time.time()
    rng = np.random.default_rng(SEMENTE)
    keras.utils.set_random_seed(SEMENTE)
    df, Y = carregar()
    total = df[ITENS].mean(axis=1)
    idx_tr, idx_te = train_test_split(df.index, test_size=.2, random_state=SEMENTE, stratify=pd.qcut(total, 3, labels=False))
    idx_aj, idx_va = train_test_split(idx_tr, test_size=.15, random_state=SEMENTE)
    X = df[ITENS].to_numpy()

    Xa, Ya = aumentar(X[idx_aj], Y[idx_aj], rng, SORTEIOS_POR_PESSOA)
    Xv, Yv = aumentar(X[idx_va], Y[idx_va], rng, 20)

    rede = keras.Sequential([
        keras.Input(shape=(46,)),
        layers.Dense(32, activation="relu", kernel_regularizer=regularizers.l2(1e-4)),
        layers.Dense(16, activation="relu", kernel_regularizer=regularizers.l2(1e-4)),
        layers.Dense(4),
    ])
    rede.compile(optimizer=keras.optimizers.Adam(3e-3), loss="mse")
    hist = rede.fit(Xa, Ya, validation_data=(Xv, Yv), epochs=60, batch_size=64, verbose=0,
                    callbacks=[keras.callbacks.EarlyStopping(patience=8, restore_best_weights=True)])

    # Avaliação no teste: (1) os 8 itens base fixos; (2) sorteios variados de 8 itens
    rank = ranking_itens(df.loc[idx_tr])
    base = [c for d in DIMENSOES for c in rank[d][:2]]
    m_base = np.array([1.0 if c in base else 0.0 for c in ITENS])
    prever = lambda E: np.clip(rede.predict(E, verbose=0), 1, 5)
    Xt, Yt = X[idx_te], Y[idx_te]
    mae_base = float(np.abs(prever(np.array([codificar(x, m_base) for x in Xt])) - Yt).mean())
    Et, Ytt = aumentar(Xt, Yt, np.random.default_rng(7), 30)
    mae_var = float(np.abs(prever(Et) - Ytt).mean())
    print(f"Épocas: {len(hist.history['loss'])} | MAE teste com 8 itens base: {mae_base:.3f} | "
          f"com 8 itens variados: {mae_var:.3f} | {time.time() - t0:.0f} s")

    (RAIZ / "modelos").mkdir(exist_ok=True)
    rede.save(RAIZ / "modelos" / "rede_mascara.keras")
    regras = {"itens": ITENS, "dimensoes": {d: [f"BAT{i}" for i in its] for d, its in DIMENSOES.items()},
              "ranking": rank, "itens_base": base, "total_itens": 8,
              "metricas_teste": {"mae_itens_base": round(mae_base, 4), "mae_itens_variados": round(mae_var, 4)},
              "cortes_total_bat23": [2.59, 3.02]}
    (RAIZ / "modelos" / "regras.json").write_text(json.dumps(regras, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
