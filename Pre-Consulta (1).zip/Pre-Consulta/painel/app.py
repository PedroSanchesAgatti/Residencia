"""Painel técnico do grupo (Streamlit): raio-X das sessões, teste do RAG e métricas.
Rode com:  streamlit run painel/app.py   (com a API ligada em http://127.0.0.1:8000)"""
import json

import httpx
import pandas as pd
import streamlit as st

API = "http://127.0.0.1:8000"
st.set_page_config(page_title="Painel técnico · BAT", layout="wide")
st.title("Painel técnico · BAT pré-consulta (v2, IA local)")

try:
    saude = httpx.get(f"{API}/saude", timeout=5).json()
except Exception:
    st.error("API indisponível. Rode: uvicorn api.main:app"); st.stop()

c1, c2, c3, c4 = st.columns(4)
local = saude.get("local", {})
c1.metric(f"IA · modo {local.get('modo', saude['llm'])}", "disponível" if local.get("ia_disponivel") else "indisponível"); c2.metric("Embeddings", saude["embeddings"])
c3.metric("MAE rede (8 itens base)", saude["rede"]["mae_itens_base"]); c4.metric("MAE rede (8 itens variados)", saude["rede"]["mae_itens_variados"])

if local.get("ollama") == "ok":
    st.caption(f"Modelo rápido: {local['modelo']} {'✓' if local['modelo_instalado'] else '✗ não instalado'} · "
               f"modelo da análise: {local['modelo_apoio']} {'✓' if local['modelo_apoio_instalado'] else '✗ não instalado'}")
elif local:
    st.warning(local.get("ollama"))

aba1, aba2 = st.tabs(["Raio-X das sessões", "Testar o RAG de itens"])

with aba1:
    sessoes = httpx.get(f"{API}/sessoes").json()
    if not sessoes:
        st.info("Nenhuma sessão ainda. Use o app desktop para criar uma.")
    else:
        opcoes = {f"#{s['id']} · {s['codigo']} · {s['estado']} · {s['criada_em']}": s["id"] for s in sessoes}
        sid = opcoes[st.selectbox("Sessão", list(opcoes))]
        eventos = httpx.get(f"{API}/sessoes/{sid}/eventos").json()
        icones = {"seguranca": "🛡️", "rag_itens": "🔎", "analista": "🧠", "seletor": "🧮", "rede": "📈",
                  "rag_normas": "📚", "relator": "✍️", "validacao": "✅",
                  "rag_ciencia": "🔬", "apoio": "🩺", "revisor": "🧐", "profissional": "👩‍⚕️", "coerencia": "⚖️"}
        tokens = sum((e["tokens_entrada"] or 0) + (e["tokens_saida"] or 0) for e in eventos)
        st.caption(f"{len(eventos)} eventos · {tokens} tokens no total")
        for e in eventos:
            tk = f" · {e['tokens_entrada']} → {e['tokens_saida']} tokens" if e["tokens_entrada"] else ""
            with st.expander(f"{icones.get(e['origem'], '•')} {e['criado_em'][11:]} · {e['origem']} · {e['descricao']}{tk}"):
                st.json(json.loads(e["dados_json"]))

with aba2:
    texto = st.text_area("Relato de teste", "Ando sem paciência, esqueço reuniões e chego em casa sem energia.")
    if st.button("Buscar itens"):
        res = httpx.get(f"{API}/rag/itens", params={"texto": texto}).json()
        st.dataframe(pd.DataFrame(res), use_container_width=True, hide_index=True)
