#!/usr/bin/env bash
# Instalação da Pre-Consulta no macOS ou Linux:  ./instalar.sh
set -e
cd "$(dirname "$0")"
passo() { printf "\n==> %s\n" "$1"; }

passo "1/6 Conferindo o Python (3.11 a 3.13)"
PY=""
for c in python3.12 python3.11 python3.13 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] <= (3,13) else 1)'; then PY="$c"; break; fi
done
[ -z "$PY" ] && { echo "Python 3.11 a 3.13 não encontrado. Instale em python.org."; exit 1; }
echo "Encontrado: $($PY --version)"

passo "2/6 Conferindo o Node.js"
command -v node >/dev/null || { echo "Node.js não encontrado. Instale a versão LTS em nodejs.org."; exit 1; }
node --version

passo "3/6 Criando o .venv e instalando as bibliotecas"
[ -x .venv/bin/python ] || "$PY" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

passo "4/6 Baixando o modelo qwen2.5:7b (cerca de 5 GB)"
if command -v ollama >/dev/null; then ollama pull qwen2.5:7b || echo "Abra o Ollama e rode: ollama pull qwen2.5:7b"
else echo "Ollama não encontrado: instale em ollama.com e rode 'ollama pull qwen2.5:7b'."; fi

passo "5/6 Instalando a interface"
(cd desktop && npm install)

passo "6/6 Rodando os testes"
.venv/bin/python -m pytest -q tests || true

printf "\nPronto! Para abrir o app: ./iniciar.sh\n"
